# -*- coding: utf-8 -*-
"""5R双处决 V2.6 —— Lucy

结构对齐用户提供的红绿灯轴：
- 三个角色只共享同一份 task.five_r_double_execution_state / STEP；
- 本文件只保存 Lucy 自己负责的 STEP 与动作模块；
- 别的角色 STEP 只通过 STEP_ACTOR 排序与精确切人，不复制对方动作代码；
- 非指定三人队时回退 OK-WW 内置 Lucy。
- V2.6：固化AUTO_TARGET_CONFIRM_FRAMES=1、P1-S1闪避后HOLD=1.00s、R后HOLD=1.50s；P1-S12/P2-S11双门完成后预输入特殊Z，下一STEP继承并补足总2.50s。
"""
import time

import cv2
import numpy as np

from src.Labels import Labels
from src.char.BaseChar import SwitchPriority
from src.char.Lucy import Lucy as BuiltinLucy

class Lucy(BuiltinLucy):
    """5R双处决V2.6：共享FSM + 角色本地动作模块。"""
    FSM_VERSION = '5R双处决V2.6'

    STATE_KEY = 'five_r_double_execution_state'

    SIGNATURE_KEY = 'five_r_double_execution_signature'

    ROLE_LUCY = 'Lucy'

    ROLE_REBECCA = 'Rebecca'

    ROLE_MORNYE = 'Mornye'

    P1_S1 = 'P1-1 等自动索敌-Lucy Z0.3-闪避-续Z1.2启动挑战'

    P1_S2A = 'P1-2A Lucy自然切Rebecca'

    P1_S2B = 'P1-2B Rebecca E进CD即自然切Mornye'

    P1_S3 = 'P1-3 Mornye攒特殊Z门-R预输入Z-切Rebecca'

    P1_S4 = 'P1-4 Rebecca第二发Z-切Lucy'

    P1_S5 = 'P1-5 Lucy E1-Z0.8且0.5开始切Rebecca'

    P1_S6 = 'P1-6 Rebecca第二发Z-切Lucy'

    P1_S7 = 'P1-7 Lucy E2-Z0.8且0.5开始切Rebecca'

    P1_S8 = 'P1-8 Rebecca第二发Z-预输入Z-切Lucy'

    P1_S9 = 'P1-9 Lucy继承Z持续0.8且0.5开始切Rebecca'

    P1_S10 = 'P1-10 继承强化Z确认-协奏50%门-立即R/HMG-切Lucy'

    P1_S11 = 'P1-11 Lucy等特殊E-F/Q机会窗并释放特殊E'

    P1_S12 = 'P1-12 Lucy持续补能-F/Q机会窗-双门完成'

    P1_S13 = 'P1-13 Lucy继承预输入特殊Z-额外0.1-R1未好A等待-R1-11A-HOLD1.5-干净特殊变奏Mornye'

    P2_S1 = 'P2-1 Mornye特殊变奏-A补协奏90%-E-特殊变奏Rebecca'

    P2_S2A = 'P2-2A Rebecca特殊变奏-A落地-0.2s武器监控-手枪E进CD-预输入Z'

    P2_S2B = 'P2-2B Rebecca预输入Z完成后自然切Lucy'

    P2_S3 = 'P2-3 Lucy E1-Z0.8且0.5开始切Rebecca'

    P2_S4 = 'P2-4 Rebecca霰弹枪Z补F-实时监测F随亮随插-F后立即切Lucy'

    P2_S5 = 'P2-5 Lucy E2后干净切Rebecca'

    P2_S6 = 'P2-6 Rebecca干净切Lucy-目标侧late预输入Z'

    P2_S7 = 'P2-7 Lucy继承Z持续0.8且0.5开始切Mornye'

    P2_S8 = 'P2-8 Mornye攒特殊Z门-R后按变奏决定Rebecca入场Z'

    P2_S9 = 'P2-9 本轮强化Z记账-必要时偏斜门强化Z-协奏50%-立即R/HMG-切Lucy'

    P2_S10 = 'P2-10 Lucy等特殊E-F/Q机会窗并释放特殊E'

    P2_S11 = 'P2-11 Lucy持续补能-F/Q机会窗-双门完成'

    P2_S12 = 'P2-12 Lucy继承预输入特殊Z-额外0.1-R1未好A等待-R1-11A-HOLD1.5-干净特殊变奏Mornye'

    STEP_ACTOR = {
        P1_S1: ROLE_LUCY,
        P1_S2A: ROLE_LUCY,
        P1_S2B: ROLE_REBECCA,
        P1_S3: ROLE_MORNYE,
        P1_S4: ROLE_REBECCA,
        P1_S5: ROLE_LUCY,
        P1_S6: ROLE_REBECCA,
        P1_S7: ROLE_LUCY,
        P1_S8: ROLE_REBECCA,
        P1_S9: ROLE_LUCY,
        P1_S10: ROLE_REBECCA,
        P1_S11: ROLE_LUCY,
        P1_S12: ROLE_LUCY,
        P1_S13: ROLE_LUCY,
        P2_S1: ROLE_MORNYE,
        P2_S2A: ROLE_REBECCA,
        P2_S2B: ROLE_REBECCA,
        P2_S3: ROLE_LUCY,
        P2_S4: ROLE_REBECCA,
        P2_S5: ROLE_LUCY,
        P2_S6: ROLE_REBECCA,
        P2_S7: ROLE_LUCY,
        P2_S8: ROLE_MORNYE,
        P2_S9: ROLE_REBECCA,
        P2_S10: ROLE_LUCY,
        P2_S11: ROLE_LUCY,
        P2_S12: ROLE_LUCY,
    }

    STATE_POLL = 0.04

    ACTION_RETRY = 0.08

    SWITCH_RETRY = 0.04

    SWITCH_TIMEOUT = 6.0

    SWITCH_UNTRUSTED_CONFIRM = 2

    CONCERTO_EFFECTIVE_FULL = 0.99

    INTRO_CONFIRM_FRAMES = 3

    INTRO_CONFIRM_TIMEOUT = 1.5

    INTRO_FILL_TIMEOUT = 6.0

    # =========================================================
    # Lucy 可手动调轴参数
    # =========================================================
    # 自动索敌门：只有OK-WW已经识别到目标后，P1-S1才真正开始。
    AUTO_TARGET_CONFIRM_FRAMES = 1  # V2.6固化实机手调值：更快起轴。
    AUTO_TARGET_POLL = 0.04  # 两次索敌复核之间的间隔。

    # P1-S1 开场连续Z：先按住Z，0.30s时闪避，闪避后继续保持1.00s。
    # 调大 POST_DODGE_HOLD：闪避后Z更容易完整衔接，但开场会变慢。
    P1_S1_DODGE_OFFSET = 0.30
    P1_S1_POST_DODGE_HOLD = 1.00
    P1_S1_LUCY_Z_DURATION = P1_S1_DODGE_OFFSET + P1_S1_POST_DODGE_HOLD

    # Lucy“普通Z后切人”统一模块参数。
    # 总HOLD=0.80s；Z开始/继承后0.50s开始切人；切人期间仍保持鼠标按下。
    # LUCY_Z_SWITCH_DURATION 调大：Z更完整，但轴更慢。
    # LUCY_Z_SWITCH_OFFSET 调大：Lucy在场更久，后续Z更容易打出；调小则更早轮切。
    LUCY_Z_SWITCH_DURATION = 0.80
    LUCY_Z_SWITCH_OFFSET = 0.50

    # P1-S13 / P2-S12 共用：特殊Z完整结束后额外等待0.10s再衔接R1；
    # R1后11A结束由Lucy本体固定长按1.50s，随后自己松开再干净特殊变奏Mornye。
    LUCY_R1_AFTER_SPECIAL_Z_DELAY = 0.10
    LUCY_POST_R_HOLD_DURATION = 1.50

    # Lucy特殊Z：沿用当前官方Lucy.py的长按思路。
    LUCY_SPECIAL_Z_HOLD = 2.50
    LUCY_SPECIAL_Z_POST_RELEASE = 0.10

    LUCY_LIB_CD_WAIT = 1.50  # R1图标刚转好时允许的等待。

    # P1-S13/P2-S12共享：R1未好时持续平A，不再罚站或高速空转。
    LUCY_R1_WAIT_SLICE = 0.80
    LUCY_R1_WAIT_A_INTERVAL = 0.08

    LUCY_LIB_CLICK_COUNT = 11  # R1后模块/解密阶段额外A点击次数；不足可能不进入R2。

    LUCY_LIB_CLICK_INTERVAL = 0.10  # 模块点击间隔；调小更快但可能丢输入。


    REBECCA_FORTE_OFF_CONFIRM_FRAMES = 2

    REBECCA_PREINPUT_FORTE_WATCH = 0.18

    # F实时监控：READY只复用OK-WW成熟check_f_break/can_break；执行统一走self.f_break()。
    F_CHECK_INTERVAL = 0.04

    # V2.3：P1-S11→S12 / P2-S10→S11 共用同一F机会窗状态。
    # F可在“等待/释放特殊E”阶段提前完成，下一STEP只继承f_done，不重复F。
    P1_LUCY_F_DONE_KEY = 'p1_lucy_f_done'
    P2_LUCY_F_DONE_KEY = 'p2_lucy_f_done'

    # V2.3：机会Q只做soft service，不形成STEP/phase/完成门。
    OPPORTUNITY_ECHO_WATCH_INTERVAL = 0.10

    # 偏斜主判据永远是F成功后的固定5.5s计时；Boss血条左侧圆圈只做辅助视觉状态。
    DEFLECTION_CD = 5.50
    DEFLECTION_VISUAL_READY_THRESHOLD = 0.90

    # V2.1偏斜视觉传感器：只采样/记录，不参与FSM决策。
    # ROI来自用户确认的Boss血条左侧圆圈；12点为0号扇区，顺时针编号。
    DEFLECTION_SENSOR_SAMPLE_INTERVAL = 0.20
    DEFLECTION_SENSOR_LOG_INTERVAL = 0.50
    DEFLECTION_SENSOR_SECTORS = 12
    DEFLECTION_SENSOR_ROI_3840 = (1176, 60, 1310, 194)
    DEFLECTION_SENSOR_INNER_RADIUS_RATIO = 0.65
    DEFLECTION_SENSOR_OUTER_RADIUS_RATIO = 0.93

    PREINPUT_REARM_LIMIT = 3

    def do_perform(self):
        """共享FSM只保存STEP；Lucy文件只执行属于Lucy自己的动作模块。"""
        if not self._five_r_team_matches():
            return super().do_perform()

        state = self._get_fsm_state()
        self._service_deflection_status(state)

        # 跨角色预输入/切人两阶段提交优先恢复；只恢复handoff，不重放已完成动作。
        if state.get('pending_handoff'):
            return self._resume_pending_handoff(state)

        step = state.get('step', self.P1_S1)
        expected = self.STEP_ACTOR.get(step)

        if expected != self.ROLE_LUCY:
            return self._recover_wrong_actor(state)

        self.logger.info(
            f'[{self.FSM_VERSION}] Lucy FSM step={step} intro={self.has_intro} '
            f'instance={state.get("step_instance_id", 0)}'
        )

        if step == self.P1_S1:
            return self._p1_s1(state)
        if step == self.P1_S2A:
            return self._p1_s2a(state)
        if step == self.P1_S5:
            return self._p1_s5(state)
        if step == self.P1_S7:
            return self._p1_s7(state)
        if step == self.P1_S9:
            return self._p1_s9(state)
        if step == self.P1_S11:
            return self._p1_s11(state)
        if step == self.P1_S12:
            return self._p1_s12(state)
        if step == self.P1_S13:
            return self._p1_s13(state)
        if step == self.P2_S3:
            return self._p2_s3(state)
        if step == self.P2_S5:
            return self._p2_s5(state)
        if step == self.P2_S7:
            return self._p2_s7(state)
        if step == self.P2_S10:
            return self._p2_s10(state)
        if step == self.P2_S11:
            return self._p2_s11(state)
        if step == self.P2_S12:
            return self._p2_s12(state)

        self.logger.error(
            f'[{self.FSM_VERSION}] Lucy owns step={step} but has no handler; reset opening'
        )
        self._clear_five_r_fsm_state(clear_signature=False, reason='missing role handler')
        return None

    @classmethod
    def _expected_actor(cls, step):
        return cls.STEP_ACTOR.get(step)

    def _recover_wrong_actor(self, state):
        """对齐红绿灯轴：当前角色不属于当前STEP时，只切到STEP_ACTOR指定角色。"""
        step = state.get('step', self.P1_S1)
        actor = self._expected_actor(step)
        if actor and actor != self.ROLE_LUCY:
            self.logger.warning(
                f'[{self.FSM_VERSION}] Lucy got step={step}, expected actor={actor}; '
                f'switch to expected actor'
            )
            return self._switch_to(actor, expect_intro=None)

        self.logger.error(
            f'[{self.FSM_VERSION}] Lucy unknown/unhandled FSM step={step}; reset opening'
        )
        self._clear_five_r_fsm_state(clear_signature=False, reason='unknown step')
        self._get_fsm_state()
        return None

    def _p1_s1(self, state):
        """先等OK-WW自动索敌稳定，再执行Lucy连续Z-闪避-续Z开场。"""
        if not self._auto_target_ready():
            self.logger.info(f'[{self.FSM_VERSION}] P1-1 waiting auto-target; no axis input yet')
            return

        t0 = time.time()
        self.task.mouse_down()
        self.logger.info(
            f'[{self.FSM_VERSION}] P1-1 auto-target READY -> continuous Lucy Z HOLD; '
            f'dodge_at=+{self.P1_S1_DODGE_OFFSET:.2f}s '
            f'post_dodge_hold={self.P1_S1_POST_DODGE_HOLD:.2f}s '
            f'total={self.P1_S1_LUCY_Z_DURATION:.2f}s'
        )

        self._wait_wall_until(t0 + self.P1_S1_DODGE_OFFSET)
        dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
        self.task.send_key(dodge_key, down_time=0.01)
        self.logger.info(
            f'[{self.FSM_VERSION}] P1-1 dodge INPUT_COMMITTED at +{time.time() - t0:.3f}s; '
            f'mouse remains DOWN for another {self.P1_S1_POST_DODGE_HOLD:.2f}s'
        )

        self._wait_wall_until(t0 + self.P1_S1_LUCY_Z_DURATION)
        self.task.mouse_up()
        self.logger.info(
            f'[{self.FSM_VERSION}] P1-1 continuous Lucy Z HOLD end at +{time.time() - t0:.3f}s'
        )
        self._set_step(state, self.P1_S2A)

    def _p1_s2a(self, state):
        self._start_handoff(state, self.ROLE_REBECCA, self.P1_S2B, expect_intro=None)

    def _p1_s5(self, state):
        if not self._cast_lucy_e1():
            return
        self._lucy_normal_z_then_switch(
            state,
            target_role=self.ROLE_REBECCA,
            next_step=self.P1_S6,
            expect_intro=None,
            label='P1-5 Lucy E1后Z',
        )

    def _p1_s7(self, state):
        if not self._cast_lucy_e2():
            return
        self._lucy_normal_z_then_switch(
            state,
            target_role=self.ROLE_REBECCA,
            next_step=self.P1_S8,
            expect_intro=None,
            label='P1-7 Lucy E2后Z',
        )

    def _p1_s9(self, state):
        self._lucy_normal_z_then_switch(
            state,
            target_role=self.ROLE_REBECCA,
            next_step=self.P1_S10,
            expect_intro=None,
            label='P1-9 Lucy继承Z',
            existing_hold=True,
            watch_rebecca_enhanced=True,
        )

    def _p1_s11(self, state):
        """Lucy特殊E等待/释放阶段同时开启F机会窗；F与特殊E互不等待。"""
        f_done_key = self.P1_LUCY_F_DONE_KEY
        if f_done_key not in state:
            state[f_done_key] = False
            self._reset_f_monitor(state)

        if not self._wait_lucy_special_e_available(
            state, label='P1-11', f_done_key=f_done_key
        ):
            return
        if not self._cast_lucy_special_e(
            state, label='P1-11', f_done_key=f_done_key
        ):
            return
        self._set_step(state, self.P1_S12)

    def _run_lucy_energy_f_dual_gate_step(self, state, label, next_step, f_done_key):
        """持续A补特殊能量；双门完成后在当前STEP末尾直接预输入特殊Z。

        V2.6：利用最后一发A后的输入缓存，让下一STEP继承已经按住的Z；
        特殊Z总HOLD仍从这里真实mouse_down的T0起算2.50s。
        """
        if not self._lucy_wait_f_and_special_energy_full(
            state, label=label, f_done_key=f_done_key
        ):
            return False
        if not self._arm_lucy_special_z_preinput(state, label=f'{label}->SPECIAL_Z'):
            return False
        self._set_step(state, next_step)
        return True

    def _arm_lucy_special_z_preinput(self, state, label):
        """双门完成后立即按住Z，并把HOLD跨STEP交给特殊Z模块。"""
        active_key = 'lucy_special_z_preinput_active'
        started_key = 'lucy_special_z_preinput_started_at'

        if state.get(active_key, False) and state.get('mouse_hold_active', False):
            return True

        # 防止异常旧状态把本次T0污染。
        state.pop(active_key, None)
        state.pop(started_key, None)
        if state.get('mouse_hold_active', False):
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: stale HOLD before special-Z preinput -> cleanup'
            )
            self._safe_mouse_up(state)

        self.task.mouse_down()
        started_at = time.time()
        state['mouse_hold_active'] = True
        state[active_key] = True
        state[started_key] = started_at
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: SPECIAL_Z PREINPUT ARMED after A-fill; '
            f'hold_T0={started_at:.3f} total={self.LUCY_SPECIAL_Z_HOLD:.2f}s'
        )
        return True

    def _p1_s12(self, state):
        """继承P1-S11的F机会窗结果；补能过程中继续F/Q soft service。"""
        self._run_lucy_energy_f_dual_gate_step(
            state,
            label='P1-12',
            next_step=self.P1_S13,
            f_done_key=self.P1_LUCY_F_DONE_KEY,
        )

    def _p1_s13(self, state):
        """继承前STEP预输入特殊Z -> 额外0.10s -> R1未好A等待 -> R1+11A+固定HOLD1.5s -> 干净特殊变奏Mornye。"""
        phase_key = 'p1_s13_phase'
        phase = state.get(phase_key, 'special_z')

        if phase == 'special_z':
            if not self._lucy_special_z_mature(state, 'P1-13 Lucy special Z'):
                return
            self.logger.info(
                f'[{self.FSM_VERSION}] P1-13 special Z complete -> '
                f'extra R1 settle {self.LUCY_R1_AFTER_SPECIAL_Z_DELAY:.2f}s'
            )
            self.sleep(self.LUCY_R1_AFTER_SPECIAL_Z_DELAY, check_combat=False)
            self.task.next_frame()
            state[phase_key] = 'wait_r1_ready'
            phase = 'wait_r1_ready'

        if phase == 'wait_r1_ready':
            if not self._wait_lucy_r1_ready_with_attacks(state, label='P1-13 Lucy R1'):
                return
            state[phase_key] = 'r1_11a_hold'
            phase = 'r1_11a_hold'

        if phase == 'r1_11a_hold':
            if not self._lucy_r1_11a_fixed_hold(state, label='P1-13 Lucy R1/11A/HOLD'):
                return
            state[phase_key] = 'handoff'
            phase = 'handoff'

        if phase == 'handoff':
            # 新一轮P2开始前清空“本轮强化Z已消费”账本。
            state['p2_enhanced_z_consumed'] = False
            state.pop('p2_enhanced_z_consumed_at', None)
            state.pop('p2_enhanced_z_consumed_label', None)
            if self._start_handoff(
                state,
                self.ROLE_MORNYE,
                self.P2_S1,
                expect_intro=True,
                preinput=False,
            ):
                state.pop(phase_key, None)
            return
    def _p2_s3(self, state):
        if not self._cast_lucy_e1():
            return
        self._lucy_normal_z_then_switch(
            state,
            target_role=self.ROLE_REBECCA,
            next_step=self.P2_S4,
            expect_intro=None,
            label='P2-3 Lucy E1后Z',
        )

    def _p2_s5(self, state):
        """P2-S5：Lucy E2后直接干净切Rebecca，不再让Rebecca继承Lucy的Z HOLD。

        V2.5冻结规则：
        - Lucy -> Rebecca 永远 clean switch；
        - 不再用瞬时mouse_forte去猜“这发跨角色Z最终会不会升级强化Z”；
        - Rebecca -> Lucy 的预输入改由P2-S6在Lucy成为当前角色后再目标侧ARM。
        """
        if not self._cast_lucy_e2():
            return

        state.pop('p2_s6_entry_z_suppressed', None)
        state.pop('p2_s6_enhanced_ready_before_lucy', None)
        self.logger.info(
            f'[{self.FSM_VERSION}] P2-5 Lucy E2 complete -> clean switch Rebecca; '
            f'NO Lucy->Rebecca Z inheritance'
        )
        return self._start_handoff(
            state,
            self.ROLE_REBECCA,
            self.P2_S6,
            expect_intro=None,
            preinput=False,
        )

    def _p2_s7(self, state):
        self._lucy_normal_z_then_switch(
            state,
            target_role=self.ROLE_MORNYE,
            next_step=self.P2_S8,
            expect_intro=None,
            label='P2-7 Lucy继承Z',
            existing_hold=True,
        )

    def _p2_s10(self, state):
        """Lucy特殊E等待/释放阶段同时开启F机会窗；F与特殊E互不等待。"""
        f_done_key = self.P2_LUCY_F_DONE_KEY
        if f_done_key not in state:
            state[f_done_key] = False
            self._reset_f_monitor(state)

        if not self._wait_lucy_special_e_available(
            state, label='P2-10', f_done_key=f_done_key
        ):
            return
        if not self._cast_lucy_special_e(
            state, label='P2-10', f_done_key=f_done_key
        ):
            return
        self._set_step(state, self.P2_S11)

    def _p2_s11(self, state):
        """继承P2-S10的F机会窗结果；补能过程中继续F/Q soft service。"""
        self._run_lucy_energy_f_dual_gate_step(
            state,
            label='P2-11',
            next_step=self.P2_S12,
            f_done_key=self.P2_LUCY_F_DONE_KEY,
        )

    def _p2_s12(self, state):
        """继承前STEP预输入特殊Z -> 额外0.10s -> R1未好A等待 -> R1+11A+固定HOLD1.5s -> 干净特殊变奏Mornye。"""
        phase_key = 'p2_s12_phase'
        phase = state.get(phase_key, 'special_z')

        if phase == 'special_z':
            if not self._lucy_special_z_mature(state, 'P2-12 Lucy special Z'):
                return
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-12 special Z complete -> '
                f'extra R1 settle {self.LUCY_R1_AFTER_SPECIAL_Z_DELAY:.2f}s'
            )
            self.sleep(self.LUCY_R1_AFTER_SPECIAL_Z_DELAY, check_combat=False)
            self.task.next_frame()
            state[phase_key] = 'wait_r1_ready'
            phase = 'wait_r1_ready'

        if phase == 'wait_r1_ready':
            if not self._wait_lucy_r1_ready_with_attacks(state, label='P2-12 Lucy R1'):
                return
            state[phase_key] = 'r1_11a_hold'
            phase = 'r1_11a_hold'

        if phase == 'r1_11a_hold':
            if not self._lucy_r1_11a_fixed_hold(state, label='P2-12 Lucy R1/11A/HOLD'):
                return
            state[phase_key] = 'handoff'
            phase = 'handoff'

        if phase == 'handoff':
            # 新一轮P2开始前清空“本轮强化Z已消费”账本。
            state['p2_enhanced_z_consumed'] = False
            state.pop('p2_enhanced_z_consumed_at', None)
            state.pop('p2_enhanced_z_consumed_label', None)
            if self._start_handoff(
                state,
                self.ROLE_MORNYE,
                self.P2_S1,
                expect_intro=True,
                preinput=False,
            ):
                state.pop(phase_key, None)
            return
    def _lucy_normal_z_only(self, label, hold_duration=None):
        """只在Lucy本体完成一次普通Z，不把鼠标HOLD跨角色传出去。"""
        duration = self.LUCY_Z_SWITCH_DURATION if hold_duration is None else float(hold_duration)
        self.task.mouse_down()
        self.sleep(duration, check_combat=False)
        self.task.mouse_up()
        self.task.next_frame()
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Lucy local Z INPUT_COMMITTED hold={duration:.2f}s'
        )
        return True

    def _deflection_elapsed_shared(self, state):
        t0 = state.get('deflection_cd_started_at')
        if not isinstance(t0, (int, float)):
            return 999.0
        return max(0.0, float(self.time_elapsed_accounting_for_freeze(t0)))

    def _deflection_ready_shared(self, state):
        return self._deflection_elapsed_shared(state) >= self.DEFLECTION_CD

    def _deflection_remaining_shared(self, state):
        return max(0.0, self.DEFLECTION_CD - self._deflection_elapsed_shared(state))


    def _get_deflection_visual_sensor_box(self):
        """Boss血条左侧偏斜圆圈的用户确认ROI；仅用于被动采样。"""
        x1, y1, x2, y2 = self.DEFLECTION_SENSOR_ROI_3840
        return self.task.box_of_screen_scaled(
            3840, 2160, x1, y1, x2, y2,
            name='deflection_visual_sensor', hcenter=True,
        )

    def _sample_deflection_visual_raw(self):
        """
        被动采样偏斜圆圈。

        不在这里判断0~100%进度，也不产生READY/CD控制结论。
        只输出：成熟f_break_full命中 + 12个顺时针扇区的原始灰度统计，
        用下一轮实机日志标定是否能复用成熟圆环方案。
        """
        try:
            box = self._get_deflection_visual_sensor_box()
            frame = getattr(self.task, 'frame', None)
            if frame is None:
                return None
            crop = box.crop_frame(frame)
            if crop is None or crop.size == 0:
                return None

            gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape[:2]
            if h < 12 or w < 12:
                return None

            cx = (w - 1) / 2.0
            cy = (h - 1) / 2.0
            yy, xx = np.indices((h, w), dtype=np.float32)
            dx = xx - cx
            dy = yy - cy
            radius = np.sqrt(dx * dx + dy * dy)
            max_r = min(w, h) / 2.0
            annulus = (
                (radius >= max_r * self.DEFLECTION_SENSOR_INNER_RADIUS_RATIO)
                & (radius <= max_r * self.DEFLECTION_SENSOR_OUTER_RADIUS_RATIO)
            )

            # 0 rad = 12点；正方向 = 顺时针。
            angle = (np.arctan2(dx, -dy) + 2.0 * np.pi) % (2.0 * np.pi)
            sector_width = 2.0 * np.pi / float(self.DEFLECTION_SENSOR_SECTORS)
            sector_ids = np.floor(angle / sector_width).astype(np.int16)

            sector_p75 = []
            sector_mean = []
            for idx in range(self.DEFLECTION_SENSOR_SECTORS):
                vals = gray[annulus & (sector_ids == idx)]
                if vals.size == 0:
                    sector_p75.append(-1)
                    sector_mean.append(-1)
                    continue
                sector_p75.append(int(round(float(np.percentile(vals, 75)))))
                sector_mean.append(int(round(float(np.mean(vals)))))

            ring_vals = gray[annulus]
            if ring_vals.size == 0:
                return None

            try:
                ready_template = bool(
                    self.task.find_one(
                        Labels.f_break_full,
                        threshold=self.DEFLECTION_VISUAL_READY_THRESHOLD,
                    )
                )
            except Exception:
                ready_template = False

            return {
                'template_ready': ready_template,
                'sector_p75': tuple(sector_p75),
                'sector_mean': tuple(sector_mean),
                'ring_mean': float(np.mean(ring_vals)),
                'ring_p90': float(np.percentile(ring_vals, 90)),
            }
        except Exception:
            return None

    def _read_deflection_visual_progress(self, state=None):
        """测试骨架暂不把原始扇区亮度硬映射成0~1；待实机日志标定后再实现。"""
        return None

    def _service_deflection_visual_sensor(self, state, timer_ready=None, force=False):
        """
        被动偏斜视觉传感器。

        - 不改变deflection_cd_started_at；
        - 不改变5.5s主门；
        - 不提前放行强化Z；
        - 只把原始12扇区数据写入共享state并低频输出测试日志。
        """
        now = time.time()
        last_sample = float(state.get('deflection_sensor_sample_at', -100.0) or -100.0)
        if not force and now - last_sample < self.DEFLECTION_SENSOR_SAMPLE_INTERVAL:
            return state.get('deflection_sensor_latest')

        state['deflection_sensor_sample_at'] = now
        sample = self._sample_deflection_visual_raw()
        state['deflection_sensor_latest'] = sample
        if sample is None:
            return None

        state['deflection_visual_ready'] = bool(sample['template_ready'])
        if timer_ready is False:
            visual_state = 'CD_TIMER'
        elif sample['template_ready']:
            visual_state = 'F_READY_TEMPLATE'
        else:
            visual_state = 'BUILD_OR_UNKNOWN'
        state['deflection_sensor_visual_state'] = visual_state

        last_log = float(state.get('deflection_sensor_log_at', -100.0) or -100.0)
        previous_state = state.get('deflection_sensor_logged_state')
        template_changed = state.get('deflection_sensor_logged_template') != bool(sample['template_ready'])
        should_log = (
            force
            or visual_state != previous_state
            or template_changed
            or now - last_log >= self.DEFLECTION_SENSOR_LOG_INTERVAL
        )
        if should_log:
            p75 = ','.join(str(v) for v in sample['sector_p75'])
            self.logger.info(
                f'[{self.FSM_VERSION}] DEFLECTION_SENSOR raw state={visual_state} '
                f'template_ready={sample["template_ready"]} '
                f'ring_mean={sample["ring_mean"]:.1f} ring_p90={sample["ring_p90"]:.1f} '
                f'p75cw12=[{p75}]'
            )
            state['deflection_sensor_log_at'] = now
            state['deflection_sensor_logged_state'] = visual_state
            state['deflection_sensor_logged_template'] = bool(sample['template_ready'])
        return sample

    def _service_deflection_status(self, state, force=False):
        """5.5s固定CD是唯一主门；全局日志只在READY/COOLDOWN状态切换时输出。

        force只强制刷新视觉传感器，不再强制打印remaining。
        STEP自己的remaining决策日志继续保留。
        """
        ready = self._deflection_ready_shared(state)
        current = 'READY' if ready else 'COOLDOWN'
        previous = state.get('deflection_status_last')

        self._service_deflection_visual_sensor(state, timer_ready=ready, force=force)
        visual_ready = bool(state.get('deflection_visual_ready', False))

        if current != previous:
            if ready:
                self.logger.info(
                    f'[{self.FSM_VERSION}] DEFLECTION READY by fixed {self.DEFLECTION_CD:.2f}s timer '
                    f'visual_ready={visual_ready} (aux only)'
                )
            else:
                self.logger.info(
                    f'[{self.FSM_VERSION}] DEFLECTION CD START fixed={self.DEFLECTION_CD:.2f}s '
                    f'visual_ready={visual_ready} (aux only)'
                )
            state['deflection_status_last'] = current
        return ready

    def _lucy_normal_z_then_switch(
        self,
        state,
        target_role,
        next_step,
        expect_intro=None,
        label='Lucy Z then switch',
        existing_hold=False,
        watch_rebecca_enhanced=False,
        hold_duration=None,
        switch_offset=None,
        dodge_offset=None,
    ):
        """Lucy所有“普通Z后切人”统一入口。

        - hold_duration：这一发Z从mouse_down到mouse_up的总持续时间；
          调大更容易完整出招，调小更快。
        - switch_offset：Z开始/继承后多久开始切人；
          调大=Lucy在场更久，后续Z更容易出来；调小=更早轮切。
        - 切人开始后不会自动松鼠标，直到hold_duration到点才mouse_up。
        - existing_hold=True表示Lucy入场时继承上一角色已经按住的鼠标。
        - dodge_offset不为None时：在Z保持期间到该时刻短按一次闪避，鼠标全程不松；
          用于P1-S13复现P1-S1的“Z -> 闪避 -> 继续Z”取消节奏。
        - 单个STEP可以传自己的hold_duration/switch_offset/dodge_offset覆盖默认值。
        """
        hold_duration = (
            self.LUCY_Z_SWITCH_DURATION if hold_duration is None else float(hold_duration)
        )
        switch_offset = (
            self.LUCY_Z_SWITCH_OFFSET if switch_offset is None else float(switch_offset)
        )
        if switch_offset >= hold_duration:
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: switch_offset {switch_offset:.2f} >= '
                f'hold {hold_duration:.2f}; clamp to keep HOLD across switch'
            )
            switch_offset = max(0.0, hold_duration - 0.05)

        if not existing_hold or not state.get('mouse_hold_active', False):
            self.task.mouse_down()
            state['mouse_hold_active'] = True
            if existing_hold:
                self.logger.warning(
                    f'[{self.FSM_VERSION}] {label}: inherited HOLD missing -> recovery mouse_down'
                )

        t0 = time.time()
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Lucy Z-switch HOLD start '
            f'duration={hold_duration:.2f}s switch_at=+{switch_offset:.2f}s '
            f'dodge_at={None if dodge_offset is None else round(float(dodge_offset), 2)} '
            f'existing_hold={existing_hold}'
        )

        # 需要闪避取消时，先保持Z到dodge_offset，短按一次闪避，再继续保持同一个mouse_down。
        if dodge_offset is not None:
            dodge_offset = max(0.0, min(float(dodge_offset), hold_duration))
            if dodge_offset < switch_offset:
                self._wait_wall_until(t0 + dodge_offset)
                dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
                self.task.send_key(dodge_key, down_time=0.01)
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: dodge INPUT_COMMITTED at '
                    f'+{time.time() - t0:.3f}s while mouse remains DOWN'
                )
            else:
                self.logger.warning(
                    f'[{self.FSM_VERSION}] {label}: dodge_offset={dodge_offset:.2f} '
                    f'>= switch_offset={switch_offset:.2f}; skip dodge to avoid racing switch'
                )

        self._wait_wall_until(t0 + switch_offset)
        return self._start_handoff(
            state,
            target_role,
            next_step,
            expect_intro=expect_intro,
            preinput=True,
            existing_hold=True,
            release_at=t0 + hold_duration,
            target_hold=0.0,
            watch_rebecca_enhanced=watch_rebecca_enhanced,
        )

    def _auto_target_ready(self):
        """使用OK-WW CombatCheck.has_target()成熟识别，连续多帧有目标才启动轴。"""
        good = 0
        for _ in range(self.AUTO_TARGET_CONFIRM_FRAMES):
            self.task.next_frame()
            try:
                has_target = bool(self.task.has_target())
            except Exception:
                has_target = False
            if not has_target:
                return False
            good += 1
            self.sleep(self.AUTO_TARGET_POLL, check_combat=False)
        if good >= self.AUTO_TARGET_CONFIRM_FRAMES:
            self.logger.info(
                f'[{self.FSM_VERSION}] auto-target confirmed '
                f'{good}/{self.AUTO_TARGET_CONFIRM_FRAMES}'
            )
            return True
        return False

    def _try_opportunity_echo(self, state, label, force=False):
        """站场机会Q：有就尝试一次；不形成STEP/phase，也不阻塞主轴硬门。"""
        if not isinstance(state, dict):
            return False
        if state.get('pending_handoff') or state.get('mouse_hold_active'):
            return False

        try:
            in_team, current_index, _ = self.task.in_team()
            if not in_team or current_index != self.index:
                return False
        except Exception:
            if not getattr(self, 'is_current_char', False):
                return False

        now = time.time()
        last = float(getattr(self, '_five_r_last_opportunity_echo_watch', -100.0) or -100.0)
        if not force and now - last < self.OPPORTUNITY_ECHO_WATCH_INTERVAL:
            return False
        self._five_r_last_opportunity_echo_watch = now

        try:
            if not self.echo_available():
                return False
            result = bool(self.click_echo(time_out=0))
        except Exception as exc:
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: opportunity Q exception={exc}'
            )
            return False

        if result:
            self.logger.info(f'[{self.FSM_VERSION}] {label}: opportunity Q INPUT_COMMITTED')
        return result

    def _wait_lucy_r1_ready_with_attacks(self, state, label):
        """P1-S13/P2-S12共用：R1未好时A等待；等待空档允许soft机会Q。"""
        started_key = 'lucy_r1_wait_started_at'

        self.task.next_frame()
        try:
            ready = bool(self.liberation_available())
        except Exception:
            ready = False

        if ready:
            started = state.pop(started_key, None)
            if isinstance(started, (int, float)):
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: R1 READY after A wait '
                    f'{time.time() - float(started):.2f}s'
                )
            return True

        if not isinstance(state.get(started_key), (int, float)):
            state[started_key] = time.time()
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: R1 not ready -> A/Q wait starts'
            )

        slice_start = time.time()
        while time.time() - slice_start < self.LUCY_R1_WAIT_SLICE:
            self._try_opportunity_echo(state, f'{label}-wait')
            self.normal_attack()
            self.sleep(self.LUCY_R1_WAIT_A_INTERVAL, check_combat=False)
            self.task.next_frame()
            try:
                ready = bool(self.liberation_available())
            except Exception:
                ready = False
            if ready:
                started = state.pop(started_key, time.time())
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: R1 READY after A wait '
                    f'{time.time() - float(started):.2f}s'
                )
                return True

        return False

    def _lucy_r1_11a_fixed_hold(self, state, label):
        """P1-S13/P2-S12共享：官方R1 -> 11A -> Lucy本体固定HOLD2s -> 自己松开。"""
        try:
            ready = bool(self.liberation_available())
        except Exception:
            ready = False
        if not ready:
            self.logger.warning(f'[{self.FSM_VERSION}] {label}: R1 not ready')
            return False

        try:
            clicked = bool(
                self.click_liberation(
                    send_click=True,
                    wait_if_cd_ready=self.LUCY_LIB_CD_WAIT,
                    click_f=False,
                )
            )
        except Exception as exc:
            self.logger.warning(f'[{self.FSM_VERSION}] {label}: R1 exception={exc}')
            return False
        if not clicked:
            self.logger.warning(f'[{self.FSM_VERSION}] {label}: R1 not confirmed')
            return False

        for _ in range(self.LUCY_LIB_CLICK_COUNT):
            self.click()
            self.sleep(self.LUCY_LIB_CLICK_INTERVAL, check_combat=False)
            self.task.next_frame()
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: module click package complete '
            f'count={self.LUCY_LIB_CLICK_COUNT}'
        )

        # 沿用V2.2：不再等待/识别R2 HUD，也不把HOLD继承给Mornye。
        # 若此前异常路径残留HOLD，先清理，再由Lucy本体重新开始固定时长长按。
        if state.get('mouse_hold_active', False):
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: stale mouse HOLD before fixed hold -> cleanup'
            )
            self._safe_mouse_up(state)

        self.task.mouse_down()
        state['mouse_hold_active'] = True
        hold_start = time.time()
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Lucy fixed HOLD start '
            f'duration={self.LUCY_POST_R_HOLD_DURATION:.2f}s'
        )
        try:
            while time.time() - hold_start < self.LUCY_POST_R_HOLD_DURATION:
                self.task.next_frame()
                self.sleep(self.STATE_POLL, check_combat=False)
        finally:
            self._safe_mouse_up(state)

        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Lucy fixed HOLD complete '
            f'elapsed={time.time() - hold_start:.2f}s -> mouse UP before Mornye handoff'
        )
        return True
    def _lucy_e2_gold_ratio(self):
        """沿用已实机使用过的 Lucy E2 金色图标思路：在 resonance 图标内读金色 HSV 覆盖率。"""
        try:
            box = self.task.get_box_by_name('box_resonance')
            image = box.crop_frame(self.task.frame)
        except Exception:
            return 0.0
        if image is None or getattr(image, 'ndim', 0) < 3:
            return 0.0
        hsv = cv2.cvtColor(image[..., :3], cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        mask = (h >= 12) & (h <= 38) & (s > 40) & (v > 90)
        return float(np.count_nonzero(mask)) / float(mask.size or 1)

    def _is_lucy_e2_gold(self):
        return self._lucy_e2_gold_ratio() >= 0.10

    def _cast_lucy_e1(self):
        """E1：非满特殊能量的第一段 E；以 E被接收 + E2金色阶段出现为主确认。"""
        start = time.time()
        last_send = -100.0
        sent = False
        cd_seen = False

        while time.time() - start < 1.4:
            self.task.next_frame()
            if self.is_forte_full():
                self.logger.warning(f'[{self.FSM_VERSION}] Lucy E1 blocked: forte already full')
                return False

            if sent and self._is_lucy_e2_gold():
                self.record_resonance_use()
                self.logger.info(
                    f'[{self.FSM_VERSION}] Lucy E1 HARD_CONFIRMED -> E2 gold ratio='
                    f'{self._lucy_e2_gold_ratio():.3f}'
                )
                return True

            if sent and self.has_cd('resonance'):
                cd_seen = True

            now = time.time()
            if self.resonance_available() and now - last_send >= self.ACTION_RETRY:
                self.send_resonance_key()
                sent = True
                last_send = now

            self.sleep(self.STATE_POLL, check_combat=False)

        if sent and cd_seen:
            self.record_resonance_use()
            self.logger.warning(
                f'[{self.FSM_VERSION}] Lucy E1 DEGRADED_CONFIRMED by resonance CD; '
                f'E2 gold not captured'
            )
            return True
        self.logger.warning(f'[{self.FSM_VERSION}] Lucy E1 confirmation timeout')
        return False

    def _cast_lucy_e2(self):
        """E2：等待金色 E2 阶段；释放后以金色状态消失或 E进入CD确认。"""
        ready_start = time.time()
        gold_seen = False
        while time.time() - ready_start < 1.5:
            self.task.next_frame()
            if self._is_lucy_e2_gold():
                gold_seen = True
                break
            self.sleep(self.STATE_POLL, check_combat=False)

        if not gold_seen:
            self.logger.warning(
                f'[{self.FSM_VERSION}] Lucy E2 gold READY not captured; '
                f'fall back to one resonance attempt if available'
            )

        start = time.time()
        last_send = -100.0
        sent = False
        while time.time() - start < 1.2:
            self.task.next_frame()
            gold = self._is_lucy_e2_gold()

            if sent and ((gold_seen and not gold) or self.has_cd('resonance')):
                self.record_resonance_use()
                self.logger.info(
                    f'[{self.FSM_VERSION}] Lucy E2 CONFIRMED gold_before={gold_seen} gold_now={gold}'
                )
                return True

            now = time.time()
            if (gold or self.resonance_available()) and now - last_send >= self.ACTION_RETRY:
                self.send_resonance_key()
                sent = True
                last_send = now

            self.sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(f'[{self.FSM_VERSION}] Lucy E2 confirmation timeout')
        return False

    def _lucy_special_e_available(self):
        """特殊E门：Lucy特殊能量已满，并且E技能当前可输入。"""
        return bool(self.is_forte_full() and self.resonance_available())

    def _wait_lucy_special_e_available(self, state, label, f_done_key, timeout=10.0):
        """特殊E未就绪时A等待；F优先实时插入，主门未好时允许soft机会Q。"""
        start = time.time()
        last_log = -100.0
        while time.time() - start < timeout:
            self.task.next_frame()

            # F executor可能自身占用一段墙钟时间；这段不扣特殊E等待预算。
            f_t0 = time.time()
            self._service_lucy_f_opportunity(
                state, label=f'{label}-SPECIAL_E_WAIT', f_done_key=f_done_key
            )
            start += max(0.0, time.time() - f_t0)

            forte_full = bool(self.is_forte_full())
            e_ready = bool(self.resonance_available())
            if forte_full and e_ready:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label} Lucy SPECIAL_E READY '
                    f'forte_full=True resonance_ready=True '
                    f'F_done={bool(state.get(f_done_key, False))}'
                )
                return True

            # 只有主轴特殊E硬门尚未满足时，才消费机会Q，避免Q延迟特殊E。
            self._try_opportunity_echo(state, f'{label}-SPECIAL_E_WAIT')

            now = time.time()
            if now - last_log >= 0.5:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label} wait SPECIAL_E: '
                    f'forte_full={forte_full} resonance_ready={e_ready} '
                    f'F_done={bool(state.get(f_done_key, False))} -> A/Q'
                )
                last_log = now

            self.normal_attack()
            self.sleep(0.08)

        self.logger.warning(f'[{self.FSM_VERSION}] {label} wait SPECIAL_E timeout')
        return False

    def _cast_lucy_special_e(self, state, label, f_done_key):
        """特殊E释放确认；释放窗口内F仍保持最高优先级机会插入。"""
        if not self._lucy_special_e_available():
            return False

        pre_ratio = self._lucy_special_energy_ratio()
        self.logger.info(
            f'[{self.FSM_VERSION}] {label} SPECIAL_E pre-energy='
            f'{"UNKNOWN" if pre_ratio is None else f"{pre_ratio:.3f}"} '
            f'F_done={bool(state.get(f_done_key, False))}'
        )

        start = time.time()
        last_send = -100.0
        sent = False
        low_frames = 0
        while time.time() - start < 2.0:
            self.task.next_frame()

            # F executor可能持续较久；执行F所花的墙钟时间不扣SPECIAL_E确认窗口。
            f_t0 = time.time()
            self._service_lucy_f_opportunity(
                state, label=f'{label}-SPECIAL_E_CAST', f_done_key=f_done_key
            )
            start += max(0.0, time.time() - f_t0)

            ratio = self._lucy_special_energy_ratio()
            if sent and ratio is not None:
                low = ratio <= 0.25
                if pre_ratio is not None and pre_ratio > 0.20:
                    low = low or ratio <= pre_ratio * 0.40
                low_frames = low_frames + 1 if low else 0
                if low_frames >= 2:
                    self.record_resonance_use()
                    self.logger.info(
                        f'[{self.FSM_VERSION}] {label} Lucy SPECIAL_E HARD_CONFIRMED '
                        f'by red-energy drop pre={pre_ratio} now={ratio:.3f}'
                    )
                    return True

            if sent and (self.has_cd('resonance') or not self.is_forte_full()):
                self.record_resonance_use()
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label} Lucy SPECIAL_E AUX_CONFIRMED '
                    f'cd={self.has_cd("resonance")} forte_full={self.is_forte_full()}'
                )
                return True

            now = time.time()
            if self.resonance_available() and now - last_send >= self.ACTION_RETRY:
                self.send_resonance_key()
                sent = True
                last_send = now

            self.sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(f'[{self.FSM_VERSION}] {label} Lucy SPECIAL_E timeout')
        return False

    def _lucy_special_z_mature(self, state, label):
        """Lucy特殊Z长按模块，优先继承V2.6上一STEP的预输入HOLD。

        若预输入存在，则HOLD总时长从上一STEP真实mouse_down的T0起算；
        若异常丢失HOLD，则自动退回旧版“当前STEP等待READY后重新起Z”的安全路径。
        """
        active_key = 'lucy_special_z_preinput_active'
        started_key = 'lucy_special_z_preinput_started_at'

        inherited = bool(
            state.get(active_key, False)
            and state.get('mouse_hold_active', False)
            and isinstance(state.get(started_key), (int, float))
        )

        if inherited:
            hold_start = float(state[started_key])
            elapsed = max(0.0, time.time() - hold_start)
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: inherit SPECIAL_Z PREINPUT '
                f'elapsed={elapsed:.3f}s remaining={max(0.0, self.LUCY_SPECIAL_Z_HOLD - elapsed):.3f}s'
            )
        else:
            if state.get(active_key, False) or state.get(started_key) is not None:
                self.logger.warning(
                    f'[{self.FSM_VERSION}] {label}: special-Z preinput state incomplete -> '
                    f'fallback local start'
                )
            state.pop(active_key, None)
            state.pop(started_key, None)
            if state.get('mouse_hold_active', False):
                self._safe_mouse_up(state)

            ready_start = time.time()
            while time.time() - ready_start < 2.0:
                self.task.next_frame()
                if self.is_mouse_forte_full():
                    break
                self.sleep(self.STATE_POLL, check_combat=False)
            else:
                self.logger.warning(f'[{self.FSM_VERSION}] {label}: mouse_forte READY timeout')
                return False

            self.task.mouse_down()
            hold_start = time.time()
            state['mouse_hold_active'] = True
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: READY -> local hold '
                f'{self.LUCY_SPECIAL_Z_HOLD:.2f}s (fallback path)'
            )

        prompt_off_logged = False
        try:
            while time.time() - hold_start < self.LUCY_SPECIAL_Z_HOLD:
                self.task.next_frame()
                if not prompt_off_logged and not self.is_mouse_forte_full():
                    prompt_off_logged = True
                    self.logger.info(
                        f'[{self.FSM_VERSION}] {label}: mouse_forte OFF at '
                        f'+{time.time() - hold_start:.3f}s; keep holding for damage'
                    )
                self.sleep(0.05, check_combat=False)
        finally:
            if state.get('mouse_hold_active', False):
                self._safe_mouse_up(state)
            else:
                # 极端异常下也确保物理鼠标状态释放。
                try:
                    self.task.mouse_up()
                except Exception:
                    pass
            state.pop(active_key, None)
            state.pop(started_key, None)

        self.sleep(self.LUCY_SPECIAL_Z_POST_RELEASE, check_combat=False)
        self.task.next_frame()
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: long-hold INPUT_COMPLETED '
            f'total={time.time() - hold_start:.3f}s inherited={inherited}'
        )
        return True

    def _lucy_special_energy_ratio(self):
        """
        实机 1600x900 客户区标定后换算到 3840x2160 HUD：
        内部有效条约 x=1627..2172, y=1978..2014。
        只读取内部条，不包含两侧装饰。填充从左向右。
        """
        try:
            box = self.task.box_of_screen_scaled(
                3840, 2160,
                1627, 1978, 2172, 2014,
                name='five_r_lucy_special_energy',
                hcenter=True,
            )
            image = box.crop_frame(self.task.frame)
        except Exception:
            return None

        if image is None or getattr(image, 'ndim', 0) < 3 or image.shape[1] < 20:
            return None

        hsv = cv2.cvtColor(image[..., :3], cv2.COLOR_BGR2HSV)
        v = hsv[:, :, 2].astype(np.float32).mean(axis=0)
        width = len(v)

        # 1600实机 ROI 宽约227px时，9px平滑效果稳定；按宽度同比缩放。
        kernel = max(3, int(round(width * 9.0 / 227.0)))
        if kernel % 2 == 0:
            kernel += 1
        kernel = min(kernel, width if width % 2 == 1 else width - 1)
        if kernel < 3:
            return None

        smooth = np.convolve(v, np.ones(kernel, dtype=np.float32) / kernel, mode='same')
        active = smooth >= 128.0

        gap_tol = max(2, int(round(width * 8.0 / 227.0)))
        first_window = max(4, int(round(width * 20.0 / 227.0)))

        # 桥接填充格之间的小暗缝，但不跨越真实终点。
        merged = active.copy()
        i = 0
        while i < width:
            if merged[i]:
                i += 1
                continue
            j = i
            while j < width and not merged[j]:
                j += 1
            if i > 0 and j < width and (j - i) <= gap_tol and merged[i - 1] and merged[j]:
                merged[i:j] = True
            i = j

        first = np.flatnonzero(merged[:first_window])
        if first.size == 0:
            return 0.0
        merged[:int(first[0])] = True

        boundary = width
        i = 0
        while i < width:
            if merged[i]:
                i += 1
                continue
            j = i
            while j < width and not merged[j]:
                j += 1
            if (j - i) > gap_tol:
                boundary = i
                break
            i = j

        return max(0.0, min(1.0, float(boundary) / float(width)))

    def _reset_f_monitor(self, state):
        state['f_available'] = False
        state['last_f_check_at'] = -100.0


    def _service_f_monitor(self, state, force=False):
        """约0.04s轮询OK-WW成熟check_f_break；偏斜传感器不参与F放行。"""
        now = time.time()
        last = float(state.get('last_f_check_at', -100.0) or -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return bool(state.get('f_available', False))

        state['last_f_check_at'] = now
        try:
            available = bool(self.task.check_f_break())
        except Exception:
            available = bool(getattr(self.task, 'can_break', False))

        available = bool(available or getattr(self.task, 'can_break', False))
        state['f_available'] = available
        return available

    def _service_lucy_f_opportunity(self, state, label, f_done_key):
        """Lucy连续F机会窗：READY走成熟check_f_break；执行统一走官方self.f_break()。"""
        if state.get(f_done_key, False):
            return True

        if not self._service_f_monitor(state):
            return False

        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: F READY -> official self.f_break()'
        )
        try:
            accepted = bool(self.f_break())
        except Exception as exc:
            accepted = False
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: official self.f_break exception={exc}'
            )

        if not accepted:
            state['f_available'] = False
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: official self.f_break returned False; '
                f'keep current STEP and retry later'
            )
            return False

        accepted_at = time.time()
        state['deflection_cd_started_at'] = accepted_at
        state['f_available'] = False
        state['deflection_visual_ready'] = False
        state[f_done_key] = True
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: official F SUCCESS -> '
            f'deflection T0={accepted_at:.3f}, fixed_cd={self.DEFLECTION_CD:.2f}s'
        )
        self._service_deflection_status(state, force=True)
        return True

    def _lucy_wait_f_and_special_energy_full(self, state, label, f_done_key):
        """特殊E后的补能段；继承早期F结果，并继续F/Q机会监听直到双门完成。"""
        first_a_key = f'{label}_first_a_done'
        start_key = f'{label}_fill_started_at'
        last_a_key = f'{label}_last_a_at'

        if f_done_key not in state:
            # 仅用于异常恢复：正常路径应由前一SPECIAL_E STEP创建。
            state[f_done_key] = False
            self._reset_f_monitor(state)

        if not state.get(first_a_key, False):
            self.normal_attack()
            now = time.time()
            state[first_a_key] = True
            state[start_key] = now
            state[last_a_key] = now
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: first A INPUT_COMMITTED -> '
                f'continue F/Q opportunity window; inherited_F={bool(state.get(f_done_key, False))}'
            )
            self.sleep(0.08)
            return False

        last_log = -100.0
        while self.time_elapsed_accounting_for_freeze(state[start_key]) < 15.0:
            self.task.next_frame()
            self._service_deflection_status(state)

            f_done = self._service_lucy_f_opportunity(
                state, label=label, f_done_key=f_done_key
            )
            forte_full = bool(self.is_forte_full())

            if f_done and forte_full:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: dual gate DONE '
                    f'F=True special_energy_full=True'
                )
                for key in (
                    f_done_key, first_a_key, start_key, last_a_key,
                ):
                    state.pop(key, None)
                return True

            # 主门未完成才尝试机会Q；Q不是STEP门，不改变f_done/能量判定。
            self._try_opportunity_echo(state, f'{label}-A_FILL')

            now = time.time()
            last_a = float(state.get(last_a_key, -100.0) or -100.0)
            if now - last_a >= 0.08:
                self.normal_attack()
                state[last_a_key] = now

            if now - last_log >= 0.5:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: A-fill running '
                    f'F={bool(state.get(f_done_key, False))} '
                    f'F_ready={bool(state.get("f_available", False))} '
                    f'special_energy_full={forte_full}'
                )
                last_log = now

            self.sleep(0.03, check_combat=False)

        state[start_key] = time.time()
        self.logger.warning(
            f'[{self.FSM_VERSION}] {label}: A-fill slice timeout; keep current STEP '
            f'F={state.get(f_done_key, False)} special_energy_full={bool(self.is_forte_full())}'
        )
        return False

    def _role_name(self, char=None):
        char = self if char is None else char
        raw = str(getattr(char, 'char_name', '') or '').casefold().removeprefix('labels.')
        if raw == 'char_lucy':
            return self.ROLE_LUCY
        if raw == 'char_rebecca':
            return self.ROLE_REBECCA
        if raw in {'char_mornye', 'char_moning'}:
            return self.ROLE_MORNYE

        cls = char.__class__.__name__.casefold()
        if cls == 'lucy':
            return self.ROLE_LUCY
        if cls == 'rebecca':
            return self.ROLE_REBECCA
        if cls == 'mornye':
            return self.ROLE_MORNYE
        return char.__class__.__name__

    def _find_target_char(self, target_role):
        for char in getattr(self.task, 'chars', []):
            if char is not None and char is not self and self._role_name(char) == target_role:
                return char
        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return False

    def _read_concerto_progress(self):
        if self._raw_con_full():
            return 1.0
        try:
            value = float(self.task.get_current_con())
        except Exception:
            try:
                value = float(self.get_current_con())
            except Exception:
                return 0.0
        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return self._raw_con_full() or self._read_concerto_progress() >= self.CONCERTO_EFFECTIVE_FULL

    def _confirm_special_intro_ready(self, target_role):
        # 特殊变奏必须真的满；不足时用A补，不偷降级成普通切。
        fill_start = time.time()
        while time.time() - fill_start < self.INTRO_FILL_TIMEOUT and not self._raw_con_full():
            self.normal_attack()
            self.sleep(0.08)
            self.task.next_frame()

        start = time.time()
        full_frames = 0
        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            self.task.next_frame()
            if self._raw_con_full():
                full_frames += 1
                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'[{self.FSM_VERSION}] special intro -> {target_role}: '
                        f'raw full {full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0
            self.sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] special intro -> {target_role}: concerto full confirm timeout'
        )
        return False

    def _switch_to(self, target_role, expect_intro=None):
        """
        expect_intro=None：自然切，当前真实协奏决定普通切/变奏。
        expect_intro=False：明确普通切。
        expect_intro=True：明确特殊变奏，协奏不满则先补满，绝不偷降级。
        """
        target = self._find_target_char(target_role)
        if target is None:
            self.logger.error(f'[{self.FSM_VERSION}] target not found: {target_role}')
            return False

        if expect_intro is True:
            if not self._confirm_special_intro_ready(target_role):
                return False
            has_intro = True
        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'[{self.FSM_VERSION}] block forced-normal switch -> {target_role}: concerto full'
                )
                return False
            has_intro = False
        else:
            # 自然切：沿用忌炎轴实机经验，raw full 或 0.99 都视为满。
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = has_intro and self.is_sub_dps

        start = time.time()
        last_send = -100.0
        untrusted_hits = 0
        send_count = 0
        team_size = len([c for c in getattr(self.task, 'chars', []) if c is not None])

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.next_frame()
            try:
                in_team, current_index, count = self.task.in_team()
            except Exception:
                in_team, current_index, count = False, -1, 0

            hit = in_team and current_index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0

            if hit and (trusted or untrusted_hits >= self.SWITCH_UNTRUSTED_CONFIRM):
                self.task.in_liberation = False
                target.is_current_char = True
                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
                    self.last_outro_time = now

                self.logger.info(
                    f'[{self.FSM_VERSION}] switch ACK {self._role_name()} -> {target_role} '
                    f'intro={has_intro} trusted={trusted} sends={send_count}'
                )
                return True

            if in_team:
                self.check_combat()

            now = time.time()
            if now - last_send >= self.SWITCH_RETRY:
                self.task.send_key(target.index + 1)
                last_send = now
                send_count += 1

            self.sleep(self.SWITCH_RETRY, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] exact switch timeout -> {target_role} sends={send_count}'
        )
        return False

    def _start_handoff(
        self,
        state,
        target_role,
        next_step,
        expect_intro=None,
        preinput=False,
        existing_hold=False,
        target_hold=0.0,
        release_at=None,
        watch_rebecca_enhanced=False,
        keep_hold_after_handoff=False,
    ):
        if state.get('pending_handoff'):
            return self._resume_pending_handoff(state)

        pending = {
            'source_step': state.get('step'),
            'target_role': target_role,
            'next_step': next_step,
            'expect_intro': expect_intro,
            'preinput': bool(preinput),
            'target_hold': max(0.0, float(target_hold or 0.0)),
            'release_at': release_at,
            'watch_rebecca_enhanced': bool(watch_rebecca_enhanced),
            'keep_hold_after_handoff': bool(keep_hold_after_handoff),
            'rearm_count': 0,
            'created_at': time.time(),
        }
        state['pending_handoff'] = pending

        if preinput and not existing_hold:
            self.task.mouse_down()
            state['mouse_hold_active'] = True
            self.logger.info(
                f'[{self.FSM_VERSION}] preinput Z ARMED -> {target_role}, next={next_step}'
            )
        elif preinput and existing_hold:
            state['mouse_hold_active'] = True

        return self._resume_pending_handoff(state)

    def _resume_pending_handoff(self, state):
        pending = state.get('pending_handoff')
        if not isinstance(pending, dict):
            state.pop('pending_handoff', None)
            return False

        target_role = pending.get('target_role')
        next_step = pending.get('next_step')
        preinput = bool(pending.get('preinput'))

        target = self if self._role_name() == target_role else self._find_target_char(target_role)
        if target is None:
            self.logger.error(f'[{self.FSM_VERSION}] pending target missing: {target_role}')
            self._safe_mouse_up(state)
            return False

        # 可能切人其实已经成功，只是在提交 STEP 前异常中断。
        try:
            in_team, current_index, _ = self.task.in_team()
            already_target = bool(in_team and current_index == target.index)
        except Exception:
            already_target = bool(getattr(target, 'is_current_char', False))

        if preinput and not state.get('mouse_hold_active', False) and not already_target:
            count = int(pending.get('rearm_count', 0))
            if count < self.PREINPUT_REARM_LIMIT:
                self.task.mouse_down()
                state['mouse_hold_active'] = True
                pending['rearm_count'] = count + 1
                self.logger.warning(
                    f'[{self.FSM_VERSION}] preinput Z REARM {count + 1}/{self.PREINPUT_REARM_LIMIT} '
                    f'-> {target_role}'
                )
            else:
                pending['preinput'] = False
                preinput = False
                self.logger.error(
                    f'[{self.FSM_VERSION}] preinput rearm budget exhausted -> '
                    f'degraded switch without Z to {target_role}'
                )

        success = already_target or self._switch_to(
            target_role,
            expect_intro=pending.get('expect_intro'),
        )

        if not success:
            # 失败时绝不让鼠标永久保持按下；保留 pending，下一轮只重试 handoff。
            if state.get('mouse_hold_active', False):
                self._safe_mouse_up(state)
            return False

        if preinput and state.get('mouse_hold_active', False):
            release_at = pending.get('release_at')
            if isinstance(release_at, (int, float)):
                self._wait_wall_until(float(release_at))
            else:
                hold = float(pending.get('target_hold', 0.0) or 0.0)
                if hold > 0:
                    self.sleep(hold, check_combat=False)
                else:
                    # 至少让目标角色存在一个有效帧再松鼠标。
                    self.task.next_frame()

            # P1-S9 -> P1-S10专项：这发跨角色hold本身可能就是Rebecca强化Z。
            # 在松手前额外观察一小段mouse_forte；若见FULL，松手后必须追OFF，
            # 这样P1-S10就能知道强化Z已在入场预输入中完成，而不是继续无限Z。
            watch_rebecca = bool(
                pending.get('watch_rebecca_enhanced')
                and target_role == self.ROLE_REBECCA
            )
            seen_full = False
            if watch_rebecca:
                watch_start = time.time()
                while time.time() - watch_start < self.REBECCA_PREINPUT_FORTE_WATCH:
                    self.task.next_frame()
                    # V1.3：入场切换动画期间能量ROI可能短暂归零，不能拿它做强化Z主确认。
                    # 这里仅保留mouse_forte作为辅助观察；能量主判据从P1-S10本次Z尝试重新建基线。
                    if self.is_mouse_forte_full():
                        seen_full = True
                        self.logger.info(
                            f'[{self.FSM_VERSION}] inherited Rebecca Z: AUX mouse_forte FULL '
                            f'before release at +{time.time() - watch_start:.3f}s'
                        )
                    self.sleep(0.02, check_combat=False)

            keep_hold = bool(pending.get('keep_hold_after_handoff'))
            if keep_hold:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z KEEPING mouse DOWN on {target_role}'
                )
            else:
                self._safe_mouse_up(state)

            if watch_rebecca and not keep_hold:
                # 即使松手前没抓到FULL，也继续短暂观察；某些情况下提示会在mouse_up后才出现，
                # 只要捕获到FULL->连续OFF，就把这发入场预输入记为已消费强化Z。
                observe_start = time.time()
                off_frames = 0
                while time.time() - observe_start < 0.45:
                    self.task.next_frame()
                    full = bool(self.is_mouse_forte_full())
                    if full:
                        if not seen_full:
                            self.logger.info(
                                f'[{self.FSM_VERSION}] inherited Rebecca Z: mouse_forte FULL '
                                f'appeared after release at +{time.time() - observe_start:.3f}s'
                            )
                        seen_full = True
                        off_frames = 0
                    elif seen_full:
                        off_frames += 1
                        if off_frames >= self.REBECCA_FORTE_OFF_CONFIRM_FRAMES:
                            state['rebecca_enhanced_consumed_at'] = time.time()
                            state['rebecca_enhanced_consumed_label'] = 'Rebecca entry preinput enhanced Z'
                            self.logger.info(
                                f'[{self.FSM_VERSION}] Rebecca entry preinput enhanced Z: '
                                f'FULL->OFF consumption recorded in shared FSM state'
                            )
                            break
                    self.sleep(0.02, check_combat=False)

            if keep_hold:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z remains HELD on {target_role}'
                )
            else:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z released on {target_role} '
                    f'-> INPUT_COMMITTED'
                )

        # 两阶段提交：先写新 STEP，再清 pending。
        self._set_step(state, next_step)
        state.pop('pending_handoff', None)
        return True

    def _safe_mouse_up(self, state):
        try:
            self.task.mouse_up()
        finally:
            state['mouse_hold_active'] = False

    def _set_step(self, state, step):
        old = state.get('step')
        state['step'] = step
        state['step_instance_id'] = int(state.get('step_instance_id', 0)) + 1
        self.logger.info(
            f'[{self.FSM_VERSION}] STEP COMMIT {old} -> {step} '
            f'instance={state["step_instance_id"]}'
        )

    def _clear_five_r_fsm_state(self, clear_signature=False, reason='clear'):
        """统一清理共享FSM。对齐红绿灯轴：离开指定队伍或战斗结束时必须丢弃旧进度。"""
        state = getattr(self.task, self.STATE_KEY, None)
        if isinstance(state, dict) and state.get('mouse_hold_active'):
            self._safe_mouse_up(state)
        if hasattr(self.task, self.STATE_KEY):
            delattr(self.task, self.STATE_KEY)
        if clear_signature and hasattr(self.task, self.SIGNATURE_KEY):
            delattr(self.task, self.SIGNATURE_KEY)
        self.logger.info(f'[{self.FSM_VERSION}] FSM state cleared reason={reason}')

    def _get_fsm_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        combat_start = float(getattr(self.task, 'combat_start', 0.0) or 0.0)

        # 额外保险：BaseCombatTask重新load_chars进入一场新战斗时会刷新combat_start。
        # 若框架某次没有及时走到on_combat_end，也不允许继承上一场的STEP。
        if isinstance(state, dict):
            saved_start = float(state.get('combat_start_token', 0.0) or 0.0)
            if combat_start > 0 and saved_start > 0 and abs(combat_start - saved_start) > 0.5:
                self._clear_five_r_fsm_state(
                    clear_signature=False,
                    reason=f'new combat_start {saved_start:.3f}->{combat_start:.3f}'
                )
                state = None

        if not isinstance(state, dict) or 'step' not in state:
            state = {
                'step': self.P1_S1,
                'step_instance_id': 1,
                'pending_handoff': None,
                'mouse_hold_active': False,
                'deflection_cd_started_at': None,
                'f_available': False,
                'last_f_check_at': -100.0,
                'rebecca_enhanced_consumed_at': None,
                'rebecca_enhanced_consumed_label': None,
                'combat_start_token': combat_start,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                f'[{self.FSM_VERSION}] initialize FSM -> {self.P1_S1} '
                f'combat_start={combat_start:.3f}'
            )
        return state

    def _five_r_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            self._clear_five_r_fsm_state(clear_signature=False, reason='chars unavailable')
            return False

        signature = tuple(
            (
                str(getattr(c, 'char_name', '') or '').casefold().removeprefix('labels.'),
                getattr(c, 'index', None),
            )
            for c in chars if c is not None
        )

        roles = {self._role_name(c) for c in chars if c is not None}
        matched = len(chars) == 3 and roles == {
            self.ROLE_LUCY, self.ROLE_REBECCA, self.ROLE_MORNYE
        }

        previous = getattr(self.task, self.SIGNATURE_KEY, None)
        if signature != previous:
            self._clear_five_r_fsm_state(clear_signature=False, reason='team signature changed')
            setattr(self.task, self.SIGNATURE_KEY, signature)
            self.logger.info(
                f'[{self.FSM_VERSION}] team signature changed matched={matched}: {signature}'
            )
        elif not matched:
            # 与用户提供的红绿灯轴一致：即便signature没变，只要当前不再匹配指定三人队，旧FSM也必须清掉。
            self._clear_five_r_fsm_state(clear_signature=False, reason='team temporarily not matched')
        return matched

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if not self._five_r_team_matches():
            return super().get_switch_priority(current_char, has_intro, target_low_con)

        state = self._get_fsm_state()
        pending = state.get('pending_handoff')
        expected = (
            pending.get('target_role')
            if isinstance(pending, dict)
            else self.STEP_ACTOR.get(state.get('step'))
        )
        return SwitchPriority.MUST if self._role_name() == expected else SwitchPriority.NO

    def on_combat_end(self, chars):
        # BaseCombatTask.combat_end()只调用当前角色的on_combat_end，因此共享FSM必须在这里无条件清理。
        # 不调用Mornye内置on_combat_end，避免其战斗结束自动switch_other_char副作用。
        self._clear_five_r_fsm_state(clear_signature=True, reason='combat end')
        return None

    def _wait_wall_until(self, deadline):
        while time.time() < deadline:
            self.sleep(min(0.01, max(0.001, deadline - time.time())), check_combat=False)
