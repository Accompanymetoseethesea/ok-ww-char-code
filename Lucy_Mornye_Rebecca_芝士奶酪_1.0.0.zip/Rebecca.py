# -*- coding: utf-8 -*-
"""5R双处决 V2.6 —— Rebecca

结构对齐用户提供的红绿灯轴：
- 三个角色只共享同一份 task.five_r_double_execution_state / STEP；
- 本文件只保存 Rebecca 自己负责的 STEP 与动作模块；
- 别的角色 STEP 只通过 STEP_ACTOR 排序与精确切人，不复制对方动作代码；
- 非指定三人队时回退 OK-WW 内置 Rebecca。
- V2.6：同步共享STEP命名/版本与P1-S1参数；Rebecca动作逻辑沿用V2.5。
"""
import time

import cv2
import numpy as np

from src.Labels import Labels
from src.char.BaseChar import SwitchPriority
from src.char.Rebecca import Rebecca as BuiltinRebecca

class Rebecca(BuiltinRebecca):
    """5R双处决V2.6：共享FSM + 角色本地动作模块。"""
    FSM_VERSION = '5R双处决V2.6'

    STATE_KEY = 'five_r_double_execution_state'

    SIGNATURE_KEY = 'five_r_double_execution_signature'

    ROLE_LUCY = 'Lucy'

    ROLE_REBECCA = 'Rebecca'

    ROLE_MORNYE = 'Mornye'

    P1_S1 = 'P1-1 等自动索敌-Lucy Z0.3-闪避-续Z1.2启动挑战'

    P1_S2A = 'P1-2A Lucy自然切Rebecca'

    P1_S2B = 'P1-2B Rebecca E进CD即自然切Mornye'

    P1_S3 = 'P1-3 Mornye攒特殊Z门-R预输入Z-切Rebecca'

    P1_S4 = 'P1-4 Rebecca第二发Z-切Lucy'

    P1_S5 = 'P1-5 Lucy E1-Z0.8且0.5开始切Rebecca'

    P1_S6 = 'P1-6 Rebecca第二发Z-切Lucy'

    P1_S7 = 'P1-7 Lucy E2-Z0.8且0.5开始切Rebecca'

    P1_S8 = 'P1-8 Rebecca第二发Z-预输入Z-切Lucy'

    P1_S9 = 'P1-9 Lucy继承Z持续0.8且0.5开始切Rebecca'

    P1_S10 = 'P1-10 继承强化Z确认-协奏50%门-立即R/HMG-切Lucy'

    P1_S11 = 'P1-11 Lucy等特殊E-F/Q机会窗并释放特殊E'

    P1_S12 = 'P1-12 Lucy持续补能-F/Q机会窗-双门完成'

    P1_S13 = 'P1-13 Lucy继承预输入特殊Z-额外0.1-R1未好A等待-R1-11A-HOLD1.5-干净特殊变奏Mornye'

    P2_S1 = 'P2-1 Mornye特殊变奏-A补协奏90%-E-特殊变奏Rebecca'

    P2_S2A = 'P2-2A Rebecca特殊变奏-A落地-0.2s武器监控-手枪E进CD-预输入Z'

    P2_S2B = 'P2-2B Rebecca预输入Z完成后自然切Lucy'

    P2_S3 = 'P2-3 Lucy E1-Z0.8且0.5开始切Rebecca'

    P2_S4 = 'P2-4 Rebecca霰弹枪Z补F-实时监测F随亮随插-F后立即切Lucy'

    P2_S5 = 'P2-5 Lucy E2后干净切Rebecca'

    P2_S6 = 'P2-6 Rebecca干净切Lucy-目标侧late预输入Z'

    P2_S7 = 'P2-7 Lucy继承Z持续0.8且0.5开始切Mornye'

    P2_S8 = 'P2-8 Mornye攒特殊Z门-R后按变奏决定Rebecca入场Z'

    P2_S9 = 'P2-9 本轮强化Z记账-必要时偏斜门强化Z-协奏50%-立即R/HMG-切Lucy'

    P2_S10 = 'P2-10 Lucy等特殊E-F/Q机会窗并释放特殊E'

    P2_S11 = 'P2-11 Lucy持续补能-F/Q机会窗-双门完成'

    P2_S12 = 'P2-12 Lucy继承预输入特殊Z-额外0.1-R1未好A等待-R1-11A-HOLD1.5-干净特殊变奏Mornye'

    STEP_ACTOR = {
        P1_S1: ROLE_LUCY,
        P1_S2A: ROLE_LUCY,
        P1_S2B: ROLE_REBECCA,
        P1_S3: ROLE_MORNYE,
        P1_S4: ROLE_REBECCA,
        P1_S5: ROLE_LUCY,
        P1_S6: ROLE_REBECCA,
        P1_S7: ROLE_LUCY,
        P1_S8: ROLE_REBECCA,
        P1_S9: ROLE_LUCY,
        P1_S10: ROLE_REBECCA,
        P1_S11: ROLE_LUCY,
        P1_S12: ROLE_LUCY,
        P1_S13: ROLE_LUCY,
        P2_S1: ROLE_MORNYE,
        P2_S2A: ROLE_REBECCA,
        P2_S2B: ROLE_REBECCA,
        P2_S3: ROLE_LUCY,
        P2_S4: ROLE_REBECCA,
        P2_S5: ROLE_LUCY,
        P2_S6: ROLE_REBECCA,
        P2_S7: ROLE_LUCY,
        P2_S8: ROLE_MORNYE,
        P2_S9: ROLE_REBECCA,
        P2_S10: ROLE_LUCY,
        P2_S11: ROLE_LUCY,
        P2_S12: ROLE_LUCY,
    }

    STATE_POLL = 0.04

    ACTION_RETRY = 0.08

    SWITCH_RETRY = 0.04

    SWITCH_TIMEOUT = 6.0

    SWITCH_UNTRUSTED_CONFIRM = 2

    CONCERTO_EFFECTIVE_FULL = 0.99

    INTRO_CONFIRM_FRAMES = 3

    INTRO_CONFIRM_TIMEOUT = 1.5

    INTRO_FILL_TIMEOUT = 6.0

    P1_S1_DODGE_OFFSET = 0.30

    P1_S1_POST_DODGE_HOLD = 1.00

    P1_S1_LUCY_Z_DURATION = P1_S1_DODGE_OFFSET + P1_S1_POST_DODGE_HOLD

    # =========================================================
    # Rebecca 可手动调轴参数
    # =========================================================
    # 普通Z统一模块：所有Rebecca普通Z都通过 _rebecca_normal_z/_sequence 发送。
    # 调大：单发Z更完整但补协奏更慢；调小：单位时间更多发，但过短可能只收到输入。
    # 用户实机确认：0.40s可提速，后续版本默认沿用。
    REBECCA_NORMAL_Z_HOLD = 0.40
    REBECCA_NORMAL_Z_GAP = 0.02  # 两发普通Z之间的最小输入分离。
    # 最后一发Z松开后多久开始切人。
    # 不能用负数实现“提前切”：代码会max(0, value)，所以负数等价于0。
    # 若以后要“Z还没松手就开始切人”，应另做switch_offset模块。
    REBECCA_POST_Z_SWITCH_DELAY = 0.00

    # 固定Z数量STEP的可调参数。改大=多打一发再切；改小=更早进入下一动作。
    # 用户V1.7实机后已手动确认：这三个固定Z数量都使用2。
    # 后续版本默认保留，不再回退成1。
    P1_S4_EXTRA_Z_COUNT = 2
    P1_S6_EXTRA_Z_COUNT = 2
    P1_S8_EXTRA_Z_COUNT = 2

    # 强化Z识别/构建参数。
    REBECCA_ENHANCED_Z_MAX_HOLD = 1.50
    REBECCA_FORTE_OFF_CONFIRM_FRAMES = 2
    REBECCA_PREINPUT_FORTE_WATCH = 0.18
    REBECCA_RECENT_ENHANCED_WINDOW = 1.50

    # P1-S10 / P2-S9统一协奏门：
    # 强化Z确认后只看协奏是否>=50%；满足就立即R/HMG，不再固定等1.20s。
    P1_S10_CONCERTO_R_GATE = 0.50

    # 极短复核，避免单帧旧UI值导致误补一发Z；比V1.8更快。
    CONCERTO_RECHECK_SAMPLES = 2
    CONCERTO_RECHECK_INTERVAL = 0.03
    CONCERTO_GATE_FILL_TIMEOUT = 10.0

    # P1-S10跨角色强化Z确认：
    # P1-S8离开Rebecca前记录特殊能量条；P1-S10回场采3帧并忽略可能残留的首帧，
    # 若尾部连续两帧稳定归零，直接认定P1-S9预输入Z已经消费强化Z，避免误补普通Z。
    P1_S10_ENTRY_ENERGY_SAMPLES = 3
    P1_S10_ENTRY_ENERGY_SAMPLE_INTERVAL = 0.03

    # 全局武器状态记录：连续稳定若干帧才提交；UNKNOWN不覆盖最近一次确认值。
    REBECCA_WEAPON_STABLE_FRAMES = 3
    REBECCA_WEAPON_POLL = 0.04
    REBECCA_WEAPON_ENTRY_SETTLE = 0.15

    # E快速ACK：发送E后只要resonance进入CD，就立即认为输入已被游戏接收。
    REBECCA_E_FAST_ACK_TIMEOUT = 0.80
    REBECCA_E_FAST_ACK_POLL = 0.02

    # P2-S2A/B：E切回霰弹枪后立刻预输入Z；S2B负责把这一发Z完成后切Lucy。
    # 调大 HOLD：更保证Z完整；调小：更快切Lucy。
    P2_S2_PREINPUT_Z_HOLD = 0.60

    REBECCA_ENERGY_ROI = (1788, 1998, 2210, 2040)

    REBECCA_ENERGY_HSV_LOWER = (65, 50, 85)

    REBECCA_ENERGY_HSV_UPPER = (110, 255, 255)

    REBECCA_ENERGY_COLUMN_COVERAGE = 0.08

    REBECCA_ENERGY_PRESENT_MIN = 0.20

    REBECCA_ENERGY_EMPTY_MAX = 0.03

    REBECCA_ENERGY_DROP_FRACTION = 0.25

    REBECCA_ENERGY_EMPTY_CONFIRM_FRAMES = 3

    REBECCA_ENERGY_MIN_CONFIRM_AFTER_INPUT = 0.15

    REBECCA_ENERGY_HUD_STABLE_FRAMES = 2

    # P2-S4与Lucy双门模块共用同一套官方F判定/执行语义。
    F_CHECK_INTERVAL = 0.04

    # V2.3：Rebecca站场填充/等待窗口的soft机会Q轮询；不形成STEP/phase门。
    OPPORTUNITY_ECHO_WATCH_INTERVAL = 0.10

    # 偏斜主判据永远是F成功后的固定5.5s计时；Boss血条左侧圆圈只做辅助视觉状态。
    DEFLECTION_CD = 5.50
    DEFLECTION_VISUAL_READY_THRESHOLD = 0.90


    # V2.1偏斜视觉传感器：只采样/记录，不参与FSM决策。
    # ROI来自用户确认的Boss血条左侧圆圈；12点为0号扇区，顺时针编号。
    DEFLECTION_SENSOR_SAMPLE_INTERVAL = 0.20
    DEFLECTION_SENSOR_LOG_INTERVAL = 0.50
    DEFLECTION_SENSOR_SECTORS = 12
    DEFLECTION_SENSOR_ROI_3840 = (1176, 60, 1310, 194)
    DEFLECTION_SENSOR_INNER_RADIUS_RATIO = 0.65
    DEFLECTION_SENSOR_OUTER_RADIUS_RATIO = 0.93

    # P2-S2A独立武器监控：整个STEP每0.2s读一次实时枪型。
    P2_S2A_WEAPON_CHECK_INTERVAL = 0.20
    P2_S2A_MAX_PHASE_TIME = 6.0

    # P2-S2A E缓冲：看到PISTOL后，直到E真正进入CD前每0.10s补发一次E。
    # V1.7只发送一次，实机日志显示那次输入被特殊变奏动作锁吞掉，之后就永远不重发。
    P2_S2A_E_BUFFER_INTERVAL = 0.10
    P2_S2A_E_DOWN_TIME = 0.03

    PREINPUT_REARM_LIMIT = 3

    def do_perform(self):
        """共享FSM只保存STEP；Rebecca文件只执行属于Rebecca自己的动作模块。"""
        if not self._five_r_team_matches():
            return super().do_perform()

        state = self._get_fsm_state()
        self._service_deflection_status(state)

        # Rebecca在场时独立维护全局武器状态；该模块只记录，不擅自推进STEP。
        # 每次真正要Z之前，再用记录值做“霰弹枪保险”。
        self._service_rebecca_weapon_monitor(state)

        # 跨角色预输入/切人两阶段提交优先恢复；只恢复handoff，不重放已完成动作。
        if state.get('pending_handoff'):
            return self._resume_pending_handoff(state)

        step = state.get('step', self.P1_S1)
        expected = self.STEP_ACTOR.get(step)

        if expected != self.ROLE_REBECCA:
            return self._recover_wrong_actor(state)

        self.logger.info(
            f'[{self.FSM_VERSION}] Rebecca FSM step={step} intro={self.has_intro} '
            f'instance={state.get("step_instance_id", 0)}'
        )

        if step == self.P1_S2B:
            return self._p1_s2b(state)
        if step == self.P1_S4:
            return self._p1_s4(state)
        if step == self.P1_S6:
            return self._p1_s6(state)
        if step == self.P1_S8:
            return self._p1_s8(state)
        if step == self.P1_S10:
            return self._p1_s10(state)
        if step == self.P2_S2A:
            return self._p2_s2a(state)
        if step == self.P2_S2B:
            return self._p2_s2b(state)
        if step == self.P2_S4:
            return self._p2_s4(state)
        if step == self.P2_S6:
            return self._p2_s6(state)
        if step == self.P2_S9:
            return self._p2_s9(state)

        self.logger.error(
            f'[{self.FSM_VERSION}] Rebecca owns step={step} but has no handler; reset opening'
        )
        self._clear_five_r_fsm_state(clear_signature=False, reason='missing role handler')
        return None

    @classmethod
    def _expected_actor(cls, step):
        return cls.STEP_ACTOR.get(step)

    def _recover_wrong_actor(self, state):
        """对齐红绿灯轴：当前角色不属于当前STEP时，只切到STEP_ACTOR指定角色。"""
        step = state.get('step', self.P1_S1)
        actor = self._expected_actor(step)
        if actor and actor != self.ROLE_REBECCA:
            self.logger.warning(
                f'[{self.FSM_VERSION}] Rebecca got step={step}, expected actor={actor}; '
                f'switch to expected actor'
            )
            return self._switch_to(actor, expect_intro=None)

        self.logger.error(
            f'[{self.FSM_VERSION}] Rebecca unknown/unhandled FSM step={step}; reset opening'
        )
        self._clear_five_r_fsm_state(clear_signature=False, reason='unknown step')
        self._get_fsm_state()
        return None

    def _p1_s2b(self, state):
        """P1开场切枪：E一进入CD就立刻自然切Mornye。

        不再等武器图标额外刷新；学习红绿灯轴忌炎的“技能图标消费即ACK”思路，
        这里以resonance进入CD作为E已被游戏接收的快速确认。
        """
        if not self._rebecca_e_to_shotgun_fast_ack(
            state, label='P1-2 Rebecca pistol -> shotgun E'
        ):
            return
        self._start_handoff(state, self.ROLE_MORNYE, self.P1_S3, expect_intro=None)

    def _p1_s4(self, state):
        # 第一发由 P1-3 R 动画期间的预输入在 Rebecca 入场时自动打出。
        self.logger.info(f'[{self.FSM_VERSION}] P1-4 Rebecca auto Z inherited -> INPUT_COMMITTED')
        if not self._validate_inherited_entry_z(state, 'P1-4 entry Z'):
            return
        if not self._rebecca_normal_z_sequence('P1-4 extra Z', self.P1_S4_EXTRA_Z_COUNT):
            return
        self._rebecca_post_z_switch_settle('P1-4')
        self._start_handoff(state, self.ROLE_LUCY, self.P1_S5, expect_intro=None)

    def _p1_s6(self, state):
        self.logger.info(f'[{self.FSM_VERSION}] P1-6 Rebecca auto Z inherited -> INPUT_COMMITTED')
        if not self._validate_inherited_entry_z(state, 'P1-6 entry Z'):
            return
        if not self._rebecca_normal_z_sequence('P1-6 extra Z', self.P1_S6_EXTRA_Z_COUNT):
            return
        self._rebecca_post_z_switch_settle('P1-6')
        self._start_handoff(state, self.ROLE_LUCY, self.P1_S7, expect_intro=None)

    def _p1_s8(self, state):
        self.logger.info(f'[{self.FSM_VERSION}] P1-8 Rebecca auto Z inherited -> INPUT_COMMITTED')
        if not self._validate_inherited_entry_z(state, 'P1-8 entry Z'):
            return
        if not self._rebecca_normal_z_sequence('P1-8 extra Z', self.P1_S8_EXTRA_Z_COUNT):
            return

        # 离开Rebecca前记录特殊能量条，为P1-S10判断“跨角色预输入Z是否已是强化Z”留证据。
        self._snapshot_p1_s10_entry_energy_before(state)

        # 从这里开始按住鼠标，切到Lucy后仍保持，不在handoff完成时mouse_up。
        self._start_handoff(
            state, self.ROLE_LUCY, self.P1_S9,
            expect_intro=None,
            preinput=True,
            target_hold=0.0,
            keep_hold_after_handoff=True,
        )

    def _sample_rebecca_energy_signal(self, samples, interval, label):
        """短窗口采样Rebecca特殊能量条。"""
        values = []
        count = max(1, int(samples))
        for i in range(count):
            self.task.next_frame()
            value = self._rebecca_special_energy_signal()
            if value is not None:
                values.append(float(value))
            if i + 1 < count:
                self.sleep(interval, check_combat=False)

        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Rebecca energy samples='
            f'{",".join(f"{v:.3f}" for v in values) if values else "NONE"}'
        )
        return values

    def _snapshot_p1_s10_entry_energy_before(self, state):
        values = self._sample_rebecca_energy_signal(
            self.P1_S10_ENTRY_ENERGY_SAMPLES,
            self.P1_S10_ENTRY_ENERGY_SAMPLE_INTERVAL,
            'P1-8 before leaving Rebecca',
        )
        baseline = max(values) if values else None
        state['p1_s10_entry_energy_before'] = baseline
        if baseline is not None:
            self.logger.info(
                f'[{self.FSM_VERSION}] P1-10 entry-enhanced baseline saved={baseline:.3f}'
            )

    def _confirm_p1_s10_inherited_enhanced(self, state):
        """主判据：离场前有能量；回场后忽略首个可能残留帧，尾部连续归零。"""
        before = state.get('p1_s10_entry_energy_before')
        values = self._sample_rebecca_energy_signal(
            self.P1_S10_ENTRY_ENERGY_SAMPLES,
            self.P1_S10_ENTRY_ENERGY_SAMPLE_INTERVAL,
            'P1-10 after inherited entry Z',
        )
        if before is None or not values:
            return False

        before = float(before)
        before_present = before >= self.REBECCA_ENERGY_PRESENT_MIN

        # 实机出现过0.153 -> 0.017的HUD刷新过程；首帧可能还是旧值，
        # 因此不再用after_max判空，而看最后两帧是否稳定落到既有EMPTY阈值。
        tail = values[-2:] if len(values) >= 2 else values[-1:]
        tail_max = max(tail)
        final_value = values[-1]
        tail_empty = len(tail) >= 2 and tail_max <= self.REBECCA_ENERGY_EMPTY_MAX
        final_empty = final_value <= self.REBECCA_ENERGY_EMPTY_MAX
        strong_drop = (
            before > 0
            and final_value <= before * self.REBECCA_ENERGY_DROP_FRACTION
        )
        inherited_enhanced = bool(
            before_present and tail_empty and final_empty and strong_drop
        )

        self.logger.info(
            f'[{self.FSM_VERSION}] P1-10 inherited enhanced evidence '
            f'before={before:.3f} samples={",".join(f"{v:.3f}" for v in values)} '
            f'tail_max={tail_max:.3f} tail_empty={tail_empty} '
            f'final_empty={final_empty} strong_drop={strong_drop}'
        )

        if inherited_enhanced:
            self._mark_rebecca_enhanced_consumed(
                state, 'P1-10 inherited preinput energy tail PRESENT->ZERO'
            )
            self.logger.info(
                f'[{self.FSM_VERSION}] P1-10 inherited preinput Z = ENHANCED_Z HARD_CONFIRMED '
                f'-> no extra build Z'
            )
            return True
        return False

    def _run_rebecca_enhanced_concerto_hmg_common(self, state, phase_key, label):
        """P1-S10 / P2-S9共用核心：强化Z -> 协奏50% -> 立即R/HMG。"""
        phase = state.get(phase_key, 'enhanced_z')

        if phase == 'enhanced_z':
            if not self._recent_rebecca_enhanced_consumed(state):
                if not self._rebecca_build_and_consume_enhanced_z(deflection_gate=False):
                    return False
            state[phase_key] = 'concerto_50'
            phase = 'concerto_50'

        if phase == 'concerto_50':
            if not self._fill_concerto_with_rebecca_z(
                threshold=self.P1_S10_CONCERTO_R_GATE,
                label=f'{label} before R',
            ):
                return False
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: concerto >= '
                f'{self.P1_S10_CONCERTO_R_GATE:.2f} -> R/HMG immediately'
            )
            state[phase_key] = 'hmg'
            phase = 'hmg'

        if phase == 'hmg':
            if not self._rebecca_run_hmg():
                return False
            state[phase_key] = 'done'
            phase = 'done'

        return phase == 'done'

    def _p1_s10(self, state):
        """P1-S10：先判定跨角色预输入Z是否已是强化Z，再走50%协奏门并立即R。"""
        phase_key = 'p1_s10_phase'
        phase = state.get(phase_key, 'entry_check')

        if phase == 'entry_check':
            self.logger.info(
                f'[{self.FSM_VERSION}] P1-10 Rebecca entry auto Z inherited -> INPUT_COMMITTED'
            )
            if not self._validate_inherited_entry_z(state, 'P1-10 entry Z'):
                return

            inherited_enhanced = self._confirm_p1_s10_inherited_enhanced(state)
            state[phase_key] = 'concerto_50' if (
                inherited_enhanced or self._recent_rebecca_enhanced_consumed(state)
            ) else 'enhanced_z'

        if not self._run_rebecca_enhanced_concerto_hmg_common(
            state, phase_key=phase_key, label='P1-10'
        ):
            return

        if self._start_handoff(state, self.ROLE_LUCY, self.P1_S11, expect_intro=None):
            state.pop(phase_key, None)
            state.pop('p1_s10_entry_energy_before', None)
            self._clear_rebecca_energy_tracking(state)
        return

    def _p2_s2a(self, state):
        """特殊变奏-A落地；0.2s监控武器；PISTOL后持续缓冲E直到进入CD。

        V1.7实机日志已经证明：
        - 武器识别能正确看到 PISTOL；
        - 脚本也确实“发送过一次E”；
        - 但那一发E被特殊变奏动作锁吞掉，之后e_sent=True导致脚本不再补发，
          所以一直停在PISTOL，直到用户手动按E才进入CD。

        V1.8：
        - PISTOL识别仍是E开始缓冲的门；
        - 从PISTOL出现开始，每0.10s重新发送E；
        - 不依赖 resonance_available() 决定是否补发，因为特殊变奏动作锁期间
          这个可用性判断可能提前恢复/抖动；
        - 唯一主确认仍是：我们已经尝试过E + has_cd('resonance') == True。
        """
        phase_key = 'p2_s2a_phase'
        phase = state.get(phase_key, 'entry')

        if phase == 'entry':
            self.normal_attack()
            now = time.time()
            state['p2_s2a_started_at'] = now
            state['p2_s2a_last_weapon_check'] = -100.0
            state['p2_s2a_pistol_seen'] = False
            state['p2_s2a_e_attempted'] = False
            state['p2_s2a_last_e_send'] = -100.0
            state[phase_key] = 'monitor_e'
            phase = 'monitor_e'

        if phase == 'monitor_e':
            slice_start = time.time()
            while time.time() - slice_start < 1.5:
                self.task.next_frame()
                self._service_deflection_status(state)
                now = time.time()

                last_check = float(state.get('p2_s2a_last_weapon_check', -100.0) or -100.0)
                if now - last_check >= self.P2_S2A_WEAPON_CHECK_INTERVAL:
                    raw_weapon = self._detect_rebecca_weapon()
                    state['p2_s2a_last_weapon_check'] = now
                    self.logger.info(
                        f'[{self.FSM_VERSION}] P2-2A weapon monitor raw={raw_weapon} '
                        f'pistol_seen={state.get("p2_s2a_pistol_seen", False)} '
                        f'e_attempted={state.get("p2_s2a_e_attempted", False)}'
                    )

                    if raw_weapon == 'PISTOL':
                        state['p2_s2a_pistol_seen'] = True
                        self._set_rebecca_weapon_state(
                            state, 'PISTOL', 'P2-2A special-intro pistol observed'
                        )
                    elif raw_weapon == 'SHOTGUN' and state.get('p2_s2a_e_attempted', False):
                        self.logger.info(
                            f'[{self.FSM_VERSION}] P2-2A weapon auxiliary sees SHOTGUN after E buffer'
                        )

                pistol_seen = bool(state.get('p2_s2a_pistol_seen', False))
                e_attempted = bool(state.get('p2_s2a_e_attempted', False))

                # 主确认：必须是脚本已经尝试过E之后，技能真的进入CD。
                if e_attempted and self.has_cd('resonance'):
                    self.record_resonance_use()
                    self._set_rebecca_weapon_state(
                        state, 'SHOTGUN', 'P2-2A buffered E entered CD PRIMARY_ACK'
                    )
                    self.logger.info(
                        f'[{self.FSM_VERSION}] P2-2A PRIMARY_ACK: buffered E -> resonance CD'
                    )
                    state[phase_key] = 'arm_z'
                    phase = 'arm_z'
                    break

                # 一旦PISTOL出现，持续缓冲E；不再“只发一次然后傻等”。
                last_e = float(state.get('p2_s2a_last_e_send', -100.0) or -100.0)
                if pistol_seen and now - last_e >= self.P2_S2A_E_BUFFER_INTERVAL:
                    self.send_resonance_key(down_time=self.P2_S2A_E_DOWN_TIME)
                    state['p2_s2a_e_attempted'] = True
                    state['p2_s2a_last_e_send'] = now
                    self.logger.info(
                        f'[{self.FSM_VERSION}] P2-2A PISTOL -> buffer E '
                        f'interval={self.P2_S2A_E_BUFFER_INTERVAL:.2f}s'
                    )

                total = now - float(state.get('p2_s2a_started_at', now) or now)
                if total >= self.P2_S2A_MAX_PHASE_TIME:
                    self.logger.warning(
                        f'[{self.FSM_VERSION}] P2-2A monitor timeout '
                        f'pistol_seen={pistol_seen} e_attempted={e_attempted}; keep STEP'
                    )
                    state['p2_s2a_started_at'] = now
                    return

                self.sleep(0.02, check_combat=False)

            if phase == 'monitor_e':
                return

        if phase == 'arm_z':
            if not state.get('mouse_hold_active', False):
                self.task.mouse_down()
                state['mouse_hold_active'] = True
            state['p2_s2b_z_started_at'] = time.time()
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-2A E-CD PRIMARY_ACK -> preinput shotgun Z ARMED '
                f'hold={self.P2_S2_PREINPUT_Z_HOLD:.2f}s'
            )
            for key in (
                phase_key, 'p2_s2a_started_at', 'p2_s2a_last_weapon_check',
                'p2_s2a_pistol_seen', 'p2_s2a_e_attempted', 'p2_s2a_last_e_send',
            ):
                state.pop(key, None)
            self._set_step(state, self.P2_S2B)
            return

    def _p2_s2b(self, state):
        """P2-S2B：完成S2A已经按住的Rebecca Z，随后立即自然切Lucy。"""
        started = state.get('p2_s2b_z_started_at')
        if not isinstance(started, (int, float)):
            # 异常恢复：如果STEP已提交但HOLD丢了，重新补一发霰弹枪Z。
            if not self._ensure_rebecca_shotgun_before_z(
                state, label='P2-2B recovery weapon insurance', force_refresh=True
            ):
                return
            self.task.mouse_down()
            state['mouse_hold_active'] = True
            started = time.time()
            state['p2_s2b_z_started_at'] = started
            self.logger.warning(
                f'[{self.FSM_VERSION}] P2-2B lost inherited HOLD -> recovery mouse_down'
            )

        remaining = self.P2_S2_PREINPUT_Z_HOLD - (time.time() - float(started))
        if remaining > 0:
            self.sleep(remaining, check_combat=False)
        self.task.mouse_up()
        state['mouse_hold_active'] = False
        state.pop('p2_s2b_z_started_at', None)
        self.task.next_frame()
        self.logger.info(
            f'[{self.FSM_VERSION}] P2-2B Rebecca Z INPUT_COMMITTED -> natural switch Lucy'
        )
        self._start_handoff(state, self.ROLE_LUCY, self.P2_S3, expect_intro=None)

    def _p2_s4(self, state):
        """P2-S4：Rebecca入场Z -> 霰弹枪普通Z补F -> F成功后立即切Lucy。

        V2.5删除旧“F后固定再打一发Z”的单动作门：
        F刚成功时偏斜立刻进入5.5s CD，此时再起一发Rebecca Z存在
        “按下时普通、结算时升级强化Z”的不可撤销风险，因此F成功即离场。
        """
        phase_key = 'p2_s4_phase'
        phase = state.get(phase_key, 'entry_validate')

        if phase == 'entry_validate':
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-4 Rebecca entry auto Z inherited -> INPUT_COMMITTED'
            )
            if not self._validate_inherited_entry_z(state, 'P2-4 entry Z'):
                return
            self._reset_f_monitor(state)
            state[phase_key] = 'wait_f_with_z'
            phase = 'wait_f_with_z'

        if phase == 'wait_f_with_z':
            if not self._wait_f_with_rebecca_z(state, label='P2-4'):
                return
            state[phase_key] = 'cast_f'
            phase = 'cast_f'

        if phase == 'cast_f':
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-4: F READY -> official self.f_break()'
            )
            try:
                accepted = bool(self.f_break())
            except Exception as exc:
                accepted = False
                self.logger.warning(
                    f'[{self.FSM_VERSION}] P2-4: official self.f_break exception={exc}'
                )
            if not accepted:
                state['f_available'] = False
                self.logger.warning(
                    f'[{self.FSM_VERSION}] P2-4: official self.f_break returned False; '
                    f'return to realtime F wait'
                )
                state[phase_key] = 'wait_f_with_z'
                return

            accepted_at = time.time()
            state['deflection_cd_started_at'] = accepted_at
            state['f_available'] = False
            state['deflection_visual_ready'] = False
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-4: official F SUCCESS -> '
                f'deflection T0={accepted_at:.3f}, fixed_cd={self.DEFLECTION_CD:.2f}s; '
                f'NO post-F Rebecca Z'
            )
            self._service_deflection_status(state, force=True)
            state[phase_key] = 'handoff'
            phase = 'handoff'

        if phase == 'handoff':
            if self._start_handoff(state, self.ROLE_LUCY, self.P2_S5, expect_intro=None):
                state.pop(phase_key, None)
            return

    def _p2_s6(self, state):
        """P2-S6：Rebecca不释放Z；先干净切Lucy，再只在目标侧ARM预输入Z。

        这不是旧的source-side preinput：mouse_down发生在_switch_to已经确认Lucy是当前角色之后，
        因而Rebecca绝不会接受/消费这次Z；随后提交P2-S7，让Lucy以existing_hold=True继续轴。
        """
        state.pop('p2_s6_entry_z_suppressed', None)
        state.pop('p2_s6_enhanced_ready_before_lucy', None)
        self.logger.info(
            f'[{self.FSM_VERSION}] P2-6 Rebecca -> Lucy clean switch first; '
            f'NO Rebecca Z, target-only late preinput after Lucy ACK'
        )
        return self._target_only_late_preinput_handoff(
            state,
            target_role=self.ROLE_LUCY,
            next_step=self.P2_S7,
            expect_intro=None,
        )

    def _p2_s9(self, state):
        """P2-S9：保证“本轮强化Z已完成”，而不是强制必须在本STEP现场再打一发。

        - 若P2周期账本已经记录强化Z消费：直接进入协奏50%门，跳过偏斜等待/强化Z重建；
        - 若本轮尚未消费：才等待偏斜READY并构建/消费强化Z；
        - 然后统一进入协奏50% -> R/HMG -> Lucy。
        """
        phase_key = 'p2_s9_phase'
        phase = state.get(phase_key, 'ensure_shotgun')

        if phase == 'ensure_shotgun':
            if not self._ensure_rebecca_shotgun_before_z(
                state, label='P2-9 entry weapon insurance', force_refresh=True
            ):
                return

            if bool(state.get('p2_enhanced_z_consumed', False)):
                self.logger.info(
                    f'[{self.FSM_VERSION}] P2-9 P2-cycle enhanced Z already consumed '
                    f'label={state.get("p2_enhanced_z_consumed_label")} '
                    f'-> skip deflection wait and enhanced-Z rebuild'
                )
                state[phase_key] = 'concerto_50'
                phase = 'concerto_50'
            else:
                state[phase_key] = 'wait_deflection'
                phase = 'wait_deflection'

        # 即便STEP在等待期间发生恢复，只要账本后来变True，也立即跳过重复强化Z。
        if phase in {'wait_deflection', 'enhanced_z'} and bool(state.get('p2_enhanced_z_consumed', False)):
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-9 detects P2-cycle enhanced Z consumed during wait '
                f'-> jump concerto_50'
            )
            state[phase_key] = 'concerto_50'
            phase = 'concerto_50'

        if phase == 'wait_deflection':
            if not self._service_deflection_status(state, force=True):
                self.logger.info(
                    f'[{self.FSM_VERSION}] P2-9 DEFLECTION COOLDOWN '
                    f'remaining={self._deflection_remaining(state):.2f}s -> A only'
                )
                self.normal_attack()
                self.sleep(0.10)
                return
            state[phase_key] = 'enhanced_z'
            phase = 'enhanced_z'

        if not self._run_rebecca_enhanced_concerto_hmg_common(
            state, phase_key=phase_key, label='P2-9'
        ):
            return

        if self._start_handoff(state, self.ROLE_LUCY, self.P2_S10, expect_intro=None):
            state.pop(phase_key, None)
            state.pop('p2_s9_expected_special_intro', None)
            self._clear_rebecca_energy_tracking(state)
        return

    def _read_concerto_progress_rechecked(self, label='concerto recheck'):
        """在短窗口内连续采样协奏，取最大值，避免UI刷新延迟导致多打一发Z。"""
        values = []
        for i in range(self.CONCERTO_RECHECK_SAMPLES):
            self.task.next_frame()
            value = self._read_concerto_progress()
            values.append(value)
            if i + 1 < self.CONCERTO_RECHECK_SAMPLES:
                self.sleep(self.CONCERTO_RECHECK_INTERVAL, check_combat=False)

        best = max(values) if values else 0.0
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: concerto recheck samples='
            f'{",".join(f"{v:.3f}" for v in values)} best={best:.3f}'
        )
        return best

    def _try_opportunity_echo(self, state, label, force=False):
        """Rebecca站场机会Q：只在安全填充/等待窗口调用，不形成硬门。"""
        if not isinstance(state, dict):
            return False
        if state.get('pending_handoff') or state.get('mouse_hold_active'):
            return False

        try:
            in_team, current_index, _ = self.task.in_team()
            if not in_team or current_index != self.index:
                return False
        except Exception:
            if not getattr(self, 'is_current_char', False):
                return False

        now = time.time()
        last = float(getattr(self, '_five_r_last_opportunity_echo_watch', -100.0) or -100.0)
        if not force and now - last < self.OPPORTUNITY_ECHO_WATCH_INTERVAL:
            return False
        self._five_r_last_opportunity_echo_watch = now

        try:
            if not self.echo_available():
                return False
            result = bool(self.click_echo(time_out=0))
        except Exception as exc:
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: opportunity Q exception={exc}'
            )
            return False

        if result:
            self.logger.info(f'[{self.FSM_VERSION}] {label}: opportunity Q INPUT_COMMITTED')
        return result

    def _fill_concerto_with_rebecca_z(self, threshold, label):
        """Rebecca普通Z补协奏；硬门优先，未到门时Z间隙允许soft机会Q。"""
        state = self._get_fsm_state()
        start = time.time()
        last_log = -100.0

        while self.time_elapsed_accounting_for_freeze(start) < self.CONCERTO_GATE_FILL_TIMEOUT:
            con = self._read_concerto_progress_rechecked(label=f'{label} pre-Z')

            if con >= threshold or self._raw_con_full():
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: concerto={con:.3f} >= {threshold:.2f} '
                    f'-> gate passed, NO extra Z'
                )
                return True

            now = time.time()
            if now - last_log >= 0.5:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: concerto={con:.3f} < {threshold:.2f} '
                    f'-> Rebecca Z/Q fill'
                )
                last_log = now

            # 协奏主门未满足时才尝试Q；固定Z本体不被Q插入。
            self._try_opportunity_echo(state, f'{label}-concerto-fill')

            if not self._rebecca_normal_z(f'{label} concerto fill'):
                return False

            post = self._read_concerto_progress_rechecked(label=f'{label} post-Z')
            if post >= threshold or self._raw_con_full():
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: post-Z concerto={post:.3f} >= {threshold:.2f} '
                    f'-> stop immediately before another Z'
                )
                return True

        self.logger.warning(
            f'[{self.FSM_VERSION}] {label}: concerto did not reach {threshold:.0%} within '
            f'{self.CONCERTO_GATE_FILL_TIMEOUT:.1f}s'
        )
        return False

    def _consume_mouse_forte(self, label):
        """Rebecca强化Z统一入口：偏斜READY是硬门，然后才允许FULL->OFF消费。"""
        state = self._get_fsm_state()
        if not self._service_deflection_status(state, force=True):
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: GLOBAL DEFLECTION GUARD blocks enhanced Z '
                f'remaining={self._deflection_remaining(state):.2f}s'
            )
            return False
        if not self._ensure_rebecca_shotgun_before_z(state, label=f'{label} weapon insurance'):
            return False
        if not self.is_mouse_forte_full():
            self.logger.warning(f'[{self.FSM_VERSION}] {label}: mouse_forte not READY')
            return False
        success = bool(self.heavy_click_forte(check_fun=self.is_mouse_forte_full))
        if success:
            self.logger.info(f'[{self.FSM_VERSION}] {label}: FULL->OFF HARD_CONFIRMED')
        else:
            self.logger.warning(f'[{self.FSM_VERSION}] {label}: FULL->OFF timeout')
        return success

    def _detect_rebecca_weapon(self):
        """
        实机标定：
        特殊能量条最左端武器图标。
        绿色/青绿色手枪 -> PISTOL
        红色/粉红色霰弹枪 -> SHOTGUN
        其余 -> UNKNOWN
        """
        try:
            box = self.task.box_of_screen_scaled(
                3840, 2160,
                1596, 1942, 1812, 2038,
                name='five_r_rebecca_weapon',
                hcenter=True,
            )
            image = box.crop_frame(self.task.frame)
        except Exception:
            return 'UNKNOWN'

        if image is None or getattr(image, 'ndim', 0) < 3:
            return 'UNKNOWN'

        hsv = cv2.cvtColor(image[..., :3], cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        valid = (s > 80) & (v > 100)
        pistol = valid & (h >= 72) & (h <= 100)
        shotgun = valid & ((h <= 10) | (h >= 155))

        total = float(h.size or 1)
        pistol_ratio = float(np.count_nonzero(pistol)) / total
        shotgun_ratio = float(np.count_nonzero(shotgun)) / total

        if pistol_ratio >= 0.12 and pistol_ratio > shotgun_ratio * 1.5:
            return 'PISTOL'
        if shotgun_ratio >= 0.08 and shotgun_ratio > pistol_ratio * 1.5:
            return 'SHOTGUN'
        return 'UNKNOWN'

    def _service_rebecca_weapon_monitor(self, state):
        """全局独立武器检测：只记录PISTOL/SHOTGUN，不直接推进STEP。

        - 同一结果连续稳定 REBECCA_WEAPON_STABLE_FRAMES 帧才写入共享状态；
        - UNKNOWN只清candidate，不覆盖最近一次已确认状态；
        - 后续所有Rebecca Z都读取这份共享记录做霰弹枪保险。
        """
        observed = self._detect_rebecca_weapon()
        if observed == 'UNKNOWN':
            state['rebecca_weapon_candidate'] = 'UNKNOWN'
            state['rebecca_weapon_candidate_frames'] = 0
            return state.get('rebecca_weapon_state', 'UNKNOWN')

        candidate = state.get('rebecca_weapon_candidate')
        if candidate == observed:
            frames = int(state.get('rebecca_weapon_candidate_frames', 0)) + 1
        else:
            candidate = observed
            frames = 1

        state['rebecca_weapon_candidate'] = candidate
        state['rebecca_weapon_candidate_frames'] = frames
        if frames >= self.REBECCA_WEAPON_STABLE_FRAMES:
            previous = state.get('rebecca_weapon_state', 'UNKNOWN')
            state['rebecca_weapon_state'] = observed
            state['rebecca_weapon_updated_at'] = time.time()
            if previous != observed:
                self.logger.info(
                    f'[{self.FSM_VERSION}] Rebecca GLOBAL weapon {previous} -> {observed} '
                    f'({frames} stable frames)'
                )
        return state.get('rebecca_weapon_state', 'UNKNOWN')

    def _get_rebecca_weapon_state(self, state, refresh=False, timeout=0.0):
        """读取最近一次稳定武器状态；refresh=True时强制重新稳定采样。

        强制刷新时不会因为shared state里还留着“上一次SHOTGUN”就立刻返回；
        必须让当前画面重新连续稳定若干帧，专门防特殊变奏切枪后的旧状态残留。
        """
        if not refresh:
            return state.get('rebecca_weapon_state', 'UNKNOWN')

        start = time.time()
        state['rebecca_weapon_candidate'] = 'UNKNOWN'
        state['rebecca_weapon_candidate_frames'] = 0
        while True:
            self.task.next_frame()
            self._service_rebecca_weapon_monitor(state)
            frames = int(state.get('rebecca_weapon_candidate_frames', 0))
            candidate = state.get('rebecca_weapon_candidate', 'UNKNOWN')
            if candidate in ('PISTOL', 'SHOTGUN') and frames >= self.REBECCA_WEAPON_STABLE_FRAMES:
                return candidate
            if time.time() - start >= max(0.0, float(timeout)):
                return 'UNKNOWN'
            self.sleep(self.REBECCA_WEAPON_POLL, check_combat=False)

    def _wait_rebecca_weapon(self, timeout=1.0):
        # 兼容旧接口；底层已切换为全局稳定武器状态。
        return self._get_rebecca_weapon_state(
            self._get_fsm_state(), refresh=True, timeout=timeout
        )

    def _set_rebecca_weapon_state(self, state, weapon, reason):
        if weapon not in ('PISTOL', 'SHOTGUN'):
            return
        previous = state.get('rebecca_weapon_state', 'UNKNOWN')
        state['rebecca_weapon_state'] = weapon
        state['rebecca_weapon_candidate'] = weapon
        state['rebecca_weapon_candidate_frames'] = self.REBECCA_WEAPON_STABLE_FRAMES
        state['rebecca_weapon_updated_at'] = time.time()
        self.logger.info(
            f'[{self.FSM_VERSION}] Rebecca weapon semantic update {previous} -> {weapon} '
            f'reason={reason}'
        )

    def _rebecca_e_to_shotgun_fast_ack(self, state, label):
        """小手枪 -> E切霰弹枪；E进入CD即刻ACK并允许切人。

        学习红绿灯轴忌炎：发送E后不等完整动画、不等武器图标刷新，
        只要resonance进入CD，就说明游戏已接收E。
        """
        weapon = self._get_rebecca_weapon_state(state, refresh=True, timeout=0.25)
        if weapon == 'SHOTGUN':
            self.logger.info(f'[{self.FSM_VERSION}] {label}: already SHOTGUN -> skip E')
            return True

        start = time.time()
        last_send = -100.0
        sent = False
        while time.time() - start < self.REBECCA_E_FAST_ACK_TIMEOUT:
            self.task.next_frame()
            if sent and self.has_cd('resonance'):
                self.record_resonance_use()
                self._set_rebecca_weapon_state(state, 'SHOTGUN', f'{label} E CD ACK')
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: E entered CD -> FAST_ACK, switch may start now'
                )
                return True

            now = time.time()
            if self.resonance_available() and now - last_send >= self.ACTION_RETRY:
                self.send_resonance_key()
                sent = True
                last_send = now

            self.sleep(self.REBECCA_E_FAST_ACK_POLL, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] {label}: E input sent={sent} but CD ACK missing'
        )
        return False

    def _rebecca_ensure_shotgun(self, allow_unknown_start=False):
        # 保留旧接口，统一走全局武器保险。
        return self._ensure_rebecca_shotgun_before_z(
            self._get_fsm_state(),
            label='Rebecca ensure shotgun',
            allow_unknown=allow_unknown_start,
        )

    def _ensure_rebecca_shotgun_before_z(
        self, state, label, allow_unknown=False, force_refresh=False
    ):
        """所有Rebecca Z之前的统一霰弹枪保险。

        默认优先使用“全局已确认武器状态”，避免每发Z都重新等3帧导致补协奏变慢。
        只有入场/变奏后这种可能自动切枪的节点才传force_refresh=True重新稳定采样。
        """
        weapon = state.get('rebecca_weapon_state', 'UNKNOWN')
        if force_refresh or weapon == 'UNKNOWN':
            weapon = self._get_rebecca_weapon_state(state, refresh=True, timeout=0.35)

        if weapon == 'SHOTGUN':
            return True
        if weapon == 'PISTOL':
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: weapon=PISTOL -> E before any Z'
            )
            return self._rebecca_e_to_shotgun_fast_ack(
                state, label=f'{label} auto-E'
            )
        if allow_unknown:
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: weapon UNKNOWN but degraded path allowed'
            )
            return True

        self.logger.warning(
            f'[{self.FSM_VERSION}] {label}: weapon UNKNOWN -> block Z and recheck next call'
        )
        return False

    def _validate_inherited_entry_z(self, state, label):
        """校验“跨角色预输入自动Z”是否真的处于霰弹枪模式。

        如果Rebecca特殊变奏入场把武器切成PISTOL，那么切人前预输入的Z不能算成功：
        先E切回SHOTGUN（E进CD确认），再补一发普通Z作为替代。
        """
        weapon = self._get_rebecca_weapon_state(state, refresh=True, timeout=0.35)
        if weapon == 'SHOTGUN':
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: inherited Z accepted by mode=SHOTGUN'
            )
            return True
        if weapon == 'PISTOL':
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: inherited Z happened in PISTOL -> repair with E + Z'
            )
            if not self._rebecca_e_to_shotgun_fast_ack(
                state, label=f'{label} repair E'
            ):
                return False
            return self._rebecca_normal_z(
                f'{label} replacement Z', ensure_shotgun=False
            )
        self.logger.warning(
            f'[{self.FSM_VERSION}] {label}: weapon UNKNOWN -> cannot count inherited Z as success'
        )
        return False

    def _mark_rebecca_enhanced_consumed(self, state, label):
        now = time.time()
        state['rebecca_enhanced_consumed_at'] = now
        state['rebecca_enhanced_consumed_label'] = str(label)

        # V2.5：P2按“本轮是否已经消费过强化Z”记账，不再要求必须在P2-S9现场重打一发。
        if str(state.get('step', '')).startswith('P2-'):
            state['p2_enhanced_z_consumed'] = True
            state['p2_enhanced_z_consumed_at'] = now
            state['p2_enhanced_z_consumed_label'] = str(label)
            self.logger.info(
                f'[{self.FSM_VERSION}] P2 enhanced-Z ledger -> CONSUMED '
                f'label={label}'
            )

        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Rebecca enhanced Z CONSUMED_CONFIRMED '
            f'and consumption recorded'
        )

    def _recent_rebecca_enhanced_consumed(self, state):
        t = state.get('rebecca_enhanced_consumed_at')
        if not isinstance(t, (int, float)):
            return False
        age = time.time() - float(t)
        return 0.0 <= age <= self.REBECCA_RECENT_ENHANCED_WINDOW

    def _reset_rebecca_energy_tracking(self, state, label='reset'):
        state['rebecca_energy_track_active'] = True
        state['rebecca_energy_peak'] = 0.0
        state['rebecca_energy_last'] = 0.0
        state['rebecca_energy_present_seen'] = False
        state['rebecca_energy_present_at'] = None
        state['rebecca_energy_empty_frames'] = 0
        state['rebecca_energy_hud_frames'] = 0
        state['rebecca_energy_last_log_at'] = -100.0
        self.logger.info(f'[{self.FSM_VERSION}] Rebecca energy tracking reset: {label}')

    def _clear_rebecca_energy_tracking(self, state):
        for key in (
            'rebecca_energy_track_active',
            'rebecca_energy_peak',
            'rebecca_energy_last',
            'rebecca_energy_present_seen',
            'rebecca_energy_present_at',
            'rebecca_energy_empty_frames',
            'rebecca_energy_hud_frames',
            'rebecca_energy_last_log_at',
        ):
            state.pop(key, None)

    def _rebecca_special_energy_signal(self):
        """返回Rebecca特殊能量条0~1的活动宽度。

        用户确认的主识别位置：血条上方特殊能量条，武器图标右侧。
        有能量时为青/青蓝发光分段；强化Z消费后归零。
        """
        try:
            x0, y0, x1, y1 = self.REBECCA_ENERGY_ROI
            box = self.task.box_of_screen_scaled(
                3840, 2160, x0, y0, x1, y1,
                name='five_r_rebecca_special_energy',
                hcenter=True,
            )
            image = box.crop_frame(self.task.frame)
        except Exception:
            return None

        if image is None or getattr(image, 'ndim', 0) < 3 or image.shape[1] < 20:
            return None

        hsv = cv2.cvtColor(image[..., :3], cv2.COLOR_BGR2HSV)
        lower = np.array(self.REBECCA_ENERGY_HSV_LOWER, dtype=np.uint8)
        upper = np.array(self.REBECCA_ENERGY_HSV_UPPER, dtype=np.uint8)
        mask = cv2.inRange(hsv, lower, upper) > 0

        col_coverage = mask.mean(axis=0)
        active = col_coverage >= self.REBECCA_ENERGY_COLUMN_COVERAGE

        # 只桥接短小的UI分段缝，不跨越真正空区。
        gap_tol = max(1, int(round(len(active) * 0.02)))
        merged = active.copy()
        i = 0
        while i < len(merged):
            if merged[i]:
                i += 1
                continue
            j = i
            while j < len(merged) and not merged[j]:
                j += 1
            if i > 0 and j < len(merged) and (j - i) <= gap_tol:
                merged[i:j] = True
            i = j

        return float(np.count_nonzero(merged)) / float(len(merged) or 1)

    def _update_rebecca_energy_tracking(self, state, label, allow_zero_confirm=True, input_started_at=None):
        """Rebecca强化Z主确认：同一次尝试内的“有能量 -> 稳定归零”。

        防V1.2误判：
        1) 当前必须确实是Rebecca且武器HUD可识别；
        2) 本次tracking必须先看到有能量，不能继承上一次/换人动画的peak；
        3) 只有实际Z输入开始至少0.15s后才允许“归零”成为确认；
        4) 必须连续3帧近0。
        """
        if not state.get('rebecca_energy_track_active', False):
            self._reset_rebecca_energy_tracking(state, label=label)

        # HUD稳定门：目标角色必须是Rebecca，并且武器图标不是UNKNOWN。
        try:
            in_team, current_index, _ = self.task.in_team()
            current_ok = bool(in_team and current_index == self.index and self._role_name() == self.ROLE_REBECCA)
        except Exception:
            current_ok = bool(self._role_name() == self.ROLE_REBECCA and self.is_current_char)
        weapon = self._detect_rebecca_weapon() if current_ok else 'UNKNOWN'
        hud_ok = bool(current_ok and weapon != 'UNKNOWN')
        if hud_ok:
            state['rebecca_energy_hud_frames'] = int(state.get('rebecca_energy_hud_frames', 0)) + 1
        else:
            state['rebecca_energy_hud_frames'] = 0
            state['rebecca_energy_empty_frames'] = 0
            return False
        if int(state.get('rebecca_energy_hud_frames', 0)) < self.REBECCA_ENERGY_HUD_STABLE_FRAMES:
            return False

        signal = self._rebecca_special_energy_signal()
        if signal is None:
            return False

        peak = max(float(state.get('rebecca_energy_peak', 0.0) or 0.0), signal)
        state['rebecca_energy_peak'] = peak
        state['rebecca_energy_last'] = signal

        if signal >= self.REBECCA_ENERGY_PRESENT_MIN:
            state['rebecca_energy_present_seen'] = True
            state['rebecca_energy_present_at'] = time.time()

        present_seen = bool(state.get('rebecca_energy_present_seen', False))
        after_input = True
        if input_started_at is not None:
            after_input = (time.time() - input_started_at) >= self.REBECCA_ENERGY_MIN_CONFIRM_AFTER_INPUT

        empty_now = bool(
            allow_zero_confirm
            and after_input
            and present_seen
            and signal <= self.REBECCA_ENERGY_EMPTY_MAX
            and signal <= peak * self.REBECCA_ENERGY_DROP_FRACTION
        )

        if empty_now:
            state['rebecca_energy_empty_frames'] = int(state.get('rebecca_energy_empty_frames', 0)) + 1
        else:
            state['rebecca_energy_empty_frames'] = 0

        now = time.time()
        if now - float(state.get('rebecca_energy_last_log_at', -100.0) or -100.0) >= 0.20:
            self.logger.info(
                f'[{self.FSM_VERSION}] {label} Rebecca energy signal={signal:.3f} '
                f'peak={peak:.3f} present={present_seen} weapon={weapon} '
                f'hud_frames={state.get("rebecca_energy_hud_frames", 0)} '
                f'empty_frames={state.get("rebecca_energy_empty_frames", 0)} '
                f'zero_allowed={allow_zero_confirm and after_input}'
            )
            state['rebecca_energy_last_log_at'] = now

        if int(state.get('rebecca_energy_empty_frames', 0)) >= self.REBECCA_ENERGY_EMPTY_CONFIRM_FRAMES:
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: PRIMARY enhanced-Z confirmation: '
                f'Rebecca special energy PRESENT->ZERO '
                f'(peak={peak:.3f}, current={signal:.3f})'
            )
            self._mark_rebecca_enhanced_consumed(state, f'{label} energy PRESENT->ZERO')
            return True

        return False

    def _confirm_rebecca_forte_off_after_seen(self, state, label, timeout=0.45):
        """已经见过mouse_forte FULL后，等待连续OFF确认强化Z被消费。"""
        start = time.time()
        off_frames = 0
        while time.time() - start < timeout:
            self.task.next_frame()
            full = bool(self.is_mouse_forte_full())
            if full:
                off_frames = 0
            else:
                off_frames += 1
                if off_frames >= self.REBECCA_FORTE_OFF_CONFIRM_FRAMES:
                    self._mark_rebecca_enhanced_consumed(state, label)
                    return True
            self.sleep(0.02, check_combat=False)
        return False

    def _rebecca_normal_z(self, label, hold_duration=None, ensure_shotgun=True):
        """Rebecca普通Z统一模块。

        hold_duration决定这一发Z按住多久；默认REBECCA_NORMAL_Z_HOLD。
        ensure_shotgun=True时，Z前先读全局武器状态；若是PISTOL先E切枪。
        普通Z仍只记INPUT_COMMITTED，不伪造单发视觉HARD_ACK。
        """
        state = self._get_fsm_state()
        self._service_deflection_status(state)

        if self.is_mouse_forte_full() and not self._deflection_ready(state):
            self.logger.warning(
                f'[{self.FSM_VERSION}] {label}: GLOBAL DEFLECTION GUARD blocks Rebecca Z; '
                f'enhanced READY, remaining={self._deflection_remaining(state):.2f}s'
            )
            return False

        if ensure_shotgun and not self._ensure_rebecca_shotgun_before_z(state, label):
            return False

        duration = self.REBECCA_NORMAL_Z_HOLD if hold_duration is None else float(hold_duration)
        self.heavy_attack(duration)
        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Rebecca normal Z INPUT_COMMITTED '
            f'hold={duration:.2f}s'
        )
        return True

    def _rebecca_normal_z_sequence(self, label, count=1, hold_duration=None):
        """连续发送可调数量的Rebecca普通Z。

        count=打几发；hold_duration=每发按多久。
        后续想调“多打一发再切”时只改常量，不改动作实现。
        """
        count = max(0, int(count))
        for i in range(count):
            if not self._rebecca_normal_z(
                f'{label} {i + 1}/{count}', hold_duration=hold_duration
            ):
                return False
            if i + 1 < count and self.REBECCA_NORMAL_Z_GAP > 0:
                self.sleep(self.REBECCA_NORMAL_Z_GAP, check_combat=False)
                self.task.next_frame()
        return True

    def _rebecca_post_z_switch_settle(self, label):
        """固定Z序列结束到切人的可调间隔。默认0秒，保留给后续实机微调。"""
        delay = max(0.0, float(self.REBECCA_POST_Z_SWITCH_DELAY))
        if delay > 0:
            self.logger.info(
                f'[{self.FSM_VERSION}] {label}: wait {delay:.2f}s after Rebecca Z before switch'
            )
            self.sleep(delay, check_combat=False)
            self.task.next_frame()

    def _rebecca_build_z_watch_enhanced(self, label):
        """P1-S10构建Z：每一发Z都单独建能量基线，并先做霰弹枪保险。"""
        state = self._get_fsm_state()
        if not self._ensure_rebecca_shotgun_before_z(
            state, label=f'{label} weapon insurance'
        ):
            return 'BLOCKED_WEAPON'
        self._reset_rebecca_energy_tracking(state, label=f'{label} new-Z-attempt')

        # 给Rebecca HUD一个很短的稳定窗口；这里只建立“有能量”基线，绝不允许0直接确认。
        baseline_start = time.time()
        while time.time() - baseline_start < 0.30:
            self.task.next_frame()
            self._update_rebecca_energy_tracking(
                state, f'{label} baseline', allow_zero_confirm=False
            )
            if state.get('rebecca_energy_present_seen', False):
                break
            self.sleep(0.02, check_combat=False)

        # mouse_forte已经明确READY时，仍优先用成熟辅助方案释放；之后能量归零可作为主佐证。
        if self.is_mouse_forte_full():
            success = self._consume_mouse_forte(f'{label} enhanced-ready-before-hold')
            self.task.next_frame()
            if success:
                self._mark_rebecca_enhanced_consumed(state, f'{label} AUX mouse_forte')
                return 'ENHANCED_CONSUMED'
            return 'ENHANCED_READY_UNCONFIRMED'

        start = time.time()
        seen_full = False
        off_frames = 0
        consumed_by_mouse = False
        consumed_by_energy = False

        self.task.mouse_down()
        try:
            while time.time() - start < self.REBECCA_ENHANCED_Z_MAX_HOLD:
                self.task.next_frame()
                elapsed = time.time() - start

                if self._update_rebecca_energy_tracking(
                    state, f'{label} hold', allow_zero_confirm=True, input_started_at=start
                ):
                    consumed_by_energy = True
                    break

                full = bool(self.is_mouse_forte_full())
                if full:
                    if not seen_full:
                        self.logger.info(
                            f'[{self.FSM_VERSION}] {label}: AUX mouse_forte became FULL '
                            f'at +{elapsed:.3f}s'
                        )
                    seen_full = True
                    off_frames = 0
                elif seen_full:
                    off_frames += 1
                    if off_frames >= self.REBECCA_FORTE_OFF_CONFIRM_FRAMES:
                        consumed_by_mouse = True
                        break

                if not seen_full and elapsed >= self.REBECCA_NORMAL_Z_HOLD:
                    break
                self.sleep(0.02, check_combat=False)
        finally:
            self.task.mouse_up()
            self.sleep(0.01, check_combat=False)

        if consumed_by_energy:
            return 'ENHANCED_CONSUMED'
        if consumed_by_mouse:
            self._mark_rebecca_enhanced_consumed(state, f'{label} AUX mouse_forte')
            return 'ENHANCED_CONSUMED'

        # 松手后的技能结算窗口：仍要求同一次tracking中先见过“有能量”。
        observe_start = time.time()
        while time.time() - observe_start < 0.45:
            self.task.next_frame()
            if self._update_rebecca_energy_tracking(
                state, f'{label} post-release', allow_zero_confirm=True, input_started_at=start
            ):
                return 'ENHANCED_CONSUMED'
            self.sleep(0.02, check_combat=False)

        if seen_full:
            if self._confirm_rebecca_forte_off_after_seen(state, label):
                return 'ENHANCED_CONSUMED'
            return 'ENHANCED_READY_UNCONFIRMED'

        self.logger.info(
            f'[{self.FSM_VERSION}] {label}: Rebecca normal/build Z INPUT_COMMITTED; '
            f'no enhanced-Z hard confirmation this attempt'
        )
        return 'NORMAL_COMMITTED'

    def _rebecca_build_and_consume_enhanced_z(self, deflection_gate=False):
        state = self._get_fsm_state()
        if self._recent_rebecca_enhanced_consumed(state):
            return True

        start = time.time()
        while time.time() - start < 8.0:
            self.task.next_frame()
            if self.is_mouse_forte_full():
                if deflection_gate:
                    while not self._deflection_ready(state):
                        # 强化Z硬门被5.5s挡住时，A/Q都是安全等待动作。
                        self._try_opportunity_echo(state, 'Rebecca enhanced-Z deflection wait')
                        self.normal_attack()
                        self.sleep(0.10)
                        self.task.next_frame()
                success = self._consume_mouse_forte('Rebecca enhanced Z')
                if success:
                    self._mark_rebecca_enhanced_consumed(state, 'Rebecca enhanced Z')
                return success

            # 尚未READY，处于正常构建窗口；Q只作为soft机会技。
            self._try_opportunity_echo(state, 'Rebecca enhanced-Z build')
            result = self._rebecca_build_z_watch_enhanced('Rebecca build')
            if result == 'ENHANCED_CONSUMED':
                return True
            if result == 'BLOCKED_WEAPON':
                return False
            if result == 'ENHANCED_READY_UNCONFIRMED':
                self.task.next_frame()
                if self.is_mouse_forte_full():
                    success = self._consume_mouse_forte('Rebecca enhanced Z retry')
                    if success:
                        self._mark_rebecca_enhanced_consumed(state, 'Rebecca enhanced Z retry')
                    return success

        self.logger.warning(f'[{self.FSM_VERSION}] Rebecca enhanced Z build timeout')
        return False

    def _rebecca_run_hmg(self):
        """
        复用当前 BuiltinRebecca 的成熟 HMG 实现：
        官方逻辑要求 has_long_action2() 且 liberation_available() 后进入 perform_hmg_mode()。
        """
        start = time.time()
        while time.time() - start < 3.0:
            self.task.next_frame()
            if self.has_long_action2() and self.liberation_available():
                self.logger.info(f'[{self.FSM_VERSION}] Rebecca R/HMG -> builtin perform_hmg_mode')
                self.perform_hmg_mode()
                return True
            self.sleep(self.STATE_POLL, check_combat=False)
        self.logger.warning(
            f'[{self.FSM_VERSION}] Rebecca R/HMG gate timeout '
            f'long={bool(self.has_long_action2())} R={bool(self.liberation_available())}'
        )
        return False

    def _cast_resonance_confirmed(self, label):
        start = time.time()
        sent = False
        last_send = -100.0
        while time.time() - start < 1.2:
            self.task.next_frame()
            if sent and (self.has_cd('resonance') or not self.resonance_available()):
                self.record_resonance_use()
                self.logger.info(f'[{self.FSM_VERSION}] {label} CONFIRMED')
                return True

            now = time.time()
            if self.resonance_available() and now - last_send >= self.ACTION_RETRY:
                self.send_resonance_key()
                sent = True
                last_send = now
            self.sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(f'[{self.FSM_VERSION}] {label} timeout')
        return False

    def _reset_f_monitor(self, state):
        state['f_available'] = False
        state['last_f_check_at'] = -100.0



    def _service_f_monitor(self, state, force=False):
        """约0.04s轮询OK-WW成熟check_f_break；偏斜传感器不参与F放行。"""
        now = time.time()
        last = float(state.get('last_f_check_at', -100.0) or -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return bool(state.get('f_available', False))

        state['last_f_check_at'] = now
        try:
            available = bool(self.task.check_f_break())
        except Exception:
            available = bool(getattr(self.task, 'can_break', False))

        available = bool(available or getattr(self.task, 'can_break', False))
        state['f_available'] = available
        return available

    def _wait_f_with_rebecca_z(self, state, label, timeout=10.0):
        """P2-S4：F最高优先；普通Z/强化Z安全等待间隙允许soft机会Q。"""
        start = time.time()
        while time.time() - start < timeout:
            self.task.next_frame()
            if self._service_f_monitor(state, force=True):
                self.logger.info(f'[{self.FSM_VERSION}] {label} F AVAILABLE realtime')
                return True

            if self.is_mouse_forte_full():
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: enhanced Z READY while waiting F '
                    f'-> stop normal Z, A/Q safety until F'
                )
                self._try_opportunity_echo(state, f'{label}-enhanced-ready-wait')
                self.normal_attack()
                self.sleep(0.08)
                continue

            # F/强化Z都没到硬门时，Q作为普通Z之间的机会技。
            self._try_opportunity_echo(state, f'{label}-Z-fill')

            if not self._ensure_rebecca_shotgun_before_z(
                state, label=f'{label} realtime-Z weapon insurance'
            ):
                return False

            z_start = time.time()
            self.task.mouse_down()
            f_ready = False
            enhanced_ready = False

            try:
                while time.time() - z_start < self.REBECCA_NORMAL_Z_HOLD:
                    self.task.next_frame()

                    if self._service_f_monitor(state):
                        f_ready = True
                        break

                    if self.is_mouse_forte_full():
                        enhanced_ready = True
                        break

                    self.sleep(0.02, check_combat=False)
            finally:
                self.task.mouse_up()

            held = time.time() - z_start

            if f_ready:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: F became READY during Rebecca Z '
                    f'at +{held:.3f}s -> interrupt Z and cast F now'
                )
                return True

            if enhanced_ready:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: enhanced Z became READY during Z hold '
                    f'at +{held:.3f}s -> release and A/Q safety'
                )
                self._try_opportunity_echo(state, f'{label}-post-Z-enhanced-ready')
                self.normal_attack()
                self.sleep(0.08)
                continue

            self.logger.info(
                f'[{self.FSM_VERSION}] {label} shotgun Z fill F: '
                f'Rebecca normal Z INPUT_COMMITTED hold={held:.2f}s'
            )
            if self.REBECCA_NORMAL_Z_GAP > 0:
                self.sleep(self.REBECCA_NORMAL_Z_GAP, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] {label} wait F slice timeout; keep realtime wait phase'
        )
        return False

    def _wait_f_with_attacks(self, state, label, timeout=10.0):
        start = time.time()
        while time.time() - start < timeout:
            self.task.next_frame()
            if self._service_f_monitor(state):
                self.logger.info(f'[{self.FSM_VERSION}] {label} F AVAILABLE')
                return True
            self._try_opportunity_echo(state, f'{label}-A-wait')
            self.normal_attack()
            self.sleep(0.08)
        self.logger.warning(f'[{self.FSM_VERSION}] {label} wait F timeout')
        return False



    def _get_deflection_visual_sensor_box(self):
        """Boss血条左侧偏斜圆圈的用户确认ROI；仅用于被动采样。"""
        x1, y1, x2, y2 = self.DEFLECTION_SENSOR_ROI_3840
        return self.task.box_of_screen_scaled(
            3840, 2160, x1, y1, x2, y2,
            name='deflection_visual_sensor', hcenter=True,
        )

    def _sample_deflection_visual_raw(self):
        """
        被动采样偏斜圆圈。

        不在这里判断0~100%进度，也不产生READY/CD控制结论。
        只输出：成熟f_break_full命中 + 12个顺时针扇区的原始灰度统计，
        用下一轮实机日志标定是否能复用成熟圆环方案。
        """
        try:
            box = self._get_deflection_visual_sensor_box()
            frame = getattr(self.task, 'frame', None)
            if frame is None:
                return None
            crop = box.crop_frame(frame)
            if crop is None or crop.size == 0:
                return None

            gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape[:2]
            if h < 12 or w < 12:
                return None

            cx = (w - 1) / 2.0
            cy = (h - 1) / 2.0
            yy, xx = np.indices((h, w), dtype=np.float32)
            dx = xx - cx
            dy = yy - cy
            radius = np.sqrt(dx * dx + dy * dy)
            max_r = min(w, h) / 2.0
            annulus = (
                (radius >= max_r * self.DEFLECTION_SENSOR_INNER_RADIUS_RATIO)
                & (radius <= max_r * self.DEFLECTION_SENSOR_OUTER_RADIUS_RATIO)
            )

            # 0 rad = 12点；正方向 = 顺时针。
            angle = (np.arctan2(dx, -dy) + 2.0 * np.pi) % (2.0 * np.pi)
            sector_width = 2.0 * np.pi / float(self.DEFLECTION_SENSOR_SECTORS)
            sector_ids = np.floor(angle / sector_width).astype(np.int16)

            sector_p75 = []
            sector_mean = []
            for idx in range(self.DEFLECTION_SENSOR_SECTORS):
                vals = gray[annulus & (sector_ids == idx)]
                if vals.size == 0:
                    sector_p75.append(-1)
                    sector_mean.append(-1)
                    continue
                sector_p75.append(int(round(float(np.percentile(vals, 75)))))
                sector_mean.append(int(round(float(np.mean(vals)))))

            ring_vals = gray[annulus]
            if ring_vals.size == 0:
                return None

            try:
                ready_template = bool(
                    self.task.find_one(
                        Labels.f_break_full,
                        threshold=self.DEFLECTION_VISUAL_READY_THRESHOLD,
                    )
                )
            except Exception:
                ready_template = False

            return {
                'template_ready': ready_template,
                'sector_p75': tuple(sector_p75),
                'sector_mean': tuple(sector_mean),
                'ring_mean': float(np.mean(ring_vals)),
                'ring_p90': float(np.percentile(ring_vals, 90)),
            }
        except Exception:
            return None

    def _read_deflection_visual_progress(self, state=None):
        """测试骨架暂不把原始扇区亮度硬映射成0~1；待实机日志标定后再实现。"""
        return None

    def _service_deflection_visual_sensor(self, state, timer_ready=None, force=False):
        """
        被动偏斜视觉传感器。

        - 不改变deflection_cd_started_at；
        - 不改变5.5s主门；
        - 不提前放行强化Z；
        - 只把原始12扇区数据写入共享state并低频输出测试日志。
        """
        now = time.time()
        last_sample = float(state.get('deflection_sensor_sample_at', -100.0) or -100.0)
        if not force and now - last_sample < self.DEFLECTION_SENSOR_SAMPLE_INTERVAL:
            return state.get('deflection_sensor_latest')

        state['deflection_sensor_sample_at'] = now
        sample = self._sample_deflection_visual_raw()
        state['deflection_sensor_latest'] = sample
        if sample is None:
            return None

        state['deflection_visual_ready'] = bool(sample['template_ready'])
        if timer_ready is False:
            visual_state = 'CD_TIMER'
        elif sample['template_ready']:
            visual_state = 'F_READY_TEMPLATE'
        else:
            visual_state = 'BUILD_OR_UNKNOWN'
        state['deflection_sensor_visual_state'] = visual_state

        last_log = float(state.get('deflection_sensor_log_at', -100.0) or -100.0)
        previous_state = state.get('deflection_sensor_logged_state')
        template_changed = state.get('deflection_sensor_logged_template') != bool(sample['template_ready'])
        should_log = (
            force
            or visual_state != previous_state
            or template_changed
            or now - last_log >= self.DEFLECTION_SENSOR_LOG_INTERVAL
        )
        if should_log:
            p75 = ','.join(str(v) for v in sample['sector_p75'])
            self.logger.info(
                f'[{self.FSM_VERSION}] DEFLECTION_SENSOR raw state={visual_state} '
                f'template_ready={sample["template_ready"]} '
                f'ring_mean={sample["ring_mean"]:.1f} ring_p90={sample["ring_p90"]:.1f} '
                f'p75cw12=[{p75}]'
            )
            state['deflection_sensor_log_at'] = now
            state['deflection_sensor_logged_state'] = visual_state
            state['deflection_sensor_logged_template'] = bool(sample['template_ready'])
        return sample

    def _service_deflection_status(self, state, force=False):
        """5.5s固定CD是唯一主门；全局日志只在READY/COOLDOWN状态切换时输出。

        force只强制刷新视觉传感器，不再强制打印remaining。
        STEP自己的remaining决策日志继续保留。
        """
        ready = self._deflection_ready(state)
        current = 'READY' if ready else 'COOLDOWN'
        previous = state.get('deflection_status_last')

        self._service_deflection_visual_sensor(state, timer_ready=ready, force=force)
        visual_ready = bool(state.get('deflection_visual_ready', False))

        if current != previous:
            if ready:
                self.logger.info(
                    f'[{self.FSM_VERSION}] DEFLECTION READY by fixed {self.DEFLECTION_CD:.2f}s timer '
                    f'visual_ready={visual_ready} (aux only)'
                )
            else:
                self.logger.info(
                    f'[{self.FSM_VERSION}] DEFLECTION CD START fixed={self.DEFLECTION_CD:.2f}s '
                    f'visual_ready={visual_ready} (aux only)'
                )
            state['deflection_status_last'] = current
        return ready

    def _deflection_elapsed(self, state):
        t0 = state.get('deflection_cd_started_at')
        if not isinstance(t0, (int, float)):
            return 999.0
        return max(0.0, float(self.time_elapsed_accounting_for_freeze(t0)))

    def _deflection_ready(self, state):
        return self._deflection_elapsed(state) >= self.DEFLECTION_CD

    def _deflection_remaining(self, state):
        return max(0.0, self.DEFLECTION_CD - self._deflection_elapsed(state))

    def _role_name(self, char=None):
        char = self if char is None else char
        raw = str(getattr(char, 'char_name', '') or '').casefold().removeprefix('labels.')
        if raw == 'char_lucy':
            return self.ROLE_LUCY
        if raw == 'char_rebecca':
            return self.ROLE_REBECCA
        if raw in {'char_mornye', 'char_moning'}:
            return self.ROLE_MORNYE

        cls = char.__class__.__name__.casefold()
        if cls == 'lucy':
            return self.ROLE_LUCY
        if cls == 'rebecca':
            return self.ROLE_REBECCA
        if cls == 'mornye':
            return self.ROLE_MORNYE
        return char.__class__.__name__

    def _find_target_char(self, target_role):
        for char in getattr(self.task, 'chars', []):
            if char is not None and char is not self and self._role_name(char) == target_role:
                return char
        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return False

    def _read_concerto_progress(self):
        if self._raw_con_full():
            return 1.0
        try:
            value = float(self.task.get_current_con())
        except Exception:
            try:
                value = float(self.get_current_con())
            except Exception:
                return 0.0
        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return self._raw_con_full() or self._read_concerto_progress() >= self.CONCERTO_EFFECTIVE_FULL

    def _confirm_special_intro_ready(self, target_role):
        # 特殊变奏必须真的满；不足时用A补，不偷降级成普通切。
        fill_start = time.time()
        while time.time() - fill_start < self.INTRO_FILL_TIMEOUT and not self._raw_con_full():
            self.normal_attack()
            self.sleep(0.08)
            self.task.next_frame()

        start = time.time()
        full_frames = 0
        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            self.task.next_frame()
            if self._raw_con_full():
                full_frames += 1
                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'[{self.FSM_VERSION}] special intro -> {target_role}: '
                        f'raw full {full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0
            self.sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] special intro -> {target_role}: concerto full confirm timeout'
        )
        return False

    def _switch_to(self, target_role, expect_intro=None):
        """
        expect_intro=None：自然切，当前真实协奏决定普通切/变奏。
        expect_intro=False：明确普通切。
        expect_intro=True：明确特殊变奏，协奏不满则先补满，绝不偷降级。
        """
        target = self._find_target_char(target_role)
        if target is None:
            self.logger.error(f'[{self.FSM_VERSION}] target not found: {target_role}')
            return False

        if expect_intro is True:
            if not self._confirm_special_intro_ready(target_role):
                return False
            has_intro = True
        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'[{self.FSM_VERSION}] block forced-normal switch -> {target_role}: concerto full'
                )
                return False
            has_intro = False
        else:
            # 自然切：沿用忌炎轴实机经验，raw full 或 0.99 都视为满。
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = has_intro and self.is_sub_dps

        start = time.time()
        last_send = -100.0
        untrusted_hits = 0
        send_count = 0
        team_size = len([c for c in getattr(self.task, 'chars', []) if c is not None])

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.next_frame()
            try:
                in_team, current_index, count = self.task.in_team()
            except Exception:
                in_team, current_index, count = False, -1, 0

            hit = in_team and current_index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0

            if hit and (trusted or untrusted_hits >= self.SWITCH_UNTRUSTED_CONFIRM):
                self.task.in_liberation = False
                target.is_current_char = True
                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
                    self.last_outro_time = now

                self.logger.info(
                    f'[{self.FSM_VERSION}] switch ACK {self._role_name()} -> {target_role} '
                    f'intro={has_intro} trusted={trusted} sends={send_count}'
                )
                return True

            if in_team:
                self.check_combat()

            now = time.time()
            if now - last_send >= self.SWITCH_RETRY:
                self.task.send_key(target.index + 1)
                last_send = now
                send_count += 1

            self.sleep(self.SWITCH_RETRY, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] exact switch timeout -> {target_role} sends={send_count}'
        )
        return False

    def _target_only_late_preinput_handoff(
        self,
        state,
        target_role,
        next_step,
        expect_intro=None,
    ):
        """先完成干净切人，目标角色ACK后才mouse_down，再提交STEP。

        用于P2-S6 Rebecca -> Lucy：Rebecca侧永远不会收到Z输入，
        Lucy在成为当前角色后的第一时间拿到HOLD，并由P2-S7以existing_hold继续。
        """
        if state.get('mouse_hold_active', False):
            self.logger.warning(
                f'[{self.FSM_VERSION}] target-only late preinput found stale HOLD -> cleanup first'
            )
            self._safe_mouse_up(state)

        if not self._switch_to(target_role, expect_intro=expect_intro):
            return False

        # _switch_to返回时已经确认target是当前角色；此时再按鼠标，source Rebecca不会吃到Z。
        self.task.mouse_down()
        state['mouse_hold_active'] = True
        state['target_only_late_preinput_started_at'] = time.time()
        self.logger.info(
            f'[{self.FSM_VERSION}] target-only late preinput Z ARMED on {target_role} '
            f'AFTER target ACK -> next={next_step}'
        )
        self._set_step(state, next_step)
        return True

    def _start_handoff(
        self,
        state,
        target_role,
        next_step,
        expect_intro=None,
        preinput=False,
        existing_hold=False,
        target_hold=0.0,
        release_at=None,
        watch_rebecca_enhanced=False,
        keep_hold_after_handoff=False,
    ):
        if state.get('pending_handoff'):
            return self._resume_pending_handoff(state)

        pending = {
            'source_step': state.get('step'),
            'target_role': target_role,
            'next_step': next_step,
            'expect_intro': expect_intro,
            'preinput': bool(preinput),
            'target_hold': max(0.0, float(target_hold or 0.0)),
            'release_at': release_at,
            'watch_rebecca_enhanced': bool(watch_rebecca_enhanced),
            'keep_hold_after_handoff': bool(keep_hold_after_handoff),
            'rearm_count': 0,
            'created_at': time.time(),
        }
        state['pending_handoff'] = pending

        if preinput and not existing_hold:
            self.task.mouse_down()
            state['mouse_hold_active'] = True
            self.logger.info(
                f'[{self.FSM_VERSION}] preinput Z ARMED -> {target_role}, next={next_step}'
            )
        elif preinput and existing_hold:
            state['mouse_hold_active'] = True

        return self._resume_pending_handoff(state)

    def _resume_pending_handoff(self, state):
        pending = state.get('pending_handoff')
        if not isinstance(pending, dict):
            state.pop('pending_handoff', None)
            return False

        target_role = pending.get('target_role')
        next_step = pending.get('next_step')
        preinput = bool(pending.get('preinput'))

        target = self if self._role_name() == target_role else self._find_target_char(target_role)
        if target is None:
            self.logger.error(f'[{self.FSM_VERSION}] pending target missing: {target_role}')
            self._safe_mouse_up(state)
            return False

        # 可能切人其实已经成功，只是在提交 STEP 前异常中断。
        try:
            in_team, current_index, _ = self.task.in_team()
            already_target = bool(in_team and current_index == target.index)
        except Exception:
            already_target = bool(getattr(target, 'is_current_char', False))

        if preinput and not state.get('mouse_hold_active', False) and not already_target:
            count = int(pending.get('rearm_count', 0))
            if count < self.PREINPUT_REARM_LIMIT:
                self.task.mouse_down()
                state['mouse_hold_active'] = True
                pending['rearm_count'] = count + 1
                self.logger.warning(
                    f'[{self.FSM_VERSION}] preinput Z REARM {count + 1}/{self.PREINPUT_REARM_LIMIT} '
                    f'-> {target_role}'
                )
            else:
                pending['preinput'] = False
                preinput = False
                self.logger.error(
                    f'[{self.FSM_VERSION}] preinput rearm budget exhausted -> '
                    f'degraded switch without Z to {target_role}'
                )

        success = already_target or self._switch_to(
            target_role,
            expect_intro=pending.get('expect_intro'),
        )

        if not success:
            # 失败时绝不让鼠标永久保持按下；保留 pending，下一轮只重试 handoff。
            if state.get('mouse_hold_active', False):
                self._safe_mouse_up(state)
            return False

        if preinput and state.get('mouse_hold_active', False):
            release_at = pending.get('release_at')
            if isinstance(release_at, (int, float)):
                self._wait_wall_until(float(release_at))
            else:
                hold = float(pending.get('target_hold', 0.0) or 0.0)
                if hold > 0:
                    self.sleep(hold, check_combat=False)
                else:
                    # 至少让目标角色存在一个有效帧再松鼠标。
                    self.task.next_frame()

            # P1-S9 -> P1-S10专项：这发跨角色hold本身可能就是Rebecca强化Z。
            # 在松手前额外观察一小段mouse_forte；若见FULL，松手后必须追OFF，
            # 这样P1-S10就能知道强化Z已在入场预输入中完成，而不是继续无限Z。
            watch_rebecca = bool(
                pending.get('watch_rebecca_enhanced')
                and target_role == self.ROLE_REBECCA
            )
            seen_full = False
            if watch_rebecca:
                watch_start = time.time()
                while time.time() - watch_start < self.REBECCA_PREINPUT_FORTE_WATCH:
                    self.task.next_frame()
                    # V1.3：入场切换动画期间能量ROI可能短暂归零，不能拿它做强化Z主确认。
                    # 这里仅保留mouse_forte作为辅助观察；能量主判据从P1-S10本次Z尝试重新建基线。
                    if self.is_mouse_forte_full():
                        seen_full = True
                        self.logger.info(
                            f'[{self.FSM_VERSION}] inherited Rebecca Z: AUX mouse_forte FULL '
                            f'before release at +{time.time() - watch_start:.3f}s'
                        )
                    self.sleep(0.02, check_combat=False)

            keep_hold = bool(pending.get('keep_hold_after_handoff'))
            if keep_hold:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z KEEPING mouse DOWN on {target_role}'
                )
            else:
                self._safe_mouse_up(state)

            if watch_rebecca and not keep_hold:
                # 即使松手前没抓到FULL，也继续短暂观察；某些情况下提示会在mouse_up后才出现，
                # 只要捕获到FULL->连续OFF，就把这发入场预输入记为已消费强化Z。
                observe_start = time.time()
                off_frames = 0
                while time.time() - observe_start < 0.45:
                    self.task.next_frame()
                    full = bool(self.is_mouse_forte_full())
                    if full:
                        if not seen_full:
                            self.logger.info(
                                f'[{self.FSM_VERSION}] inherited Rebecca Z: mouse_forte FULL '
                                f'appeared after release at +{time.time() - observe_start:.3f}s'
                            )
                        seen_full = True
                        off_frames = 0
                    elif seen_full:
                        off_frames += 1
                        if off_frames >= self.REBECCA_FORTE_OFF_CONFIRM_FRAMES:
                            state['rebecca_enhanced_consumed_at'] = time.time()
                            state['rebecca_enhanced_consumed_label'] = 'Rebecca entry preinput enhanced Z'
                            self.logger.info(
                                f'[{self.FSM_VERSION}] Rebecca entry preinput enhanced Z: '
                                f'FULL->OFF consumption recorded in shared FSM state'
                            )
                            break
                    self.sleep(0.02, check_combat=False)

            if keep_hold:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z remains HELD on {target_role}'
                )
            else:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z released on {target_role} '
                    f'-> INPUT_COMMITTED'
                )

        # 两阶段提交：先写新 STEP，再清 pending。
        self._set_step(state, next_step)
        state.pop('pending_handoff', None)
        return True

    def _safe_mouse_up(self, state):
        try:
            self.task.mouse_up()
        finally:
            state['mouse_hold_active'] = False

    def _set_step(self, state, step):
        old = state.get('step')
        state['step'] = step
        state['step_instance_id'] = int(state.get('step_instance_id', 0)) + 1
        self.logger.info(
            f'[{self.FSM_VERSION}] STEP COMMIT {old} -> {step} '
            f'instance={state["step_instance_id"]}'
        )

    def _clear_five_r_fsm_state(self, clear_signature=False, reason='clear'):
        """统一清理共享FSM。对齐红绿灯轴：离开指定队伍或战斗结束时必须丢弃旧进度。"""
        state = getattr(self.task, self.STATE_KEY, None)
        if isinstance(state, dict) and state.get('mouse_hold_active'):
            self._safe_mouse_up(state)
        if hasattr(self.task, self.STATE_KEY):
            delattr(self.task, self.STATE_KEY)
        if clear_signature and hasattr(self.task, self.SIGNATURE_KEY):
            delattr(self.task, self.SIGNATURE_KEY)
        self.logger.info(f'[{self.FSM_VERSION}] FSM state cleared reason={reason}')

    def _get_fsm_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        combat_start = float(getattr(self.task, 'combat_start', 0.0) or 0.0)

        # 额外保险：BaseCombatTask重新load_chars进入一场新战斗时会刷新combat_start。
        # 若框架某次没有及时走到on_combat_end，也不允许继承上一场的STEP。
        if isinstance(state, dict):
            saved_start = float(state.get('combat_start_token', 0.0) or 0.0)
            if combat_start > 0 and saved_start > 0 and abs(combat_start - saved_start) > 0.5:
                self._clear_five_r_fsm_state(
                    clear_signature=False,
                    reason=f'new combat_start {saved_start:.3f}->{combat_start:.3f}'
                )
                state = None

        if not isinstance(state, dict) or 'step' not in state:
            state = {
                'step': self.P1_S1,
                'step_instance_id': 1,
                'pending_handoff': None,
                'mouse_hold_active': False,
                'deflection_cd_started_at': None,
                'f_available': False,
                'last_f_check_at': -100.0,
                'rebecca_enhanced_consumed_at': None,
                'rebecca_enhanced_consumed_label': None,
                'combat_start_token': combat_start,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                f'[{self.FSM_VERSION}] initialize FSM -> {self.P1_S1} '
                f'combat_start={combat_start:.3f}'
            )
        return state

    def _five_r_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            self._clear_five_r_fsm_state(clear_signature=False, reason='chars unavailable')
            return False

        signature = tuple(
            (
                str(getattr(c, 'char_name', '') or '').casefold().removeprefix('labels.'),
                getattr(c, 'index', None),
            )
            for c in chars if c is not None
        )

        roles = {self._role_name(c) for c in chars if c is not None}
        matched = len(chars) == 3 and roles == {
            self.ROLE_LUCY, self.ROLE_REBECCA, self.ROLE_MORNYE
        }

        previous = getattr(self.task, self.SIGNATURE_KEY, None)
        if signature != previous:
            self._clear_five_r_fsm_state(clear_signature=False, reason='team signature changed')
            setattr(self.task, self.SIGNATURE_KEY, signature)
            self.logger.info(
                f'[{self.FSM_VERSION}] team signature changed matched={matched}: {signature}'
            )
        elif not matched:
            # 与用户提供的红绿灯轴一致：即便signature没变，只要当前不再匹配指定三人队，旧FSM也必须清掉。
            self._clear_five_r_fsm_state(clear_signature=False, reason='team temporarily not matched')
        return matched

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if not self._five_r_team_matches():
            return super().get_switch_priority(current_char, has_intro, target_low_con)

        state = self._get_fsm_state()
        pending = state.get('pending_handoff')
        expected = (
            pending.get('target_role')
            if isinstance(pending, dict)
            else self.STEP_ACTOR.get(state.get('step'))
        )
        return SwitchPriority.MUST if self._role_name() == expected else SwitchPriority.NO

    def on_combat_end(self, chars):
        # BaseCombatTask.combat_end()只调用当前角色的on_combat_end，因此共享FSM必须在这里无条件清理。
        # 不调用Mornye内置on_combat_end，避免其战斗结束自动switch_other_char副作用。
        self._clear_five_r_fsm_state(clear_signature=True, reason='combat end')
        return None

    def _wait_wall_until(self, deadline):
        while time.time() < deadline:
            self.sleep(min(0.01, max(0.001, deadline - time.time())), check_combat=False)
