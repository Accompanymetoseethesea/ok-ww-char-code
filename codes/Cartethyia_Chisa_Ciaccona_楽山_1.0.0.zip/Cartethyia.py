import ctypes
import os
import threading
import time

import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Cartethyia import Cartethyia as NativeCartethyia


# ==================== 物理 F 键监视 ====================
# opener_blocked_by() 靠 task._f_last_press 区分"玩家按 F 重开了一局"和"战斗判定
# 抖了一下"(抖动不会有人按 F): 按过就直接放行, 不用干等 OPENER_MIN_GAP。
#
# 【为什么写在角色文件里】: src/ 下的代码每次更新会被 git 检出盖回官方版,
# configs/custom_teams/ 不受影响, 也是唯一能跟着"导出队伍"一起走的地方。
#
# 【为什么要单开一个线程】: 玩家按 F 是在战斗开始之前, 那一刻角色代码一行都没在跑。
# 也不能用 GetAsyncKeyState 的低位 —— get_switch_priority 会被框架对每个候选反复调用,
# 标志位会被前一次调用吃掉。
#
# 【为什么读得到玩家、读不到宏】: GetAsyncKeyState 读硬件键盘状态; 框架和宏发的键
# 走 PostMessage 直接投递给窗口, 不经过硬件层。
F_VK = 0x46
F_POLL_INTERVAL = 0.05
F_LOG_DEBOUNCE = 1.0
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。没装那张卡片就返回默认值(开, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # 初值取 -1 不是 0: 读取方是 `f_press > self.last_opener`, 而 last_opener 的
        # "没跑过"也是 -1, 给 0 的话开局第一次判定恒成立
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e})')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    task._f_last_press = now
                    # 框架 CombatCheck.note_f_key() 读的是低位(读一次就清、全进程共享),
                    # 本线程轮询会把它清光, 所以顺手把框架要的时间戳也写了
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


# ==================== 宏表 ====================
# 每一项 (键, 按住毫秒, 松开后到下一项的毫秒)。最后一项的间隔是 None = 宏到此结束, 接下一步。
# 键: E/Q/R 走按键设置里的技能键, SP=跳跃键, L=左键, RB=右键,
#     卡/夏/千 = 切到这个角色(按她实际所在的槽位发数字键, 编队顺序变了也不用改表)。
# 表是按 卡夏千 顺序(1卡提 2夏空 3千咲)录的; 剑切宏、循环宏原图是 千夏卡 顺序, 已把 1/3 对调。

OPENER_MACRO = (
    ('E', 100, 200), ('夏', 93, 220), ('L', 78, 220), ('L', 78, 50),
    ('E', 80, 0), ('SP', 50, 100), ('L', 63, 150), ('千', 50, 150),
    ('E', 20, 170), ('R', 50, 3680), ('L', 50, 250), ('夏', 93, 25),
    ('L', 78, 550), ('L', 78, 50), ('SP', 150, 100), ('L', 78, 50),
    ('千', 100, 150), ('L', 150, 420), ('L', 50, 150), ('夏', 93, 25),
    ('L', 150, 550), ('L', 78, 50), ('RB', 50, 0), ('L', 1100, 0),
    ('R', 0, 3725), ('千', 100, 850), ('E', 50, 50), ('卡', 100, 600),
    ('L', 150, 200), ('千', 0, 110), ('L', 10, 1050), ('L', 15, 0),
    ('卡', 5, 10), ('L', 100, 900), ('千', 100, 200), ('L', 50, 250),
    ('卡', 50, None),
)

SWORD_MACRO = (
    ('E', 15, 900), ('E', 50, 0), ('夏', 100, 200), ('L', 75, 200),
    ('L', 78, 100), ('E', 50, 0), ('千', 100, 150), ('E', 50, 350),
    ('L', 78, 50), ('卡', 50, 0), ('L', 100, 850), ('L', 50, 50),
    ('千', 100, 150), ('L', 150, 420), ('L', 50, 150), ('卡', 16, 50),
    ('L', 78, 650), ('R', 50, None),
)

LOOP_MACRO = (
    ('E', 50, 100), ('夏', 50, 900), ('L', 50, 450), ('L', 50, 150),
    ('SP', 50, 100), ('L', 250, 0), ('千', 50, 100), ('Q', 50, 0),
    ('R', 50, 3680), ('夏', 50, 50), ('E', 50, 50), ('Q', 50, 0),
    ('R', 50, 3750), ('千', 50, 850), ('E', 50, 50), ('卡', 100, 400),
    ('L', 150, 250), ('L', 125, 0), ('千', 50, 0), ('L', 50, 1010),
    ('L', 15, 0), ('卡', 25, 25), ('L', 50, 950), ('千', 100, 200),
    ('L', 50, 250), ('卡', 50, None),
)

# 宏在几处保底那里拆开, 保底按屏幕上的实际情况决定时刻, 下一段从保底结束那一刻重新起算:
#   夏空回路(只有循环轴): 按住左键到回路满过再清空才切千咲(ciac_heavy_then_switch)。
#       宏原本按住 0.25 秒就切, 视频里回路清空到切人只有 0.16 秒余量
#   千咲强化E: 按 E 之前先看到 E 图标的粉圈, 按下后粉圈灭了才切卡提(chisa_enhanced_e)
#   协奏满: 最后那下切卡提(变奏卡提)之前确认千咲协奏满(chisa_con_before_cart)
OP_SEG1 = OPENER_MACRO[:26]      # ... ('千', 100, 850)
OP_CHISA_E = OPENER_MACRO[26]    # ('E', 50, 50) 千咲强化E
OP_SEG2 = OPENER_MACRO[27:36]    # ('卡', 100, 600) ... ('L', 50, 250)
OP_LAST = OPENER_MACRO[36:]      # ('卡', 50, None) 变奏卡提
assert OPENER_MACRO[25] == ('千', 100, 850) and OP_CHISA_E == ('E', 50, 50)
assert OPENER_MACRO[35] == ('L', 50, 250) and OP_LAST == (('卡', 50, None),)

LOOP_SEG1 = LOOP_MACRO[:5]       # ... ('SP', 50, 100) 夏空跳
LOOP_SEG2 = LOOP_MACRO[6:14]     # ('千', 50, 100) ... ('千', 50, 850); 夏空那下 ('L', 250, 0) 换成回路保底
LOOP_CHISA_E = LOOP_MACRO[14]    # ('E', 50, 50) 千咲强化E
LOOP_SEG3 = LOOP_MACRO[15:25]    # ('卡', 100, 400) ... ('L', 50, 250)
LOOP_LAST = LOOP_MACRO[25:]      # ('卡', 50, None) 变奏卡提
assert LOOP_MACRO[4][0] == 'SP' and LOOP_MACRO[5] == ('L', 250, 0) and LOOP_MACRO[6][0] == '千'
assert LOOP_MACRO[13] == ('千', 50, 850) and LOOP_CHISA_E == ('E', 50, 50)
assert LOOP_MACRO[24] == ('L', 50, 250) and LOOP_LAST == (('卡', 50, None),)

# 千咲的普通 E(确认放出来, 不然回路条攒不满、后面没有强化E): 启动宏千咲第一次上场那下、剑切宏里那下
OP_CHISA_NORMAL_E = 8
SWORD_CHISA_NORMAL_E = 7
assert OPENER_MACRO[7][0] == '千' and OPENER_MACRO[8][0] == 'E'
assert SWORD_MACRO[6][0] == '千' and SWORD_MACRO[7][0] == 'E'

# 剑切宏里夏空那次上场(空中切进来): 第一下 A 是下落攻击, 第二下 A 落地后打, 这下 A 才给 1 格回路。
# 在夏空按 E 之前拆开读回路(ciac_sword_forte), 没给就接着 A
SWORD_A = SWORD_MACRO[:5]        # ... ('夏', 100, 200), ('L', 75, 200), ('L', 78, 100)
SWORD_B = SWORD_MACRO[5:]        # ('E', 50, 0) 夏空E, ('千', 100, 150) ...
SWORD_B_CHISA_NORMAL_E = SWORD_CHISA_NORMAL_E - 5
assert SWORD_MACRO[2][0] == '夏' and SWORD_A[-1] == ('L', 78, 100) and SWORD_B[0] == ('E', 50, 0)
assert SWORD_B[SWORD_B_CHISA_NORMAL_E][0] == 'E' and SWORD_B[SWORD_B_CHISA_NORMAL_E - 1][0] == '千'

# 千咲 R(演完看回路条, 短太多就当场补 E): 启动宏千咲第一次上场那下、循环宏千咲那下
OP_CHISA_R = 9
LOOP_SEG2_CHISA_R = 2
assert OPENER_MACRO[OP_CHISA_R] == ('R', 50, 3680) and OPENER_MACRO[OP_CHISA_R - 2][0] == '千'
assert LOOP_SEG2[LOOP_SEG2_CHISA_R] == ('R', 50, 3680) and LOOP_SEG2[0][0] == '千'

SWITCH_TOKENS = {'卡': 'Cartethyia', '夏': 'Ciaccona', '千': 'Chisa'}
CN_NAMES = {'Cartethyia': '卡提', 'Ciaccona': '夏空', 'Chisa': '千咲'}
# 循环宏开头(R2 之后)卡提那下 E: 给后面变奏下落用的人权剑, 读冷却确认放出去
LOOP_SEG1_CART_E = 0
assert LOOP_SEG1[LOOP_SEG1_CART_E] == ('E', 50, 100)
# 强化E 之后千咲下一次上场那下 A(后面有 1 秒空档): 在这里复查强化E 放出去没有
OP_SEG2_RECHECK = 3
LOOP_SEG3_RECHECK = 4
assert OP_SEG2[OP_SEG2_RECHECK - 1][0] == '千' and OP_SEG2[OP_SEG2_RECHECK] == ('L', 10, 1050)
assert LOOP_SEG3[LOOP_SEG3_RECHECK - 1][0] == '千' and LOOP_SEG3[LOOP_SEG3_RECHECK] == ('L', 50, 1010)


class Cartethyia(NativeCartethyia):
    """卡夏千队(卡提希娅/夏空/千咲)里的卡提希娅, 兼【整条轴的持宏者】。非本队时整套走原版。

    ================= 4R8下 这条轴 =================
    一圈 = [宏] -> 变奏段 -> 剑切宏 -> 小卡段 -> 芙段, 芙大招演完就是一圈结束。
      启动轴: 启动宏 -> ...(卡提在场开局)
      循环轴: 循环宏 -> ...(上一圈的芙大招演完, 卡提还在场, 下一次 do_perform 直接进)

    变奏段(宏最后那个数字键把卡提变奏出来):
        入场锁过了跳A 下落 -> 边A 边等 E/R 转好 -> E Q R 连按变身
        0链卡提的 E 在循环轴这里还差几秒, 必须等, 否则 E 落空、后面少打一次下落。
        等多久读技能栏的 CD 数字, 2链转得快就不等 —— 两种都不用改代码。
    剑切宏: 看到变身演出开始, 从那下 R 按下起算 3.55 秒开始放(不等 HUD 回来, 读 HUD 要晚 0.6 秒)。
        宏最后那个 R 是芙切回小卡。
    小卡段(锚在剑切宏的 R): 连A 到A4 -> 长按重击 -> 跳A 下落 -> R 变回芙
    宏里几处不照表走, 按屏幕确认了再往下(下一段从确认那一刻重新起算):
        两条轴剑切宏夏空: 按 E 之前读回路, 下落+落地A 给的那格没有就接着 A
        两条轴剑切宏最后那个 R 没切回小卡: 决意没满就补按 R, 小卡段顺延
        循环宏开头卡提E / 变奏夏空按住前 / 千咲协奏检查前: 确认放出去了、场上是对的人
        循环轴变奏夏空: 按住左键等回路满过、重击把回路清空了才松手切千咲; 一直不满就补 A / 跳A下落+A
        循环轴千咲R/夏空R: 按完没见演出就补放
        两条轴千咲强化E: 看到 E 图标粉圈再按, 粉圈灭了才切卡提
        两条轴最后切卡提: 千咲协奏满了才切
        两条轴变奏卡提: 最左剑位没亮(入场被打断)就补重击再跳A
        两条轴千咲普通E(启动宏第一次上场、剑切宏): 读到 E 冷却数字才算放出去, 没有就补按
        两条轴千咲R 演完: 回路条明显短就当场补 E(条的读数对上过才补)
        两条轴强化E 到点回路没满: 补 E 接着 A 把回路攒满再放
        两条轴 R 变回大卡之后马上按 F, 有处决就打
    芙段: A 到决意满(大招图标换掉) -> R2 -> 等演出结束
        【决意没满绝对不按 R】, 那一下是切回小卡。每下 R 之前都重新确认图标亮着。

    ================= 判据 vs 计时 =================
    宏里每一个按键都按表里的毫秒数定时发, 不读屏, 不确认切人 —— 宏就是照这个节奏录的,
    插读屏只会把后面整体推歪。宏里只在大招那几秒的空档里顺手看一眼 HUD 掉没掉(只记日志)。
    读屏的只有宏外面几格: 变身/芙大招演出开始结束(队伍 HUD)、E/R 的 CD 数字、决意满、形态。

    ================= 改之前先看 =================
    - 【启动轴和循环轴分开调】: 变奏段、剑切宏起手、小卡段两条轴都走, 可调的数拆成 O_/L_ 两档。
    - 【交棒不能落在大招演出里】: 芙大招后面一定等 HUD 回来再把控制权还给框架。
    - 【千咲是 HEALER】: 本队 Chisa.py 把 is_healer 关掉了, 否则框架开局会把她拽上场。
    - 【宏里不打处决】: 视频里没有, 切人也不走 switch_next_char, 框架不会代按 F。
    """

    # ==================== 引擎参数 ====================
    A_INTERVAL = 0.12
    MIN_KEY_HOLD = 0.010         # 表里写 0 毫秒的按键也至少按住这么久, 太短 PostMessage 会被吞
    LATE_WARN = 0.030            # 宏里单个按键发晚超过这么多就记一笔
    PROBE_MARGIN = 0.12          # 宏里读屏只在离下一个按键还有这么久的空档里做
    PROBE_MIN_GAP = 1.00         # R 之后空档超过这么久才去看 HUD
    # 循环宏里千咲 R / 夏空 R 的保底(ensure_lib_fired)。实机 05:22 那圈千咲 R 没放出来, 05:00/05:06 夏空 R 各没出过一次,
    # 宏照表往下按, 后面整段就乱了。可能是变奏入场锁输入(千咲 QTE 第48F前不响应)、切人被拒、能量没满
    LIB_CONFIRM = 0.35           # 按完 R 这么久 HUD 还在 = 没放出去。实机正常 +0.06~0.08 就掉
    LIB_RETRY_CAP = 2.00         # 补按 R 的上限, 盖过变奏入场的输入锁
    LIB_RETRY_STEP = 0.10        # 补按间隔, 中间点一下 A

    SWITCH_TIME_OUT = 2.5
    FIELD_SETTLE_TIME_OUT = 1.5
    UNTRUSTED_CONFIRM = 3

    LIB_FIRE_WINDOW = 0.6
    LIB_KEY_INTERVAL = 0.05
    LIB_READ_EVERY = 3
    HUD_UP_CAP = 0.8             # 发 R 之前等 HUD 在场的上限, 防 fire_lib 假成功

    OPENER_MIN_GAP = 60.0

    # ---- 演出 ----
    CART_TRANSFORM_ANIM = 3.40   # 变身 隐藏HUD 203F, 只当超时兜底
    FLEUR_LIB_ANIM = 5.00        # 芙大招 隐藏HUD 300F, 只当超时兜底
    ANIM_GONE_GRACE = 0.70       # 按完 R 这么久 HUD 都没掉 = 大招没放出去
    CART_LIB_RETRY_CAP = 1.50    # 变身/芙大招没出去时边点边等能量的上限

    # ---- 变奏段: 宏最后一个数字键 -> 跳A 下落 -> 等 E/R -> EQR ----
    O_INTRO_TO_JUMP = 1.20       # 数字键 -> 跳。变奏入场第53F前不响应输入; 视频循环轴量到 1.25
    L_INTRO_TO_JUMP = 1.20
    INTRO_CHECK_AT = 0.35        # 数字键按下这么久之后读一次场上是谁(只读, 不影响跳的时刻)
    JUMP_HOLD = 0.05
    JUMP_TO_AIR_A = 0.10         # 跳 -> 空中A(出下落攻击)
    AIR_A_HOLD = 0.06
    AIR_A_RETRY = 0.14           # 第一下没出下落时隔这么久再补一下, 已经在下落里的话这下被吞
    O_JUMP_TO_LANDED = 0.75      # 跳 -> 下落落地。下落第9F吃剑、同时 E 冷却减 3 秒左右(视频), 所以落地后才读 CD
    L_JUMP_TO_LANDED = 0.75
    EQR_WAIT_CAP = 7.0           # 等 E/R 转好的上限, 到了照按
    EQR_AFTER = 0.05             # 预测转好之后再等这么久才按 E。读数 0.1 秒一格, 读到 0.0 时可能还剩几十毫秒,
                                 # 按早了 E 就落空(干跑抓到过还剩 0.04 就按了)
    EQR_NO_CLICK = 0.25          # 预测转好前这么久停止点A, 免得 E 按在普攻起手里
    CD_POLL_FAR = 0.30           # 离转好还远时多久读一次 CD(OCR 不便宜)
    CD_POLL_NEAR = 0.10
    CD_ZERO_CONFIRM = 2          # 没读到过正数时, 连读到几次 0 才算真的转好了(防特效挡住数字)
    EQR_E_HOLD = 0.05            # E/Q/R 的按法照循环宏里夏空那一下: E 50/50 Q 50/0 R 50
    EQR_E_TAPS = 2               # E 按两下: 第一下要是还差一丝冷却, 第二下补上; 已经放出去的话第二下是空操作
    EQR_E_TAP_GAP = 0.03
    EQR_E_GAP = 0.05
    EQR_Q_HOLD = 0.05
    EQR_Q_GAP = 0.00
    EQR_R_HOLD = 0.05

    # ---- 剑切宏起手 ----
    # 从变身那下 R 按下起算, 不等 HUD 回来: 实机日志 R -> 读到 HUD 回来 4.03 秒, 比帧表 隐藏HUD 203F(3.38) 晚 0.6,
    # 那是检测延迟(HUD 渐显), 用户报"R1 之后衔接慢"就是这一段。视频人手 R -> 剑切第一个 E 约 3.75。
    # 帧表 无敌 266F 比隐藏HUD 长, 输入到底哪一帧放开没写, 所以前面再抢按两下 E 兜底
    O_R1_TO_SWORD = 3.55
    L_R1_TO_SWORD = 3.55
    SWORD_E_PREPRESS = (0.20, 0.10)  # 剑切宏起点前这么久各抢按一下 E。先生效的那下就是芙 E1, 后面的落在 E1 里被丢掉;
                                     # 宏里第二个 E 在起点 +0.915, 离最早那下 1.115 秒, 仍在 E1 派生55F 之后
    SWORD_E_PREPRESS_HOLD = 0.015
    R1_HUD_PROBE = 0.35          # 剑切宏起点前这么久读一次 HUD 在不在(只记日志, 调 R1_TO_SWORD 用)
    SWORD_AFTER_HUD_RETRY = 0.05  # 变身是补按出来的(按下时刻不准)时, 退回"HUD 回来 -> 剑切宏"

    # ---- 小卡段: 全部从剑切宏最后那个 R(芙切回小卡)按下算起 ----
    # 视频两轮: 下落出手 +3.87 / +3.80, R 变回芙 +4.47 / +4.30; 卡夏风实机调过的同一串(A到A4、长按1.03、松手0.20跳)也落在这里
    O_SMALL_A_FROM = 0.10        # 这之后开始连点(R 本身就是小卡 A2)
    L_SMALL_A_FROM = 0.10
    O_SMALL_HOLD_AT = 2.40       # 开始长按(A4 里按住, 收招自动接重击)
    L_SMALL_HOLD_AT = 2.40
    O_SMALL_HOLD_UP = 3.45       # 松手(重击聚怪29F之后松手不影响爆发)
    L_SMALL_HOLD_UP = 3.45
    O_SMALL_JUMP_AT = 3.62       # 跳(取消重击后摇)
    L_SMALL_JUMP_AT = 3.62
    O_SMALL_R_AT = 4.30          # 开始按 R 变回芙
    L_SMALL_R_AT = 4.30
    SMALL_FORM_PROBE = 0.60      # 剑切宏的 R 按下这么久读一次形态。还是芙 = 那下 R 没生效(实机被控时出现过)
    SWORD_R_FIX_CAP = 0.60       # 补按 R 之后这么久内读到小卡就接着打小卡段(从补按那下重新起算), 读不到才直接走芙段
    # R 变回芙: 每次按之前先读形态, 已经是芙就不按; 还是小卡隔 SMALL_R_RETRY 再补。
    # 实机 16 圈里 15 圈第一下就变了(读到芙 <0.1 秒); 04:47 那圈连按 4 下(间隔 0.1)都没变,
    # 旧代码接着在小卡上等决意 A 了十几秒 —— 用户报的"小卡卡住一直重复"
    SMALL_R_CAP = 2.00           # 这么久还是小卡就放弃这一圈(不进芙段), 下一次 do_perform 从循环宏重来
    SMALL_R_RETRY = 0.45         # 补按间隔。读形态只要 0.1 秒, 这么久还是小卡说明上一下确实没生效, 补按不会把芙切回去
    SMALL_R_MAX = 4
    FORM_WATCH_EVERY = 0.30      # 芙段等决意时多久看一眼形态
    FORM_SMALL_STREAK = 2        # 连着几次看到小卡就停止等决意(小卡永远 A 不满决意)

    # ---- 循环轴: 变奏夏空 跳 -> 按住左键 -> 回路满 -> 重击清空回路 -> 切千咲 ----
    # 视频(以切夏空为 0): 回路满 +1.76, 按左键 +1.80, 回路清空 +1.89, 宏切千咲 +2.05
    L_CIAC_JUMP_TO_HOLD = 0.15   # 跳 -> 按住左键(宏里的值)
    L_CIAC_HEAVY_CAP = 4.50      # 总上限(含补回路), 到了照样松手切人, 不把整圈卡住
    # 回路缺一格就一直不满: 按住这么久还没见满就松手补。夏空的回路是【下落攻击之后再 A 一下】才给(用户 2026-09-17),
    # 所以只补下落没用, 要补那下 A: 第一次先点 A(按住那下已经在空中打过下落了), 还不满再补 跳A下落 + 落地A。
    # 实机正常时回路满在按住后 +0.02, 最慢一次 +0.83; 缺格那两圈 1.6 秒都没满过
    L_CIAC_FALL_WAIT = 1.00
    L_CIAC_FIX_WAIT = 0.70       # 每次补完等这么久看满没满
    L_CIAC_FALL_FIXES = 2
    L_CIAC_FIX_A_GAP = 0.15      # 补 A: 点两下, 隔这么久
    L_CIAC_FIX_AIR_A = (0.10, 0.24)  # 补跳A下落: 起跳后这两个时刻各点一下
    L_CIAC_FIX_LAND_A = 0.65     # 补跳A下落: 起跳后这么久(落地)再点一下, 这下才给回路
    # ---- 剑切宏里夏空那次上场(两条轴): 下落攻击 + 落地 A 才给 1 格回路 ----
    # 大体型怪下落时间不固定, 宏里第二下 A 按在下落里被吞, 夏空带着 0 格走, 后面变奏夏空就少一格、重击出不来
    CIAC_SWORD_CHECK_LEAD = 0.05  # 宏里夏空按 E 之前这么久读一次回路格数
    CIAC_SWORD_GRACE = 0.15      # 读到 0 格先不点 A, 再读这么久: 实机每圈都是 0.1 秒后回路自己到(那下 A 给回路比按 E 晚一点)
    CIAC_SWORD_FIX_CAP = 1.50    # 读到 0 格就接着点 A(落地之后那下给回路), 读到 1 格马上按 E 往下走, 最多这么久
    CIAC_SWORD_A_EVERY = 0.15
    CIAC_SWORD_READ_EVERY = 0.10
    L_CIAC_REGRIP = 0.25         # 回路满了这么久还没清空 = 这次按住没触发强化重击(空中按下去的), 松开重按一次。视频按下到清空 0.09
    L_CIAC_CLEAR_TO_SWITCH = 0.0  # 回路清空 -> 切千咲。重击的聚怪和爆炸是脱手自己生成的, 切走不丢; 真丢伤害再往上加
    CIAC_CLEAR_CONFIRM = 2       # 连着几帧读不到回路满才算清空(特效闪一帧不算)

    # ---- 千咲强化E(两条轴): 宏里切千咲之后那下 E ----
    # 判据是 E 图标的粉圈: 残响1满、在地面时解锁 E2(强化E), 图标是锯片带粉圈; 放出去之后残响1开始掉, 图标变回三角。
    # 视频量的: 粉圈在切千咲后 +0.43 出现, 环上粉色占比 0.8~0.9, 没有强化E 时 0.00
    CHISA_RING_FROM = 0.30       # 切千咲之后这么久才开始读(前几帧技能栏还是上一个人的)
    CHISA_RING_MIN = 0.10        # E 图标框(外扩 20%)里粉色占比。视频按同样的框量: 有粉圈 0.17~0.46, 没有 0.00~0.03, 红色特效最多 0.05
    CHISA_RING_WAIT = 0.60       # 到了宏里按 E 的时刻还没见粉圈就再等这么久(不按键); 还不见就按一下照原节奏走
    # 按下强化E 之后不在原地等确认: 粉圈和白框都要等回路条掉下去(实机约 0.46 秒)才灭, 旧版每圈因此多等 0.37 秒、
    # 还多按一下 E。改成照宏的节奏切走, 千咲下一次上场(宏里约 1 秒后)再看: 条还满着 = 刚才那下被吞了, 当场补按。
    # 放出去的话 1 秒后残响1 已经掉了两成多(每 0.2 秒 -8), 不会误判
    CHISA_RECHECK_AT = 0.50      # 千咲下一次上场、宏里那下 A 之后这么久复查(上场后粉圈/白框要 0.33~0.45 秒才亮, 太早读会当成没满)
    CHISA_FILL_CAP = 3.00        # 到点回路条(残响1)还没满: 补一下 E 接着 A 攒满, 最多这么久。1.8 秒时实机两圈都没攒出来
    # ---- 千咲 R 演完的回路条(两条轴) ----
    # 视频: 千咲 R 刚演完时条大概八九成满、条尾圆环还没亮, 剩下一截是她在场下补满的(下次上场就满了)。
    # 所以这里不能拿"满"判, 只在条明显短的时候当场补 E(用户: 正常 R 后不需要那下 E)。
    # 条的位置是从剑位标注推的, 07:21 的排查截图(2560x1440)里条正好落在框里, 读数可信
    CHISA_BAR_LOW = 0.55         # R 演完条短于这个才补 E。实机正常圈读 0.68~0.77, 07:21 那圈到强化E 时还差一点没满
    CHISA_BAR_FULL = 0.97        # 强化E 那里条读到这个也算满(粉圈读不到时的第二判据, 读数对上过才用)
    CHISA_BAR_CALIB = 0.85       # 看到粉圈时条读到这个以上, 就认为条的读数可信
    CHISA_TOPUP_LATE = 0.30      # 等 R 演完(HUD 回来)最多比宏里下一个按键晚这么久, 再晚就不看了
    # ---- 排查截图 ----
    KXQ_SNAPSHOT = False         # 排查用: 千咲回路条补不满时存一张底部 HUD 小图到 logs/kxq_debug。2026-09-17 定版已关
    KXQ_SNAPSHOT_MAX = 6         # 每场战斗最多存几张
    # ---- 千咲普通E(两条轴): 启动宏千咲第一次上场那下 E、剑切宏里那下 E ----
    # 视频: 按下后技能栏 E 上出现冷却数字(12.0)。在下一个按键之前读到数字就算放出去, 读不到补按, 后面整段顺延
    CHISA_E_CD_MIN = 0.5         # E 冷却读数超过这个 = 放出去了
    CHISA_E_READ_FROM = 0.06     # 按下后这么久开始读(数字要过一两帧才出来)
    CHISA_NORMAL_E_RETRY = 0.20  # 按下这么久还没读到数字就补按
    CHISA_NORMAL_E_CAP = 0.90    # 最多等这么久, 读不到也照走
    # ---- 协奏满才切卡提(两条轴): 宏最后那下切卡提 ----
    CHISA_CON_CAP = 2.50         # 协奏没满就接着 A, 到上限照切(不然整圈卡死)
    # ---- 变奏卡提的第一把剑(两条轴) ----
    # 最左剑位(异权剑)是变奏入场那一下给的(帧表 QTE 第65F), 视频切卡提后 1.2 秒亮; 被怪打断就不给, 要补一发重击。
    # 亮蓝色占比(框用框架标注 forte_cartethyia_sword1 外扩 15%)
    SWORD1_POLL_FROM = 0.50
    SWORD1_CAP = 1.80            # 切卡提之后这么久还灰 = 被打断了
    SWORD1_BLUE = 0.30           # 视频按同样的框量: 亮 0.54~0.81, 变奏入场期间灰 0.00~0.09(别人的回路条偶尔 0.22, 那时不读)
    SWORD1_CONFIRM = 2
    CART_HEAVY_CAP = 1.60        # 补重击按住的上限(地面重击-异权剑 发生56F), 剑位亮了就松手
    CART_HEAVY_TRIES = 2         # 补重击又被打断就再来一次
    CART_HEAVY_TO_JUMP = 0.20    # 补重击松手 -> 跳(卡夏风实机调过的数)
    # ---- 处决(两条轴): R 变回大卡之后马上打 ----
    USE_F_BREAK = True           # 改成 False 就不按
    BREAK_WINDOW = 0.35          # R 变回大卡之后马上按 F: 这么久里每 BREAK_EVERY 按一下, 照样点 A; HUD 掉了 = 处决演出, 等演完接着打
    BREAK_EVERY = 0.10           # 变芙那下形态切换有动画, 单按一下可能被吞, 所以多按几下盖住
    F_ANIM_TIME_OUT = 5.0

    # ---- 芙段 ----
    # 【决意没满绝对不按 R】: 芙 + 决意<120 时 R 是切回小卡。旧版等 5 秒没满就照按, 实机 04:11 那圈就这么被切回小卡了
    FLEUR_R2_CAP = 20.0          # A 到决意满的总上限。到了也不按 R, 交给下一圈开头的 recover_from_fleur 接着 A
    R2_PRESS_TRIES = 3           # 图标亮着时最多按几下 R, 每下之前重新确认图标还亮着
    R2_PRESS_WATCH = 0.35        # 按一下 R 之后看这么久 HUD 掉没掉(实机 R2 出手到读到 HUD 掉约 0.15)
    LOOP_AFTER_R2 = 0.30         # 芙大招 HUD 回来 -> 循环宏第一个 E 的最短间隔。视频人手是 0.4~0.9

    # ==================== 生命周期 ====================

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.held = set()
        self.last_r2_back = 0.0
        self.r2_owed = False
        self.chisa_bar_trusted = True
        self.chisa_e2_recheck = False
        self.snapshots = 0
        self.macro_yield_logged = 0.0

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        self.cur = None
        self.r2_owed = False
        self.snapshots = 0
        start_f_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_kxq_cycle(self) -> bool:
        team_members = 0
        for char in self.task.chars:
            if char is not None and char.name in {'Ciaccona', 'Chisa'}:
                team_members += 1
        return team_members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。"""
        if not self.is_in_kxq_cycle:
            return 'team is not cartethyia/chisa/ciaccona'
        if not self.opener_armed:
            return 'already armed-down (ran once this combat)'
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 时间轴记录 ====================

    def macro_start(self):
        self.macro_t0 = time.perf_counter()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.perf_counter() - self.macro_t0:.2f}')

    def macro_timeline(self):
        return ' '.join(self.macro_marks)

    # ==================== 定时原语 ====================

    def check_enabled(self):
        self.task.executor.check_enabled(check_pause=False)

    def sleep_until(self, target):
        """睡到 perf_counter 的某个时刻。长等待里顺手检查任务有没有被关掉。"""
        while True:
            left = target - time.perf_counter()
            if left <= 0:
                return
            if left > 0.06:
                time.sleep(min(0.05, left - 0.02))
                self.check_enabled()
            else:
                time.sleep(left)

    def macro_wait(self, sec):
        self.sleep_until(time.perf_counter() + max(0.0, sec))

    def center(self):
        return self.task.width_of_screen(0.5), self.task.height_of_screen(0.5)

    def key_of(self, token):
        if token == 'E':
            return self.get_resonance_key()
        if token == 'Q':
            return self.get_echo_key()
        if token == 'R':
            return self.get_liberation_key()
        if token == 'SP':
            return self.task.key_config.get('Jump Key', 'space')
        if token == 'F':
            return 'f'
        return None

    def press_down(self, token, char_by_token):
        if token == 'L':
            x, y = self.center()
            self.task.mouse_down(x, y)
        elif token == 'RB':
            x, y = self.center()
            self.task.mouse_down(x, y, key='right')
        elif token in SWITCH_TOKENS:
            target = char_by_token[token]
            self.task.send_key_down(str(target.index + 1))
            if target is not self.cur:
                self.handoff(self.cur if self.cur is not None else self, target)
        else:
            self.task.send_key_down(self.key_of(token))
            if token == 'E':
                self.cur.record_resonance_use()
            elif token == 'Q':
                self.cur.record_echo_use()
            elif token == 'R':
                self.cur.record_liberation_use()
        self.held.add(token)

    def press_up(self, token, char_by_token):
        if token == 'L':
            self.task.mouse_up()
        elif token == 'RB':
            self.task.mouse_up(key='right')
        elif token in SWITCH_TOKENS:
            self.task.send_key_up(str(char_by_token[token].index + 1))
        else:
            self.task.send_key_up(self.key_of(token))
        self.held.discard(token)

    def release_all(self):
        """异常退出时把按着的键都松开, 不然左键会一直按在游戏里。"""
        chars = self.char_by_token()
        for token in list(self.held):
            try:
                self.press_up(token, chars)
            except Exception:
                pass
        self.held.clear()

    def tap(self, token, hold):
        """按一下。返回按下的 perf_counter。"""
        chars = self.char_by_token()
        down = time.perf_counter()
        self.press_down(token, chars)
        self.macro_wait(max(hold, self.MIN_KEY_HOLD))
        self.press_up(token, chars)
        return down

    def char_by_token(self):
        return {'卡': self, '夏': self.teammate('Ciaccona'), '千': self.teammate('Chisa')}

    def handoff(self, from_char, to_char):
        """复刻 switch_next_char() 尾部那套交接记账(不确认切人, 按下数字键就记)。

        不补的话没人的 is_current_char 是 True, get_current_char() 返回 None,
        框架主循环和 get_cd() 当场崩。
        """
        self.task.in_liberation = False
        from_char.switch_out(con_full=False)
        to_char.is_current_char = True
        to_char.has_intro = False
        to_char.has_sub_dps_intro = False
        to_char.last_switch_in_time = time.time()
        self.cur = to_char

    def play_macro(self, macro, tag, start=None, done_mark=True, guard_lib=False, guard_chisa_e=(), guard_chisa_r=(),
                   guard_chisa_e2=()):
        """按表回放一段宏。返回 (起点, 最后一个按键按下的时刻), 都是 perf_counter。

        每个按键的发送时刻 = 起点 + 前面所有项的(按住 + 间隔)之和, 按绝对时刻排,
        某一下发晚了不会把后面的累积推歪。
        【起点已经过去了就从现在算】: 不然前面那几项会挤成一串连发(变身补 R 耽误过一次, 干跑抓到的)。
        guard_lib: 宏里的大招 R 按完确认演出开始了; 没开始就补放, 后面的按键从真正放出去的时刻重新起算。
        guard_chisa_e: 表里这几项(下标)是千咲的普通 E, 按完读冷却数字确认放出去了, 没放出去补按、后面顺延。
        guard_chisa_r: 表里这几项是千咲的 R, 演完看回路条, 短太多当场补 E、后面顺延。
        """
        chars = self.char_by_token()
        now = time.perf_counter()
        t0 = now if start is None else start
        if t0 < now:
            if now - t0 > 0.02:
                self.macro_mark(f'{tag}起点晚{now - t0:.2f}s')
            t0 = now
        self.sleep_until(t0)
        at = 0.0
        last_down = t0
        worst = 0.0
        late = []
        for i, (token, hold_ms, gap_ms) in enumerate(macro):
            down_at = t0 + at
            hold = hold_ms / 1000.0
            gap = 0.0 if gap_ms is None else gap_ms / 1000.0
            next_at = down_at + hold + gap
            up_at = down_at + max(hold, self.MIN_KEY_HOLD)
            if gap_ms is not None and up_at > next_at:
                up_at = next_at
            self.sleep_until(down_at)
            lag = time.perf_counter() - down_at
            self.press_down(token, chars)
            worst = max(worst, lag)
            if lag > self.LATE_WARN:
                late.append(f'#{i}{token}+{lag * 1000:.0f}ms')
            if token in SWITCH_TOKENS or token in ('E', 'Q', 'R'):
                self.macro_mark(f'{tag}{token}')
            last_down = down_at
            self.sleep_until(up_at)
            self.press_up(token, chars)
            if i in guard_chisa_e:
                t0 += self.ensure_chisa_normal_e(f'{tag}{CN_NAMES.get(self.cur.name, "")}', down_at, next_at)
            if token == 'R' and gap >= self.PROBE_MIN_GAP:
                if guard_lib:
                    t0 += self.ensure_lib_fired(self.cur, f'{tag}R', down_at, next_at)
                else:
                    self.probe_lib(f'{tag}R', down_at, next_at - self.PROBE_MARGIN)
            if i in guard_chisa_r:
                t0 += self.chisa_r_topup(f'{tag}千咲', t0 + at + hold + gap)
            if i in guard_chisa_e2:
                t0 += self.chisa_e2_recheck_now(f'{tag}千咲', down_at, t0 + at + hold + gap)
            at += hold + gap
        if done_mark or late:
            self.macro_mark(f'{tag}{"宏完" if done_mark else "宏前段"}(最晚+{worst * 1000:.0f}ms'
                            + (f' {",".join(late)}' if late else '') + ')')
        return t0, last_down

    def ensure_lib_fired(self, char, tag, pressed_at, next_at):
        """宏里按完大招 R: 确认演出开始了。返回后面的按键要整体推迟多少秒。

        正常情况 HUD 在按下后 0.06~0.08 秒掉(实机), 这里只读屏不改节奏, 返回 0。
        没掉: 先看场上是不是她(切人被拒就补切), 再边点 A 边隔 LIB_RETRY_STEP 补按 R,
        放出去了就把后面整体推迟到"从这一下起算"; 补到上限也没放出去就不推迟(只是不让后面挤成连发)。
        """
        if self.wait_hud_gone(self.LIB_CONFIRM, pressed_at, tag=tag):
            return 0.0
        start = time.perf_counter()
        actual = self.on_field_char(time_out=0.2)
        if actual is not None and actual is not char:
            self.macro_mark(f'{tag}场上是{actual.name[:3]}')
            self.cur = actual
            self.quick_switch(char, tag=f'{tag}补切')
        fired_at = None
        n = 0
        while time.perf_counter() - start < self.LIB_RETRY_CAP and fired_at is None:
            pressed = self.tap('R', self.EQR_R_HOLD)
            n += 1
            step_end = pressed + self.LIB_RETRY_STEP
            while time.perf_counter() < step_end:
                self.task.next_frame()
                if not self.task.in_team()[0]:
                    fired_at = pressed
                    break
                time.sleep(0.01)
            if fired_at is None:
                self.task.click()
        if fired_at is not None:
            self.macro_mark(f'{tag}补出(x{n},晚{fired_at - pressed_at:.2f})')
            return fired_at - pressed_at
        self.macro_mark(f'{tag}补也没出(x{n})')
        self.logger.warning(f'kxq: {tag} ({char.name}) liberation never fired, even after {n} retries')
        return max(0.0, time.perf_counter() - next_at)

    def probe_lib(self, tag, pressed_at, deadline):
        """宏里 R 之后的长空档: 看一眼 HUD 掉没掉, 只记日志, 不改节奏。"""
        while time.perf_counter() < deadline:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                self.macro_mark(f'{tag}演出(+{time.perf_counter() - pressed_at:.2f})')
                return True
            time.sleep(0.02)
        self.macro_mark(f'{tag}没见演出')
        self.logger.warning(f'kxq: {tag} never hid the HUD, liberation probably not fired')
        return False

    # ==================== 读屏原语 ====================

    def wait_anim(self, tag, time_out, gone_grace=None):
        """【不点击】等一段演出: 先看到 HUD 掉下去, 再等它回来。

        返回 (是否有演出, HUD 回来的 perf_counter)。gone_grace 内 HUD 一直在 = 没有演出。
        不点击是因为演出一结束接的是技能键(剑切宏的 E / 循环宏的 E), 普攻起手会挡住它。
        """
        gone_grace = self.ANIM_GONE_GRACE if gone_grace is None else gone_grace
        start = time.perf_counter()
        wall = time.time()
        gone = False
        while time.perf_counter() - start < time_out:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone = True
            elif gone:
                break
            elif time.perf_counter() - start >= gone_grace:
                break
            time.sleep(0.01)
            self.check_enabled()
        back = time.perf_counter()
        if gone:
            # 演出计入 freeze, 否则 get_cd 等按"扣掉冻结"算的时间全歪
            self.add_freeze_duration(wall, back - start)
        self.macro_mark(f'{tag}({"演出" if gone else "没演出"},{back - start:.2f}s)')
        return gone, back

    def wait_hud_gone(self, cap, pressed_at, tag):
        """【不点击】等 HUD 掉下去(大招演出开始), 看到就返回 True。只确认放出去了, 不等演出结束。"""
        start = time.perf_counter()
        while time.perf_counter() - start < cap:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                self.macro_mark(f'{tag}演出(+{time.perf_counter() - pressed_at:.2f})')
                return True
            time.sleep(0.01)
            self.check_enabled()
        self.macro_mark(f'{tag}没演出({cap:.2f}s)')
        return False

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 在场。放在按 R 之前: HUD 本来就不在时 fire_lib 会假成功。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.perf_counter()
        while time.perf_counter() - start < cap:
            self.task.next_frame()
            if self.task.in_team()[0]:
                if time.perf_counter() - start > 0.05:
                    self.macro_mark(f'{tag}等回({time.perf_counter() - start:.2f}s)')
                return True
            time.sleep(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.2f}s)')
        return False

    def fire_lib(self, tag='R', window=None):
        """连发 R 直到 HUD 掉下去(演出开始)。返回是否放出去了。"""
        window = self.LIB_FIRE_WINDOW if window is None else window
        start = time.perf_counter()
        n = 0
        while time.perf_counter() - start < window:
            self.send_liberation_key()
            n += 1
            if n % self.LIB_READ_EVERY == 0:
                self.task.next_frame()
                if not self.task.in_team()[0]:
                    self.record_liberation_use()
                    self.macro_mark(f'{tag}出手(x{n})')
                    return True
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.next_frame()
        if not self.task.in_team()[0]:
            self.record_liberation_use()
            self.macro_mark(f'{tag}出手(x{n})')
            return True
        self.macro_mark(f'{tag}没出(x{n})')
        return False

    def click_until(self, target, interval=None):
        """连点普攻到 perf_counter 的某个时刻。返回点了几下。"""
        interval = self.A_INTERVAL if interval is None else interval
        n = 0
        while True:
            now = time.perf_counter()
            if now >= target:
                return n
            self.task.click()
            n += 1
            self.sleep_until(min(target, now + interval))

    def wait_lib_ready(self, cap, tag):
        """边点边等大招能量。"""
        start = time.perf_counter()
        next_click = 0.0
        while time.perf_counter() - start < cap:
            now = time.perf_counter()
            if now >= next_click:
                self.task.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            try:
                if self.liberation_available():
                    self.macro_mark(f'{tag}能量满({time.perf_counter() - start:.2f}s)')
                    return True
            except Exception:
                pass
        self.macro_mark(f'{tag}能量cap')
        return False

    def read_form(self, reads=2):
        """连读几帧形态, 读数一致才算。返回 True=小卡 False=芙 None=读数不一致。"""
        vals = []
        for i in range(reads):
            self.task.next_frame()
            vals.append(bool(self.is_small()))
            if i + 1 < reads:
                time.sleep(0.01)
        return vals[0] if all(v == vals[0] for v in vals) else None

    def wait_lib_big(self, cap, tag='决意'):
        """边点普攻边等芙的决意满(大招图标换成 lib_cartethyia_big)。

        返回 'ready' / 'cap' / 'small'。'small' = 连着几次看到的是小卡: 小卡永远 A 不满决意,
        再等就是原地重复普攻。
        """
        start = time.perf_counter()
        n = 0
        next_click = 0.0
        next_form = start + self.FORM_WATCH_EVERY
        small_streak = 0
        status = 'cap'
        while time.perf_counter() - start < cap:
            now = time.perf_counter()
            if now >= next_click:
                self.task.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if self.is_lib_big_available():
                status = 'ready'
                break
            if now >= next_form:
                next_form = now + self.FORM_WATCH_EVERY
                small_streak = small_streak + 1 if self.read_form() is True else 0
                if small_streak >= self.FORM_SMALL_STREAK:
                    status = 'small'
                    break
        label = {'ready': '满', 'cap': 'cap', 'small': '是小卡'}[status]
        self.macro_mark(f'{tag}({label},A x{n},{time.perf_counter() - start:.2f}s)')
        return status

    def read_cds(self):
        """读技能栏 E、R 的 CD 秒数(OCR)。读不到数字就是 0。"""
        self.task.next_frame()
        try:
            e = max(0.0, float(self.task.get_cd('resonance')))
        except Exception:
            e = 0.0
        try:
            r = max(0.0, float(self.task.get_cd('liberation')))
        except Exception:
            r = 0.0
        return e, r

    def wait_eqr_ready(self, tag):
        """边点普攻边等 E 和 R 都转好。返回等了多久。

        读到数字就记下"预计转好的时刻"并按它走, 之后再读到数字就更新(时停会让 CD 停住)。
        读不到数字: 离预计还早就当成特效挡住了; 从没读到过数字(2链或者本来就好了)时
        要连着 CD_ZERO_CONFIRM 次都读不到才算转好。
        """
        start = time.perf_counter()
        ready_at = None
        zeros = 0
        reads = []
        next_read = start
        next_click = start
        why = 'cap'
        while True:
            now = time.perf_counter()
            if ready_at is not None and now >= ready_at + self.EQR_AFTER:
                why = 'cd'
                break
            if now - start >= self.EQR_WAIT_CAP:
                break
            if now >= next_read:
                e, r = self.read_cds()
                t = time.perf_counter()
                need = max(e, r)
                if len(reads) < 12:
                    reads.append(f'{e:.1f}/{r:.1f}')
                if need > 0.02:
                    ready_at = t + need
                    zeros = 0
                elif ready_at is None:
                    zeros += 1
                    if zeros >= self.CD_ZERO_CONFIRM:
                        ready_at = t
                elif t >= ready_at - 0.15:
                    ready_at = t
                near = ready_at is None or ready_at - t <= 0.6
                next_read = t + (self.CD_POLL_NEAR if near else self.CD_POLL_FAR)
                continue
            quiet = ready_at is not None and now >= ready_at - self.EQR_NO_CLICK
            if not quiet and now >= next_click:
                self.task.click()
                next_click = now + self.A_INTERVAL
            wake = next_read if quiet else min(next_read, next_click)
            if ready_at is not None:
                wake = min(wake, ready_at + self.EQR_AFTER)
            self.sleep_until(max(now + 0.005, wake))
        waited = time.perf_counter() - start
        self.macro_mark(f'{tag}等E/R({why},{waited:.2f}s,读数E/R {" ".join(reads)})')
        return waited

    def on_field_char(self, time_out=None):
        """现在场上是谁(in_team 的 count 要够才可信)。"""
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.perf_counter() + time_out
        while True:
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.perf_counter() >= end:
                return None
            time.sleep(0.03)

    def quick_switch(self, target, tag='切'):
        """一直发数字键直到 HUD 确认换人。只用在宏外面的兜底(宏里切人不确认)。"""
        if target is None:
            return False
        start = time.perf_counter()
        source = self.cur if self.cur is not None else self
        slot = str(target.index + 1)
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted = 0
        while time.perf_counter() - start < self.SWITCH_TIME_OUT:
            self.task.send_key(slot, down_time=0.02)
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            hit = in_team and index == target.index
            untrusted = untrusted + 1 if (hit and count < team_size) else 0
            if hit and (count >= team_size or untrusted >= self.UNTRUSTED_CONFIRM):
                if source is not target:
                    self.handoff(source, target)
                self.macro_mark(f'{tag}>{target.name[:3]}({time.perf_counter() - start:.2f}s)')
                return True
        self.macro_mark(f'{tag}>{target.name[:3]}FAIL')
        return False

    def ensure_cart_on_field(self, tag):
        """宏里切人不确认; 宏收尾那个数字键被游戏拒了的话场上不是卡提, 这里补切。

        返回补切成功的 perf_counter, 没补切返回 None。
        """
        actual = self.on_field_char(time_out=0.3)
        if actual is None or actual is self:
            return None
        self.macro_mark(f'{tag}场上是{actual.name[:3]}')
        self.cur = actual
        if self.quick_switch(self, tag=f'{tag}补切'):
            return time.perf_counter()
        return None

    # ==================== 宏外面的三段 ====================

    def seg_intro_eqr(self, switch_at, opener):
        """变奏段: 宏最后那个数字键按下的时刻 -> 跳A 下落 -> 等 E/R -> EQR -> 确认变身出手。

        返回 (剑切宏起点, 起点是不是从 R 按下推出来的)。看到变身演出开始就不再等 HUD 回来。
        """
        p = 'op' if opener else 'L'
        intro_to_jump = self.O_INTRO_TO_JUMP if opener else self.L_INTRO_TO_JUMP
        jump_at = switch_at + intro_to_jump
        # 入场锁里的输入被丢掉, 趁这段确认一下场上真的是卡提。
        # 数字键按下后 0.1 秒左右才换人, 太早读会读到上一个人
        self.sleep_until(switch_at + self.INTRO_CHECK_AT)
        switched = self.ensure_cart_on_field(f'{p}变奏')
        anchor = switch_at
        if switched is not None:
            anchor = switched - 0.10
            jump_at = max(jump_at, anchor + intro_to_jump)
        jump_at = max(jump_at, self.cart_first_sword(anchor, tag=f'{p}变奏'))
        self.sleep_until(jump_at)
        self.macro_mark(f'{p}跳')
        self.tap('SP', self.JUMP_HOLD)
        self.sleep_until(jump_at + self.JUMP_TO_AIR_A)
        self.tap('L', self.AIR_A_HOLD)
        self.sleep_until(jump_at + self.JUMP_TO_AIR_A + self.AIR_A_RETRY)
        self.tap('L', self.AIR_A_HOLD)
        self.macro_mark(f'{p}空中A')
        self.sleep_until(jump_at + (self.O_JUMP_TO_LANDED if opener else self.L_JUMP_TO_LANDED))
        self.wait_eqr_ready(tag=p)
        for i in range(self.EQR_E_TAPS):
            if i:
                self.macro_wait(self.EQR_E_TAP_GAP)
            self.tap('E', self.EQR_E_HOLD)
        self.macro_wait(self.EQR_E_GAP)
        self.tap('Q', self.EQR_Q_HOLD)
        self.macro_wait(self.EQR_Q_GAP)
        wall = time.time()
        r_down = self.tap('R', self.EQR_R_HOLD)
        self.macro_mark(f'{p}EQR')
        self.is_cartethyia = False
        if self.wait_hud_gone(self.ANIM_GONE_GRACE, r_down, tag=f'{p}变身'):
            self.add_freeze_duration(wall, self.CART_TRANSFORM_ANIM)
            return r_down + (self.O_R1_TO_SWORD if opener else self.L_R1_TO_SWORD), True
        self.logger.warning('kxq: transform R did not start an animation, retrying')
        self.wait_lib_ready(self.CART_LIB_RETRY_CAP, tag=f'{p}变身补')
        self.wait_hud_up(tag=f'{p}变身补前')
        back = time.perf_counter()
        if self.fire_lib(tag=f'{p}变身补R'):
            _, back = self.wait_anim(f'{p}变身补', self.CART_TRANSFORM_ANIM + 3, gone_grace=0.0)
        return back + self.SWORD_AFTER_HUD_RETRY, False

    def seg_sword(self, start, prepress, opener):
        """剑切宏。返回宏最后那个 R(芙切回小卡)按下的时刻。

        prepress: 起点是从变身 R 按下推出来的(没等 HUD), 起点前抢按几下 E 兜底。
        """
        p = 'op' if opener else 'L'
        if prepress:
            probe_at = start - self.R1_HUD_PROBE
            if time.perf_counter() < probe_at:
                self.sleep_until(probe_at)
                self.task.next_frame()
                self.macro_mark(f'{p}剑切前HUD{"在" if self.task.in_team()[0] else "不在"}')
            for lead in self.SWORD_E_PREPRESS:
                if time.perf_counter() < start - lead:
                    self.sleep_until(start - lead)
                    self.tap('E', self.SWORD_E_PREPRESS_HOLD)
            self.macro_mark(f'{p}剑切抢按E')
        _, l2_down = self.play_macro(SWORD_A, f'{p}剑切', start=start, done_mark=False)
        e_at = self.ciac_sword_forte(l2_down, SWORD_A[-1], tag=f'{p}剑切夏空')
        _, r_at = self.play_macro(SWORD_B, f'{p}剑切', start=e_at, guard_chisa_e=(SWORD_B_CHISA_NORMAL_E,))
        self.is_cartethyia = True
        return r_at

    def seg_small_to_r2(self, r_at, opener):
        """小卡段 + 芙段: 连A -> 长按重击 -> 跳A 下落 -> R 变回芙 -> A 到决意满 -> R2。"""
        p = 'op' if opener else 'L'
        a_from = r_at + (self.O_SMALL_A_FROM if opener else self.L_SMALL_A_FROM)
        hold_at = r_at + (self.O_SMALL_HOLD_AT if opener else self.L_SMALL_HOLD_AT)
        hold_up = r_at + (self.O_SMALL_HOLD_UP if opener else self.L_SMALL_HOLD_UP)
        jump_at = r_at + (self.O_SMALL_JUMP_AT if opener else self.L_SMALL_JUMP_AT)
        r_from = r_at + (self.O_SMALL_R_AT if opener else self.L_SMALL_R_AT)
        chars = self.char_by_token()

        self.sleep_until(a_from)
        n = self.click_until(r_at + self.SMALL_FORM_PROBE)
        if self.read_form() is False:
            # 剑切宏那下 R 没切回小卡(被控/被打断)。决意没满就补按一下 R 切回去, 小卡段整体顺延; 决意满了或补不回去才直接走芙段
            if self.is_lib_big_available():
                self.macro_mark(f'{p}剑切R后还是芙(决意满),直接走芙段')
                return self.fleur_r2(f'{p}R2')
            pressed = self.tap('R', self.EQR_R_HOLD)
            back = False
            while time.perf_counter() - pressed < self.SWORD_R_FIX_CAP:
                if self.read_form() is True:
                    back = True
                    break
                time.sleep(0.02)
            if not back:
                self.macro_mark(f'{p}剑切R后还是芙,补R也没切回,直接走芙段')
                self.logger.warning('kxq: still fleurdelys after the sword macro R, skipping the cartethyia part')
                return self.fleur_r2(f'{p}R2')
            self.macro_mark(f'{p}剑切R后还是芙,补R切回小卡(+{time.perf_counter() - pressed:.2f})')
            shift = pressed - r_at
            r_at, a_from, hold_at = pressed, a_from + shift, hold_at + shift
            hold_up, jump_at, r_from = hold_up + shift, jump_at + shift, r_from + shift
            n += self.click_until(r_at + self.SMALL_FORM_PROBE)
        n += self.click_until(hold_at)
        self.macro_mark(f'{p}小卡A(x{n})')
        self.press_down('L', chars)
        self.sleep_until(hold_up)
        self.press_up('L', chars)
        self.macro_mark(f'{p}重击松手')
        self.sleep_until(jump_at)
        self.tap('SP', self.JUMP_HOLD)
        self.sleep_until(jump_at + self.JUMP_TO_AIR_A)
        self.tap('L', self.AIR_A_HOLD)
        self.sleep_until(jump_at + self.JUMP_TO_AIR_A + self.AIR_A_RETRY)
        self.tap('L', self.AIR_A_HOLD)
        self.macro_mark(f'{p}小卡跳A')

        if not self.small_to_fleur(r_from, tag=f'{p}R变芙'):
            self.logger.warning('kxq: never became fleurdelys, skipping R2 this cycle')
            self.r2_owed = True
            return False
        return self.fleur_r2(f'{p}R2')

    def ensure_on_field(self, char, tag):
        """读一帧看场上是不是 char, 不是就补切(宏里切人不确认, 被拒了后面整段都打在别人身上)。

        HUD 不在(演出里)或读不准就当是对的, 不耽误。返回是否补切过。
        """
        if char is None:
            return False
        self.task.next_frame()
        in_team, index, count = self.task.in_team()
        if not in_team or index < 0 or index == char.index:
            return False
        actual = next((c for c in self.task.chars if c is not None and c.index == index), None)
        self.macro_mark(f'{tag}场上是{CN_NAMES.get(actual.name, "?") if actual else index},补切')
        if actual is not None:
            self.cur = actual
        self.quick_switch(char, tag=f'{tag}补切')
        return True

    def ciac_forte_count(self, ciac):
        """夏空回路格数(0~3), 走原版 judge_forte(满了看重击图标, 没满看回路条频谱)。"""
        self.task.next_frame()
        try:
            return int(ciac.judge_forte())
        except Exception:
            return -1

    def ciac_sword_forte(self, l2_down, l2_item, tag):
        """剑切宏里夏空按 E 之前: 读回路, 下落 + 落地 A 给的那 1 格有了就照宏走; 没有就接着点 A 到有为止。

        返回夏空按 E 的时刻(后面整段从这里重新起算)。正常情况只多读一次屏, 不改节奏。
        """
        ciac = self.teammate('Ciaccona')
        e_at = l2_down + (l2_item[1] + l2_item[2]) / 1000.0
        self.sleep_until(e_at - self.CIAC_SWORD_CHECK_LEAD)
        have = self.ciac_forte_count(ciac)
        grace_end = time.perf_counter() + self.CIAC_SWORD_GRACE
        while have < 1 and time.perf_counter() < grace_end:
            time.sleep(0.02)
            have = self.ciac_forte_count(ciac)
        if have >= 1:
            late = time.perf_counter() - e_at
            self.macro_mark(f'{tag}回路{have}格' + (f'(晚{late:.2f})' if late > 0.01 else ''))
            return max(e_at, time.perf_counter())
        start = time.perf_counter()
        n = 0
        next_click = start
        next_read = start + self.CIAC_SWORD_READ_EVERY
        while time.perf_counter() - start < self.CIAC_SWORD_FIX_CAP:
            now = time.perf_counter()
            if now >= next_click:
                self.task.click()
                n += 1
                next_click = now + self.CIAC_SWORD_A_EVERY
            if now >= next_read:
                have = self.ciac_forte_count(ciac)
                next_read = time.perf_counter() + self.CIAC_SWORD_READ_EVERY
                if have >= 1:
                    break
            time.sleep(0.01)
        self.macro_mark(f'{tag}回路{"补到" if have >= 1 else "没补到"}{have}格(A x{n},{time.perf_counter() - start:.2f}s)')
        if have < 1:
            self.logger.warning(f'kxq: {tag} forte still empty after {self.CIAC_SWORD_FIX_CAP:.1f}s of attacks')
        return time.perf_counter()

    def ciac_heavy_then_switch(self, jump_at, tag):
        """夏空跳起来之后按住左键, 确认回路满过、再确认重击把回路清空了, 马上松手。返回该切千咲的时刻。

        判据是技能栏的"回路满"图标(is_mouse_forte_full): 先看到亮, 再连着 CIAC_CLEAR_CONFIRM 帧灭。
        按住期间只读屏不发输入(再发 mouse_down 会把按住打断); 亮了 L_CIAC_REGRIP 秒还不灭才松开重按。
        按住 L_CIAC_FALL_WAIT 秒一直没满过 = 回路缺一格: 松手补 A(不满再补 跳A下落+落地A), 满了再按住重击。
        """
        ciac = self.teammate('Ciaccona')
        chars = self.char_by_token()
        self.sleep_until(jump_at + 0.03)
        self.ensure_on_field(ciac, tag)
        self.sleep_until(jump_at + self.L_CIAC_JUMP_TO_HOLD)
        self.press_down('L', chars)
        holding = True
        start = time.perf_counter()
        wait_from = start
        grip_at = start
        grips = 1
        fixes = 0
        full_at = None
        clear_streak = 0
        why = '没见满'
        while time.perf_counter() - start < self.L_CIAC_HEAVY_CAP:
            self.task.next_frame()
            try:
                full = bool(ciac.is_mouse_forte_full())
            except Exception:
                full = False
            t = time.perf_counter()
            if full:
                clear_streak = 0
                if full_at is None:
                    full_at = t
                    why = '满了没清'
                    if not holding:
                        self.press_down('L', chars)
                        holding = True
                        grip_at = time.perf_counter()
                        grips += 1
                elif holding and grips < 4 and t - max(full_at, grip_at) >= self.L_CIAC_REGRIP:
                    self.press_up('L', chars)
                    self.macro_wait(0.03)
                    self.press_down('L', chars)
                    grip_at = time.perf_counter()
                    grips += 1
            elif full_at is not None:
                clear_streak += 1
                if clear_streak >= self.CIAC_CLEAR_CONFIRM:
                    why = '清空'
                    break
            elif (fixes < self.L_CIAC_FALL_FIXES
                  and t - wait_from >= (self.L_CIAC_FALL_WAIT if fixes == 0 else self.L_CIAC_FIX_WAIT)):
                have = self.ciac_forte_count(ciac)
                if holding:
                    self.press_up('L', chars)
                    holding = False
                fixes += 1
                if fixes == 1:
                    self.macro_mark(f'{tag}补A(+{t - start:.2f}没满,回路{have}格)')
                    self.tap('L', self.AIR_A_HOLD)
                    self.macro_wait(self.L_CIAC_FIX_A_GAP)
                    self.tap('L', self.AIR_A_HOLD)
                else:
                    self.macro_mark(f'{tag}补跳A下落+A(+{t - start:.2f}没满,回路{have}格)')
                    jumped = self.tap('SP', self.JUMP_HOLD)
                    for offset in self.L_CIAC_FIX_AIR_A:
                        self.sleep_until(jumped + offset)
                        self.tap('L', self.AIR_A_HOLD)
                    self.sleep_until(jumped + self.L_CIAC_FIX_LAND_A)
                    self.tap('L', self.AIR_A_HOLD)
                wait_from = time.perf_counter()
            time.sleep(0.005)
        if holding:
            self.press_up('L', chars)
        end = time.perf_counter()
        full_txt = f'满+{full_at - start:.2f}' if full_at is not None else '没见满'
        self.macro_mark(f'{tag}回路({why},{full_txt},松手+{end - start:.2f},按x{grips},补x{fixes})')
        if why != '清空':
            self.logger.warning(f'kxq: {tag} forte never went full->cleared in {self.L_CIAC_HEAVY_CAP:.1f}s ({why}), switching anyway')
        return end + self.L_CIAC_CLEAR_TO_SWITCH

    # ==================== 保底用的读屏判据 ====================

    def hsv_fraction(self, box, pad, hue_lo, hue_hi, s_min, v_min):
        """框(四周外扩 pad 倍)里满足色相/饱和度/亮度条件的像素占比。hue_lo > hue_hi 表示跨过 180。"""
        frame = self.task.frame
        if frame is None or box is None:
            return 0.0
        h, w = frame.shape[:2]
        x0 = max(0, int(box.x - box.width * pad))
        y0 = max(0, int(box.y - box.height * pad))
        x1 = min(w, int(box.x + box.width * (1 + pad)))
        y1 = min(h, int(box.y + box.height * (1 + pad)))
        if x1 <= x0 or y1 <= y0:
            return 0.0
        hsv = cv2.cvtColor(frame[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        hue, sat, val = hsv[..., 0], hsv[..., 1], hsv[..., 2]
        if hue_lo <= hue_hi:
            hue_ok = (hue >= hue_lo) & (hue <= hue_hi)
        else:
            hue_ok = (hue >= hue_lo) | (hue <= hue_hi)
        return float(np.mean(hue_ok & (sat >= s_min) & (val >= v_min)))

    def sword1_blue(self):
        """最左剑位(异权剑)的亮蓝色占比。位置用框架标注 forte_cartethyia_sword1(和读形态用的剑位是同一套坐标)。"""
        try:
            return self.hsv_fraction(self.task.get_box_by_name('forte_cartethyia_sword1'), 0.15, 85, 130, 90, 120)
        except Exception:
            return 0.0

    def chisa_ring(self):
        """千咲 E 图标框里的粉色占比(强化E 可用时的粉圈)。纯红(色相 0 附近)不算, 免得被红色特效骗。"""
        try:
            return self.hsv_fraction(self.task.get_box_by_name('box_resonance'), 0.20, 140, 178, 80, 110)
        except Exception:
            return 0.0

    def chisa_bar_level(self):
        """千咲回路条(残响1)长度: 条上粉色的列占多少(0~1)。框是从剑位标注推的(条在三个剑位那一排)。"""
        try:
            box = self.task.box_of_screen_scaled(3840, 2160, 1620, 1984, 2168, 2012, name='kxq_chisa_bar', hcenter=True)
            crop = box.crop_frame(self.task.frame)
            if crop is None or crop.size == 0:
                return 0.0
            hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
            pink = (hsv[..., 0] >= 140) & (hsv[..., 0] <= 178) & (hsv[..., 1] >= 80) & (hsv[..., 2] >= 110)
            return float(np.mean(pink.mean(axis=0) >= 0.2))
        except Exception:
            return 0.0

    def chisa_full(self, chisa):
        """千咲回路条满了没有。返回 (满没满, 靠哪条判据)。

        E 图标粉圈 / 框架的回路满白框(原版千咲用的 is_forte_full) / 条读满(条的读数对上过才用)。
        """
        ring = self.chisa_ring()
        if ring >= self.CHISA_RING_MIN:
            return True, f'粉圈{ring:.2f}'
        try:
            if chisa is not None and chisa.is_forte_full():
                return True, '白框'
        except Exception:
            pass
        if self.chisa_bar_trusted:
            level = self.chisa_bar_level()
            if level >= self.CHISA_BAR_FULL:
                return True, f'条{level:.2f}'
        return False, ''

    def debug_snapshot(self, kind):
        """排查用: 存一张屏幕底部 16% 的小图到 logs/kxq_debug。KXQ_SNAPSHOT 总开关, 每场最多 KXQ_SNAPSHOT_MAX 张。"""
        if not self.KXQ_SNAPSHOT or self.snapshots >= self.KXQ_SNAPSHOT_MAX:
            return
        try:
            frame = self.task.frame
            if frame is None:
                return
            crop = frame[int(frame.shape[0] * 0.84):, :]
            folder = os.path.join('logs', 'kxq_debug')
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, f'{time.strftime("%m%d_%H%M%S")}_{kind}.png')
            ok, buf = cv2.imencode('.png', crop)
            if ok:
                buf.tofile(path)
                self.snapshots += 1
                self.macro_mark(f'截图{kind}')
        except Exception as e:
            self.logger.warning(f'kxq: snapshot failed ({e})')

    def chisa_r_topup(self, tag, next_at):
        """千咲 R 演完: 看回路条长度。短太多(CHISA_BAR_LOW 以下)就当场补一下 E 再往下走。返回后面要整体推迟多少秒。

        正常这时候条八九成满, 剩下的在场下补满, 不补。条的读数对上过才会补, 没对上之前只记日志。
        """
        chisa = self.teammate('Chisa')
        deadline = next_at + self.CHISA_TOPUP_LATE
        back = False
        while time.perf_counter() < deadline:
            self.task.next_frame()
            if self.task.in_team()[0]:
                back = True
                break
            time.sleep(0.01)
        if not back:
            self.macro_mark(f'{tag}R后回路(没等到HUD回来)')
            return max(0.0, time.perf_counter() - next_at)
        level = self.chisa_bar_level()
        full, how = self.chisa_full(chisa)
        if full or level >= self.CHISA_BAR_LOW:
            self.macro_mark(f'{tag}R后回路(条{level:.2f}{"," + how if how else ""})')
            return max(0.0, time.perf_counter() - next_at)
        if not self.chisa_bar_trusted:
            self.macro_mark(f'{tag}R后回路(条{level:.2f},条读数没对上过,不补)')
            return max(0.0, time.perf_counter() - next_at)
        # 启动轴千咲 R 之前刚放过普通 E, 这时 E 还在冷却: 按了放不出来, 冷却数字还会让下面的确认误判成功
        e_cd, _ = self.read_cds()
        if e_cd > self.CHISA_E_CD_MIN:
            self.macro_mark(f'{tag}R后回路(条{level:.2f},短,但E冷却{e_cd:.1f},留给强化E那里补)')
            return max(0.0, time.perf_counter() - next_at)
        self.macro_mark(f'{tag}R后回路(条{level:.2f},短,补E)')
        self.debug_snapshot('chisa_after_r_low')
        pressed = self.tap('E', 0.05)
        self.ensure_chisa_normal_e(f'{tag}补', pressed, next_at)
        return max(0.0, time.perf_counter() - next_at)

    # ==================== 保底 ====================

    def cart_first_sword(self, switch_at, tag):
        """变奏卡提: 等最左剑位亮。被怪打断没亮就补重击(按住到剑位亮), 最多 CART_HEAVY_TRIES 次。

        返回最早可以跳的时刻。正常情况剑位在切人后 1.2 秒亮, 跟原来固定 1.2 秒跳几乎一样。
        """
        self.sleep_until(switch_at + self.SWORD1_POLL_FROM)
        streak = 0
        blue = 0.0
        while time.perf_counter() < switch_at + self.SWORD1_CAP:
            self.task.next_frame()
            blue = self.sword1_blue()
            streak = streak + 1 if blue >= self.SWORD1_BLUE else 0
            if streak >= self.SWORD1_CONFIRM:
                now = time.perf_counter()
                self.macro_mark(f'{tag}剑1亮(+{now - switch_at:.2f},蓝{blue:.2f})')
                return now
            time.sleep(0.01)
        self.macro_mark(f'{tag}剑1没亮(蓝{blue:.2f}),补重击')
        chars = self.char_by_token()
        for i in range(self.CART_HEAVY_TRIES):
            self.press_down('L', chars)
            start = time.perf_counter()
            streak = 0
            lit = False
            while time.perf_counter() - start < self.CART_HEAVY_CAP:
                self.task.next_frame()
                blue = self.sword1_blue()
                streak = streak + 1 if blue >= self.SWORD1_BLUE else 0
                if streak >= self.SWORD1_CONFIRM:
                    lit = True
                    break
                time.sleep(0.01)
            self.press_up('L', chars)
            end = time.perf_counter()
            self.macro_mark(f'{tag}补重击{i + 1}({"亮" if lit else "没亮"},{end - start:.2f}s,蓝{blue:.2f})')
            if lit:
                return end + self.CART_HEAVY_TO_JUMP
            self.macro_wait(0.05)
        self.logger.warning(f'kxq: {tag} first sword never lit after {self.CART_HEAVY_TRIES} heavy attacks')
        return time.perf_counter()

    def chisa_enhanced_e(self, chi_down, chi_item, e_item, tag):
        """千咲强化E: 按 E 之前先看到粉圈, 按下后粉圈连两帧灭了(且 HUD 在)才算放出去。返回该切卡提的时刻。

        粉圈还在就隔 CHISA_E_RETRY 补按。一直没见过粉圈(强化E 没解锁, 或者读不到)就按一下照宏的节奏走。
        """
        e_at = chi_down + (chi_item[1] + chi_item[2]) / 1000.0
        e_hold = e_item[1] / 1000.0
        e_min_after = (e_item[1] + e_item[2]) / 1000.0
        chisa = self.teammate('Chisa')
        self.sleep_until(chi_down + self.CHISA_RING_FROM)
        ring_at = None
        how = ''
        streak = 0
        while time.perf_counter() < e_at + self.CHISA_RING_WAIT:
            self.task.next_frame()
            full, how = self.chisa_full(chisa)
            streak = streak + 1 if full else 0
            if streak >= 2:
                ring_at = time.perf_counter()
                break
            time.sleep(0.01)
        if ring_at is not None and how.startswith('粉圈'):
            level = self.chisa_bar_level()
            if level >= self.CHISA_BAR_CALIB and not self.chisa_bar_trusted:
                self.chisa_bar_trusted = True
                self.macro_mark(f'{tag}条读数对上(粉圈时条{level:.2f})')
        if ring_at is None:
            self.debug_snapshot('chisa_no_ring')
            ring_at = self.chisa_fill_forte(tag)
            if ring_at is None:
                first = self.tap('E', e_hold)
                self.macro_mark(f'{tag}强化E(补回路也没见粉圈,按一下照走)')
                self.logger.warning(f'kxq: {tag} enhanced E ring never showed up, even after filling')
                self.sleep_until(first + e_min_after)
                return time.perf_counter()
        self.sleep_until(e_at)
        first = self.tap('E', e_hold)
        self.chisa_e2_recheck = True
        self.macro_mark(f'{tag}强化E(满于+{ring_at - chi_down:.2f}{"(" + how + ")" if how else ""})')
        self.sleep_until(first + e_min_after)
        return time.perf_counter()

    def chisa_fill_forte(self, tag):
        """到点还没粉圈: 回路条(残响1)没满, 多半是前面普通 E 没放出来。补一下 E, 接着 A 攒到出粉圈。

        返回看到粉圈的时刻, CHISA_FILL_CAP 内都没出现返回 None。
        """
        chisa = self.teammate('Chisa')
        start = time.perf_counter()
        self.tap('E', 0.05)
        next_click = start + 0.10
        n = 0
        streak = 0
        how = ''
        while time.perf_counter() - start < self.CHISA_FILL_CAP:
            now = time.perf_counter()
            if now >= next_click:
                self.task.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            full, how = self.chisa_full(chisa)
            streak = streak + 1 if full else 0
            if streak >= 2:
                t = time.perf_counter()
                self.macro_mark(f'{tag}补回路(补E+A x{n},{t - start:.2f}s满,{how})')
                return t
            time.sleep(0.01)
        level = self.chisa_bar_level()
        self.macro_mark(f'{tag}补回路(补E+A x{n},{self.CHISA_FILL_CAP:.1f}s没满,条{level:.2f})')
        self.debug_snapshot('chisa_fill_fail')
        return None

    def ensure_chisa_normal_e(self, tag, pressed_at, next_at):
        """宏里千咲那下普通 E: 读技能栏 E 的冷却数字, 出现了就算放出去; 没出现补按。返回后面要整体推迟多少秒。

        正常情况在下一个按键之前就读到了, 不改节奏。
        """
        self.sleep_until(pressed_at + self.CHISA_E_READ_FROM)
        last = pressed_at
        presses = 1
        cd = 0.0
        ok_at = None
        while time.perf_counter() - pressed_at < self.CHISA_NORMAL_E_CAP:
            cd, _ = self.read_cds()
            now = time.perf_counter()
            if cd > self.CHISA_E_CD_MIN:
                ok_at = now
                break
            if presses < 3 and now - last >= self.CHISA_NORMAL_E_RETRY:
                last = self.tap('E', 0.05)
                presses += 1
        end = time.perf_counter()
        if ok_at is None:
            self.macro_mark(f'{tag}普通E(读不到冷却,按x{presses})')
            self.logger.warning(f'kxq: {tag} normal E cooldown never showed up after {presses} presses')
        else:
            self.macro_mark(f'{tag}普通E(冷却{cd:.1f},按x{presses},+{ok_at - pressed_at:.2f})')
        # 确认得早就不动节奏; 确认(或放弃)已经过了下一个按键的时刻, 后面整体顺延到现在
        return max(0.0, end - next_at)

    def chisa_e2_recheck_now(self, tag, a_down, next_at):
        """强化E 按完切走之后, 千咲下一次上场复查: 回路条还满(粉圈/白框/条读满) = 那下强化E 被吞了, 当场补按。

        放在宏里那下 A 之后的长间隙里(离下一个按键还有 1 秒), 只读一两帧, 不改节奏。
        """
        if not self.chisa_e2_recheck:
            return 0.0
        self.chisa_e2_recheck = False
        self.sleep_until(min(a_down + self.CHISA_RECHECK_AT, next_at - 0.15))
        full, how = self.chisa_full(self.teammate('Chisa'))
        if not full:
            self.macro_mark(f'{tag}强化E复查(放出去了)')
            return 0.0
        self.task.next_frame()
        full, how = self.chisa_full(self.teammate('Chisa'))
        if not full:
            self.macro_mark(f'{tag}强化E复查(放出去了)')
            return 0.0
        self.tap('E', 0.05)
        self.macro_mark(f'{tag}强化E复查(还满着{how},补按E)')
        self.logger.warning(f'kxq: {tag} enhanced E was swallowed, pressed again on the next entry')
        return max(0.0, time.perf_counter() - next_at)

    def chisa_con_before_cart(self, planned, tag):
        """宏最后那下切卡提之前: 千咲协奏满了才切(变奏卡提), 没满接着 A。返回该切的时刻。

        直接读 task.get_current_con(): 角色身上那个会缓存"满", 宏里切人记账不清缓存, 读到的是旧值。
        """
        self.sleep_until(planned)
        self.ensure_on_field(self.teammate('Chisa'), tag)
        start = time.perf_counter()
        n = 0
        next_click = 0.0
        con = 0.0
        why = 'cap'
        while True:
            self.task.next_frame()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if con >= 1.0:
                why = '满'
                break
            now = time.perf_counter()
            if now - start >= self.CHISA_CON_CAP:
                break
            if now >= next_click:
                self.task.click()
                n += 1
                next_click = now + self.A_INTERVAL
            time.sleep(0.01)
        self.macro_mark(f'{tag}协奏({why},{con:.2f},A x{n},{time.perf_counter() - start:.2f}s)')
        if why != '满':
            self.logger.warning(f'kxq: {tag} concerto not full after {self.CHISA_CON_CAP:.1f}s, switching anyway')
        return time.perf_counter()

    def try_break(self, tag):
        """变回大卡之后马上找处决: BREAK_WINDOW 里每 BREAK_EVERY 按一下 F, 中间照样点 A。

        HUD 掉了 = 处决演出, 等它演完。没有处决时按 F 什么都不发生, 这段时间 A 也没停, 不耽误攒决意。
        """
        if not self.USE_F_BREAK:
            return False
        start = time.perf_counter()
        next_f = start
        next_click = start + 0.05
        n = 0
        while time.perf_counter() - start < self.BREAK_WINDOW:
            now = time.perf_counter()
            if now >= next_f:
                self.tap('F', 0.02)
                n += 1
                next_f = now + self.BREAK_EVERY
            elif now >= next_click:
                self.task.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                self.macro_mark(f'{tag}处决(F x{n},+{time.perf_counter() - start:.2f})')
                self.wait_anim(f'{tag}处决', self.F_ANIM_TIME_OUT, gone_grace=0.0)
                return True
            time.sleep(0.01)
        return False

    def small_to_fleur(self, r_from, tag):
        """R 变回芙。每次按之前先读形态: 已经是芙就不按, 还是小卡才按, 补按之间隔 SMALL_R_RETRY。"""
        self.sleep_until(r_from)
        start = time.perf_counter()
        presses = 0
        last = -1.0
        while time.perf_counter() - start < self.SMALL_R_CAP:
            form = self.read_form()
            now = time.perf_counter()
            if form is False:
                self.macro_mark(f'{tag}(芙,R x{presses},{now - start:.2f}s)')
                return True
            if form is True and presses < self.SMALL_R_MAX and (presses == 0 or now - last >= self.SMALL_R_RETRY):
                last = self.tap('R', self.EQR_R_HOLD)
                presses += 1
            time.sleep(0.01)
        self.macro_mark(f'{tag}(一直是小卡,R x{presses})')
        return False

    def fleur_r2(self, tag):
        """芙: A 到决意满 -> R2 -> 等演出结束。【决意没满绝对不按 R】。

        R 在芙身上有两种含义: 决意满是 R2, 没满是切回小卡。所以每一下 R 之前都在新的一帧上
        确认大招图标亮着; 按了没出演出(撞在普攻收招里被吞了)就回去接着 A, 图标还亮就再按。
        一直等不满就不放 R2, 返回 False —— 下一次 do_perform 开头的 recover_from_fleur 会接着 A。
        """
        self.try_break(f'{tag}大卡')
        start = time.perf_counter()
        rounds = 0
        while True:
            left = self.FLEUR_R2_CAP - (time.perf_counter() - start)
            status = self.wait_lib_big(cap=left, tag=f'{tag}决意') if left > 0 else 'cap'
            if status == 'small':
                self.logger.warning(f'kxq: {tag} waiting for resolve but the form is cartethyia, giving up')
                self.r2_owed = True
                return False
            if status != 'ready':
                self.r2_owed = True
                self.macro_mark(f'{tag}决意一直没满,不按R')
                self.logger.warning(f'kxq: {tag} resolve never filled in {self.FLEUR_R2_CAP:.0f}s, '
                                    f'not pressing R (it would switch back to cartethyia)')
                return False
            self.wait_hud_up(tag=f'{tag}前')
            if self.press_r2_verified(tag, rounds):
                _, back = self.wait_anim(tag, self.FLEUR_LIB_ANIM + 4, gone_grace=0.0)
                self.is_cartethyia = True
                self.last_r2_back = back
                self.r2_owed = False
                return True
            rounds += 1

    def press_r2_verified(self, tag, rounds):
        """图标亮着才按 R, 按完看 HUD 掉没掉。图标不亮了就返回 False(回去接着 A)。"""
        for i in range(self.R2_PRESS_TRIES):
            self.task.next_frame()
            if not self.is_lib_big_available():
                self.macro_mark(f'{tag}按前图标不亮(第{rounds + 1}轮x{i})')
                return False
            pressed = self.tap('R', self.EQR_R_HOLD)
            watch_end = pressed + self.R2_PRESS_WATCH
            while time.perf_counter() < watch_end:
                self.task.next_frame()
                if not self.task.in_team()[0]:
                    self.record_liberation_use()
                    self.macro_mark(f'{tag}出手(第{rounds + 1}轮x{i + 1},+{time.perf_counter() - pressed:.2f})')
                    return True
                time.sleep(0.01)
        self.macro_mark(f'{tag}按了没出(第{rounds + 1}轮x{self.R2_PRESS_TRIES})')
        return False

    # ==================== 启动轴 / 循环轴 ====================

    def run_macro(self, name, entry_char, body):
        ciac = self.teammate('Ciaccona')
        chisa = self.teammate('Chisa')
        if ciac is None or chisa is None:
            return False
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.cur = entry_char or self
        try:
            self.macro_start()
            for c in (self, ciac, chisa):
                c.check_f_on_switch = False
            body()
            self.logger.info(f'{name} timeline: {self.macro_timeline()}')
            self.logger.info(f'{name} wall {time.perf_counter() - self.macro_t0:.2f}s')
        except Exception as e:
            self.logger.warning(f'{name} aborted ({type(e).__name__}: {e}) at: {self.macro_timeline()}')
            raise
        finally:
            self.release_all()
            self.task.skip_combat_check = previous
        return True

    def perform_opener(self, entry_char=None):
        def body():
            if self.cur is not self:
                self.quick_switch(self, tag='op起手')
            _, chi_down = self.play_macro(OP_SEG1, 'op', done_mark=False, guard_chisa_e=(OP_CHISA_NORMAL_E,),
                                          guard_chisa_r=(OP_CHISA_R,))
            e_done = self.chisa_enhanced_e(chi_down, OPENER_MACRO[25], OP_CHISA_E, tag='op千咲')
            _, l_down = self.play_macro(OP_SEG2, 'op', start=e_done, done_mark=False, guard_chisa_e2=(OP_SEG2_RECHECK,))
            planned = l_down + (OPENER_MACRO[35][1] + OPENER_MACRO[35][2]) / 1000.0
            con_at = self.chisa_con_before_cart(planned, tag='op千咲')
            _, switch_at = self.play_macro(OP_LAST, 'op', start=con_at)
            sword_at, prepress = self.seg_intro_eqr(switch_at, opener=True)
            r_at = self.seg_sword(sword_at, prepress, opener=True)
            self.seg_small_to_r2(r_at, opener=True)
        return self.run_macro('kxq opener', entry_char, body)

    def perform_loop(self, entry_char=None):
        """循环轴。入口是芙大招演完还在场的卡提。"""
        def body():
            if self.cur is not self:
                self.quick_switch(self, tag='L起手')
            if not self.recover_from_fleur():
                return
            start = time.perf_counter()
            if self.last_r2_back > 0 and start - self.last_r2_back < 3.0:
                gap = start - self.last_r2_back
                start = max(start, self.last_r2_back + self.LOOP_AFTER_R2)
                self.macro_mark(f'L距R2回({gap:.2f}s)')
            _, jump_at = self.play_macro(LOOP_SEG1, 'L', start=start, done_mark=False,
                                         guard_chisa_e=(LOOP_SEG1_CART_E,))
            clear_at = self.ciac_heavy_then_switch(jump_at, tag='L夏空')
            _, chi_down = self.play_macro(LOOP_SEG2, 'L', start=clear_at, guard_lib=True, done_mark=False,
                                          guard_chisa_r=(LOOP_SEG2_CHISA_R,))
            e_done = self.chisa_enhanced_e(chi_down, LOOP_MACRO[13], LOOP_CHISA_E, tag='L千咲')
            _, l_down = self.play_macro(LOOP_SEG3, 'L', start=e_done, done_mark=False, guard_chisa_e2=(LOOP_SEG3_RECHECK,))
            planned = l_down + (LOOP_MACRO[24][1] + LOOP_MACRO[24][2]) / 1000.0
            con_at = self.chisa_con_before_cart(planned, tag='L千咲')
            _, switch_at = self.play_macro(LOOP_LAST, 'L', start=con_at)
            sword_at, prepress = self.seg_intro_eqr(switch_at, opener=False)
            r_at = self.seg_sword(sword_at, prepress, opener=False)
            self.seg_small_to_r2(r_at, opener=False)
        return self.run_macro('kxq loop', entry_char, body)

    def recover_from_fleur(self):
        """循环宏要从小卡、没有显化的状态起手。上一圈没放出 R2 时先补上。

        - 断在芙形态: A 到决意满放 R2。
        - 断在小卡但欠着 R2(上一圈 R 变芙没成功): 显化大概率还在 —— 小卡形态下显化暂停计时,
          不清掉的话这一圈变奏段 EQR 那下 R 会变成切芙而不是变身, 整圈都乱。先 R 变芙再 A 满放 R2;
          还是变不了芙就不管了, 照常起循环宏。
        刚放完 R2 进来的(正常一圈接一圈)不读。决意等不满不按 R, 返回 False(这次 do_perform 什么都不做)。
        """
        if self.last_r2_back > 0 and time.perf_counter() - self.last_r2_back < 3.0:
            return True
        form = self.read_form()
        if form is None:
            form = self.read_form()
        if form is not False:
            if not self.r2_owed:
                return True
            self.r2_owed = False
            self.macro_mark('L上圈欠R2')
            if not self.small_to_fleur(time.perf_counter(), tag='L补变芙'):
                return True
        else:
            self.macro_mark('L起手是芙')
        return self.fleur_r2('L补R2')

    def hand_to_cart(self, entry_char):
        """宏散了而场上不是卡提: 切回卡提, 下一次 do_perform 从循环宏重新起跑。"""
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.cur = entry_char
        try:
            self.macro_start()
            ok = self.quick_switch(self, tag='交回卡提')
            self.logger.info(f'kxq: hand field to cartethyia: {self.macro_timeline()}')
            return ok
        finally:
            self.task.skip_combat_check = previous

    # ==================== 框架接口 ====================

    def do_perform(self):
        if not self.is_in_kxq_cycle:
            return super().do_perform()
        self.check_f_on_switch = False
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 标记要在跑之前落: 中途抛异常也不能让启动轴重跑
            self.opener_armed = False
            self.last_opener = time.time()
            if self.perform_opener(self):
                return
            self.logger.warning('kxq opener aborted, falling back to the native rotation')
            return super().do_perform()
        now = time.time()
        if now - self.macro_yield_logged > 5:
            self.macro_yield_logged = now
            self.logger.info(f'kxq: opener not pending ({blocked}), running the loop')
        if self.perform_loop(self):
            return
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """本队里卡提是两条轴的入口, 宏外面框架要选人时一律先选她。【这里别打日志】。"""
        if self.is_in_kxq_cycle:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_all()
        self.cur = None
        return super().on_combat_end(chars)
