import time

from src.char.BaseChar import SwitchPriority
from src.char.Ciaccona import Ciaccona as NativeCiaccona


class Ciaccona(NativeCiaccona):
    """卡夏千队(卡提希娅/夏空/千咲)里的夏空。非本队时整套走原版。

    【她不驱动任何一段轴】: 两条轴的入口都是卡提, 夏空每次上场都是宏按数字键切进来的。
    框架调到她的 do_perform 就说明宏散了 —— 直接把场子交回卡提, 下一次从循环宏重新起跑。
    宏体在同目录的 Cartethyia.py 里, 自定义角色文件互相 import 不到, 靠 task.chars 拿实例。
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.macro_yield_logged = 0.0

    @property
    def is_in_kxq_cycle(self) -> bool:
        team_members = 0
        for char in self.task.chars:
            if char is not None and char.name in {'Cartethyia', 'Chisa'}:
                team_members += 1
        return team_members == 2

    def macro(self):
        """拿到持宏的卡提实例。【按能力找, 不按名字找】。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'perform_loop') and hasattr(char, 'hand_to_cart'):
                return char
        return None

    def do_perform(self):
        if not self.is_in_kxq_cycle:
            return super().do_perform()
        self.check_f_on_switch = False
        macro = self.macro()
        if macro is None:
            self.logger.warning('kxq cycle: Cartethyia custom code is off, '
                                'falling back to the native rotation')
            return super().do_perform()
        now = time.time()
        if now - self.macro_yield_logged > 5:
            self.macro_yield_logged = now
            self.logger.info('ciaccona: macro drives this team, handing the field to cartethyia')
        if macro.hand_to_cart(self):
            return
        return self.switch_next_char()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """本队里框架选人一律让给卡提。【这里别打日志】。"""
        if self.is_in_kxq_cycle and self.macro() is not None:
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
