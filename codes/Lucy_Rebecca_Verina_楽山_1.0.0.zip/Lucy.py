import ctypes
import threading
import time

from src.char.BaseChar import SwitchPriority
from src.char.Lucy import Lucy as NativeLucy

# ==================== 物理 F 键监视 ====================
# 跟 Changli__Jinhsi__Verina/Changli.py 里那份逐字相同(构建脚本抽的), 说明见那边。
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05   # 一次按键按住的时间远大于这个, 不会漏采
F_LOG_DEBOUNCE = 1.0     # 按住不放时别刷日志
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。

    【没装那张卡片就返回默认值(开, 0 秒)】—— 把队伍导给别人时对方没有 ok_tasks/
    里的那个任务, 功能照常, 只是他那边没有界面可调。
    """
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。

    线程是 daemon, 跟着进程退出, 不用管回收。
    """
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # 【初值取 -1 而不是 0】: 读取方是 `if f_press > self.last_opener`, 而
        # last_opener 的"没跑过"也是 -1。给 0 的话开局第一次判定就恒成立(0 > -1),
        # 会连 use_liberation 那道检查一起跳过 —— 两边都用 -1 表示"从没发生过"才对得上
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    # 【上升沿才算一次按下】。原来是"只要按着就每轮记一次",
                    # 对 _f_last_press(取最新时刻)无所谓, 但下面 _f_pressed_at 是
                    # 给框架消费的, 按住不放时反复刷新会让它永远"刚刚才按"
                    now = time.time()
                    # 【宏正在跑 = 正在战斗, 这下 F 是玩家手动处决, 不是重开副本】(2026-09-11 日志:
                    # 06:17:40 手动处决的那一下 F 打出了 "opener re-armed" —— 下一次进长离就会从头
                    # 跑启动轴)。只在宏空闲时才把 F 当成"重开了一局"
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    # 【这里是本线程和框架的唯一交接点】(2026-08-19):
                    # 框架 CombatCheck.note_f_key() 原本自己调 GetAsyncKeyState,
                    # 判据是【低位】—— 那一位的语义是"距上次调用之间被按过",
                    # 【读一次就清, 而且整个进程共享】。本线程 20 毫秒轮询一次,
                    # 每次调用都会把低位清掉, 框架那边就永远读到 0 ——
                    # 结果是 watcher 一直在打日志, 而"按 F 直接进战斗"从来不触发。
                    # 现在改成【一个读者】: 本线程读键, 顺手把框架要的时间戳也写了,
                    # 框架不再自己读(见 CombatCheck.note_f_key 里的 watcher 分支)。
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return          # 进程收尾时 ctypes/解释器可能已经拆掉了, 安静退出

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


class MacroBroken(Exception):
    """某一步切人没成功, 后面的按键会落在错的人身上 —— 整圈放弃, 交回框架。"""


class Lucy(NativeLucy):
    """露西。露丽维(露西/丽贝卡/维里奈)里她兼任【整条轴的持宏者】, 三个人的 do_perform 都转到 drive()。

    ================= 出处 =================
    露西/丽贝卡两人的流程和数值来自露莫丽(Lucy__Mornye__Rebecca, 2026-09-15 实机逐格调过, 再往前是露丽守);
    第三人按用户要求(2026-09-15)换成维里奈, 流程照龙凤队的维里奈: E -> Q -> R -> 二段跳 -> 空中 A。
    处决只在露西身上按两处(用户): 强化E 之后、回路重击打完后; 变奏入场和露西 E 段那两处去掉。

    ================= 轴的形状 =================
    启动轴: 露 E1 -> R(面板选①-⑤) -> 切维里奈 -> 【一圈】
    一圈(循环轴从维里奈变奏入场那一刻开始):
      维  [变奏入场: 等入场那段冲撞演完] -> E -> Q -> R -> 二段跳 -> 空中 A -> 边 A 边等协奏满 -> 变奏丽贝卡
      丽  (变奏入场) 霰弹E -> 进 CD 马上切露西
      露  E(启动轴只剩 E2 / 循环轴 E1+E2) -> 按住普攻切丽贝卡
      丽  (一直按着) 手枪重击循环到强化重击指示亮 -> [启动轴多一下战术闪避] -> 松手出强化重击 -> 马上切露西
      露  普攻打到 A4 -> 切丽贝卡
      丽  Q -> R -> 机枪里连点(升两次阶) -> 大烟花 -> 满协奏变奏露西
      露  (变奏入场) A 到回路满 -> 强化E(死锁) -> 边 A 边 F: 3A -> Q -> A 到重击指示亮 -> 回路重击 -> 只点 A 等整串打完
          -> 边 A 边 F 到 R 转好 -> R(面板) -> 满协奏变奏维里奈
    宏在【维里奈变奏入场】时返回, 下一次框架调的就是她。她的 QTE 第53F前不响应输入, 框架那一趟往返落在锁里, 不亏时间。
    【处决由宏按的两处, 都在露西身上】: 强化E(死锁)之后到回路重击指示亮之间边 A 边 F(出了处决接着 A);
    回路重击整串打完(松手后 1.8s)到 R 放出去之间边 A 边 F。其余时候玩家手动。
    宏在跑时按的物理 F 不会被当成"重开一局"。

    ================= 帧表结论(鸣潮动作数据汇总.xlsx) =================
    - 露西 E1 命中后自动派生追加(46F), 追加第1F解锁 E2; E2 派生 64F。
    - 露西回路(传输协议)满 100 才能放 E3。E3 在死锁前置(骇入 88F)结束时才清空回路, 之后死锁还有 80F。
    - 露西根协议满解锁强化重击2, 后面整串不可脱手。
    - 露西大招面板: 左键每点一下按顺序选下一个选项, RAM 不够的选项点了没反应, 再点就收起面板;
      面板开着时队伍 HUD 不在。演出 ~3.4s 后才出面板。
    - 丽贝卡霰弹E 第40F 切回手枪。手枪重击循环长按攒狂热, 满了松手 = 手枪强化重击, 切走后照样打完。
      变奏入场实机 ~1.4s 才响应输入。
    - 丽贝卡机枪期间霸体、不能切人, 过载满自动大烟花; 放人时刻游戏说了算(视频 R 后 ~6.9s),
      提前按着切人键等, 放人第一帧就走。
    - 维里奈 QTE 第53F前不响应输入、第84F前不能切人, 给 10 协奏; E-1 第25F 出手、给 30 协奏, E-2 派生 60F;
      大招第106F前不能切人、隐藏 HUD 136F(2.27s)、给 20 协奏; 空中A1/A2/A3 各 ~4.5/4.3/2.0 协奏。
    - 处决演出不藏队伍 HUD(实机), 判不到演出什么时候结束。

    ================= 判断 vs 固定时间 =================
    判断: 协奏满 / 重击指示亮暗 / 回路条满空 / 技能进 CD / 队伍 HUD 消失回来 / 切人到场。
    固定: 露西 E 的站场时长、露西 4A、回路重击的按住和伤害结算、机枪段连点、维里奈 E/Q/R 的间隔和二段跳 ——
    要么没有可读信号, 要么信号本身就是结果。

    ================= 改这个文件之前先读 =================
    - 引擎那一半(macro_* / quick_switch / press_key_until_cd …)由构建脚本从
      Changli__Jinhsi__Verina/Changli.py 逐字抽出来, 那些注释里的角色和日志是别的轴的标定记录。
      fire_r 是本队自己写的: HUD 要【连续】消失几帧才算放出去。
    - 【自定义 __init__ 里跟内置版不同的字段会被打回内置值】, 要保住就在 reset_state() 里重申。
    - 按住左键期间别调 click()/mouse_down()/send_key() —— 它们先投 WM_ACTIVATE。
      丽贝卡按住期间的闪避走 dodge_keep_hold(), 直接投右键消息。
    - 排查用截图(LU_PANEL_SNAPSHOT)默认关着, 代码定稿就关。
    """

    # ==================== 全局节奏(引擎用) ====================
    A_INTERVAL = 0.12
    KEY_INTERVAL = 0.10

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    SWITCH_SETTLE = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True

    # ---- 大招 ----
    LIB_KEY_INTERVAL = 0.03
    LIB_READ_EVERY = 2
    LIB_ANIM_TIME_OUT = 8.0
    LIB_ANIM_TAIL = 0.15
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 连续这么多帧不在 = 演出真的开始了
    HUD_UP_CAP = 1.0             # 按 R 之前等 HUD 在场的上限(防假成功)

    # ---- 协奏 ----
    CON_WAIT_TIME_OUT = 2.0
    CON_POLL_INTERVAL = 0.05
    CON_FULL_LEVEL = 1.0         # 0.99 是环没闭合的哨兵值, 要真满传 1.0
    CON_SAMPLE_MAX = 24

    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40      # 刚切进来多久没见过技能亮就当它在 CD 上

    # ==================== 防重入 ====================
    OPENER_MIN_GAP = 60.0

    # ==================== 露西 · 启动段 E1 -> R ====================
    # 按 E1 -> 等 E 框变成金色的强化E 图标(追加第1F解锁 E2) -> R。视频: 按下 0.12s 出 CD, ~0.5s 变金。
    # E1 只在没被接受(没见到 CD 也没见到金色)时才补发: 露西有输入缓存, 多按的 E 会在追加之后直接放出 E2,
    # 启动轴的 E2 要留到后面
    O_LU_E1_RESEND = 0.45
    O_LU_E2_WAIT_CAP = 2.00      # 等变金的上限; 等不到也照放 R, 日志带金色占比 trace
    # E 框里金色像素(HSV 色相 12~38、饱和度>40、亮度>90)占比超过它算"亮"。
    # 视频实测: 金色实心 0.34~0.43; 白色 E1 / CD 中 / 丽贝卡的 E 全是 0.000;
    # 金环只是变实心前 ~0.2s 的过渡(0.003)。游戏里的技能框可能比图标大一圈、占比被稀释, 所以取 0.10
    LU_E_GOLD_RATIO = 0.10
    LU_E_GOLD_CONFIRM = 2
    LU_R_WINDOW = 1.50

    # ==================== 露西 · 大招面板 ====================
    # 面板操作(放大视频图标看清的): 左键 = 对被标记目标执行当前选中的选项, 滚轮 = 上下切换选项。
    # 用完一项光标会自己跳到下一项, 所以正常情况下一直点左键就行; 可光标停在受限/RAM 不够的项上时
    # 左键永远没反应, 只能等面板 648F 超时 —— 实机 2026-09-14 循环轴点了 81 下 14.8s 才关。
    LU_PANEL_CLICK_INTERVAL = 0.17   # 视频手速。面板里点太密可能在选项刷新前被吞
    LU_PANEL_CAP = 16.0              # 演出 ~3.4s + 面板最长 648F(10.8s) + 收起
    LU_PANEL_BACK_CONFIRM = 2        # HUD 连续回来这么多帧才算面板收了
    LU_PANEL_OPEN = 3.40             # 从 R 放出去到面板出来(视频 3.34s)
    LU_PANEL_PLAIN = 2.20            # 面板出来后先只点左键这么久; 启动轴实机 5.4s 就收起了, 碰不到扫描
    LU_PANEL_SCAN_STEP = 0.45        # 之后每这么久滚一格再接着点(一格之间能点两下)
    LU_PANEL_SCAN_SPAN = 7           # 先往下滚这么多格, 再往上滚这么多格, 循环; 不管滚轮会不会绕回都能扫到每一项
    # 【面板里的左键必须带坐标】: PostMessage 后端不带坐标的点击落在"上一次带坐标点击的位置"(没有就是左上角),
    # 战斗里无所谓, 面板是能用鼠标点的界面, 点偏了就不算执行 —— 实机 2026-09-14 L2/L3 选项预选好了还愣 14.8s。
    # 轮流点屏幕正中(准星)和右下角"左键执行骇入"按钮(视频量的相对位置)。面板收起后这两处点下去就是普攻
    LU_PANEL_CLICK_POINTS = ((0.50, 0.50), (0.827, 0.798))
    # 排查用截图总开关(每张 ~4MB 存到 logs/): 面板到扫描阶段还没收起、露西变奏入场 LU_FILL_SNAPSHOT_AT 秒还没判到回路满。
    # 分享出去之前关掉(用户 2026-09-15), 要排查时改 True
    LU_PANEL_SNAPSHOT = False

    # ==================== 协奏(交棒前等满, 各格共用) ====================
    INTRO_CON_ENOUGH = 1.0       # 0.99 是环没闭合的哨兵值, 要真满
    INTRO_CON_FULL_CONFIRM = 3   # 连着几帧读到满才算, 一个假的满会把交棒提前
    INTRO_CON_SETTLE = 0.50
    INTRO_CON_POLL = 0.03
    INTRO_CON_CAP = 6.0

    # ==================== 维里奈 ====================
    # 流程(用户 2026-09-15): E -> Q -> R -> 二段跳 -> 空中 A; 协奏满就变奏丽贝卡, 不满就接着 A 到满。
    # 数值照搬龙凤队 Changli.py 的 VR_*(那组出自赞菲维 Zani.py 实机调好的 V_*), 只放宽了 E 的上限:
    # 循环轴她是变奏入场, QTE 第53F(0.88s)前不响应输入, 锁里按的 E 全被吞
    VR_E_CAP = 2.20
    # 循环轴(变奏入场): 入场自带一段冲撞攻击(QTE-冲 53F 出手 -> QTE-撞 派生 41F, 地转空), 打完落地之前按 E 放不出来,
    # 期间点的 A 会接着打。实机 2026-09-15 循环轴: 边点 A 边连按 23 下 E、2.2s 没进 CD, R 也没放, 协奏只到 0.47 整圈断掉。
    # 所以到场后什么都不按等 VR_INTRO_TO_E, 再只按 E(不点 A)到进 CD; 被吞的几发不花钱, 上限盖过落地
    VR_INTRO_TO_E = 1.60
    VR_E_CAP_INTRO = 3.00
    VR_E_TO_Q = 0.05
    VR_Q_WINDOW = 0.20
    VR_Q_TO_R = 0.10
    # R(用户 2026-09-15): R 和 A 错开帧一起连发, 到队伍 HUD 连续消失(大招出来了)为止, VR_R_CAP 封顶。
    # 原来是"只按 R 2s -> A 1s -> 再按 R", R 没转好时人愣在原地; R 优先级高, 能量一够就打断普攻放出来,
    # 没转好的那段正好在打怪攒能量。只改维里奈: 露西/丽贝卡的 R 前后有强化重击和面板, 不能乱点 A
    VR_R_KEY_INTERVAL = 0.12
    VR_R_CAP = 10.0
    VR_JUMP_GAP = 0.30           # 两下跳之间(二段跳, 把人抬到能连打空中 A 的高度)
    VR_JUMP_SETTLE = 0.16        # 第二跳到第一下空中 A
    VR_AIR_A = 0.95              # 空中 A + 落地 A
    # 协奏: 变奏 10 + E 30 + R 20 + 空中 A 每下 ~4; 没打满的轮次边 A 边等, 满了立刻切。这是兜底上限
    VR_CON_CAP = 6.00
    # 切给她之后只看一小段 HUD 会不会藏; QTE 的输入锁由 E 的连发盖过去
    VR_INTRO_ANIM_CAP = 6.0
    VR_INTRO_NOANIM = 0.35
    VR_SWITCH_ANIM_HINT = 1.00   # 切人本身花了这么久才判到到场 = 演出已经在里面演完

    # ==================== 丽贝卡 · 变奏入场霰弹E ====================
    # 视频逐帧: 霰弹E 出手 40F 后 E 图标从霰弹换成手枪, 出手后 ~1.2s E 上才出现 CD 数字。
    # 实机 2026-09-14 上限 1.3s 时一直没读到 CD、E 也没出来就切走了 -> 上限放宽、按键放慢
    RB_E_CAP = 2.40              # 连按 E 等它进 CD 的上限
    RB_E_INTERVAL = 0.15         # 视频手速 ~0.2s 一下
    RB_E_SETTLE = 0.25           # 到场头这么久技能栏还是上一个人的, 读数不算
    RB_E_TO_SWITCH = 0.70        # 读不到 CD、按满上限之后再等这么久才切(霰弹E 第40F 才切回手枪)
    # 丽贝卡的处决放在变奏入场霰弹E 【之前】(用户 2026-09-15 实机: 放在 E 之后的话, 出了处决会把 E 吞掉)。
    # 到场头 RB_E_F_LEAD 秒只按 F 不按 E, 之后才按 E。出了处决, 演出里按的 E 也被吞: 一直按到 E 进 CD, 上限放宽; E 放出去马上切人。
    # 1.00 -> 1.60(实机 2026-09-15): 1.0s 那版 F x7 一次没处决上 —— 丽贝卡变奏入场 ~1.4s 才响应输入:
    # 从 0s 连按 E 时进 CD 在 1.53~1.72s, 从 1.0s 才按 E 进 CD 还是 1.60s; 0.9s 那次图标变化是入场动作结束, 不是 E 出手。
    # 所以 1.0s 前的 F 全落在入场锁里被丢。1.6s 起按 E ≈ E 推后 0.2s, F 在锁结束到 1.6s 之间才有效, 间隔压密一点
    # 不点 A: 点击会带过切人落到露西身上, 把她的 E 往后推
    # 关掉(用户 2026-09-15): 1.6s 那版霰弹E 之前连按 15 下 F 一次没处决上 —— 提示要霰弹E 打中那一下才出来。
    # 处决挪到下一段露西(LU_E_F): 丽贝卡恢复成进场就按 E, E 进 CD 马上切人
    RB_E_F = False
    RB_E_F_LEAD = 1.60
    RB_E_F_INTERVAL = 0.08
    RB_E_CAP_F = 4.50            # 开 F 时从开始按 E 算的上限(要盖过处决演出)
    RB_E_TO_LU_TIME_OUT = 4.00   # E 刚放出去/演出刚结束切人可能要多等一会

    # ==================== 露西 · E ====================
    O_LU_E2_STAY = 1.15          # 启动轴只有 E2: 派生 64F(1.07s)
    L_LU_E12_STAY = 1.95         # 循环轴 E1+E2: 46F + 64F = 110F(1.83s), 视频 2.04s
    # E 段按图标走: [E1 -> 等 E 图标变金(E2 解锁)] -> 连按 E 到金色消失(E2 放出去) -> 站满 stay -> 按住切丽贝卡。
    # 实机 2026-09-14 循环轴 E2 偶尔没出来: 旧写法固定连按 1.2s 且"回路读到满就停手", E1 出得晚或回路先满都会漏 E2。
    # 【金色消失一次就停手】: E2 放完回路可能刚好满, 再按会当场放出强化E(死锁锁切人)
    LU_E_SETTLE = 0.25           # 到场头这么久技能栏还是丽贝卡的, 读数不算
    LU_E2_GOLD_CAP = 1.60        # 按完 E1 等变金的上限(视频 ~0.5s)
    LU_E2_PRESS_CAP = 1.40       # 连按 E2 到金色消失的上限
    # 实机 2026-09-14 两种漏 E2: ① 循环轴进场时 E 框被特效染成金色, 宏以为 E2 已解锁跳过了 E1, 按一下金色没了又当成 E2 出去;
    # ② E1 读到 CD 了, 1.6s 里没判到变金。所以:
    #   - 循环轴一律先按 E1(上一圈 E2 用掉了, 进场时不可能已解锁), 只有启动轴直接按 E2;
    #   - 金色只在【E 框没有 CD 数字】时才算(真的强化E 图标上没有数字, 特效扫过去数字还在), 连续 3 帧;
    #   - E2 出去 = 金色消失且出现 CD 数字; 读不到数字时要连续暗 6 帧
    LU_E2_GOLD_CONFIRM = 3
    LU_E2_GOLD_AFTER_CD = 0.25   # E1 进 CD 之后这么久才开始认金色(追加第1F才解锁)
    LU_E2_GOLD_NO_CD_AFTER = 0.45  # CD 数字一直读不到时, 从第一发 E1 起这么久才认金色
    LU_E2_DARK_NO_CD = 6
    LU_E_INTERVAL = 0.10
    # 处决放在这一段(用户 2026-09-15): 丽贝卡霰弹E 打中才出处决提示, 切过来的露西先只按 F 一小段, 处决完再 EE。
    # 处决演出不藏队伍 HUD, 判不到演出什么时候完 —— 等变金 / 按 E2 的上限各加 LU_E_F_EXTRA_CAP 盖过演出(E 放出去就停, 正常不花时间);
    # 站场时长从开始按 E 算, E2 放出去之后至少再站 LU_E2_MIN_TAIL 才按住切人(正常流程实测这一截就是 ~0.73s)
    # 露丽维(用户 2026-09-15): 这一处处决去掉, 只留露西变奏入场那一处; 代码留着, 改 True 恢复
    LU_E_F = False
    LU_E_F_WINDOW = 0.35
    LU_E_F_INTERVAL = 0.06
    LU_E_F_EXTRA_CAP = 2.50
    LU_E2_MIN_TAIL = 0.70

    # ==================== 丽贝卡 · 长按 ====================
    RB_HOLD_SETTLE = 0.40        # 到场头这么久的指示读数不算(技能栏还是露西的)
    RB_HOLD_CONFIRM = 2
    RB_HOLD_CAP = 7.00           # 视频: 循环轴 3.5s, 启动轴(狂热从低位攒, 带两下闪避)5.3s; 处决演出不算在内
    # 长按期间隔一会按一下 F(用户 2026-09-15: 有处决就处决, 处决完接着 A 不耽误); 没处决时 F 什么都不触发。
    # F 不走 send_key(PostMessage 后端会先投 WM_ACTIVATE 把按住打断), 走 rb_send_f_keep_hold
    # 用户 2026-09-15 改成在丽贝卡变奏入场的霰弹E 之后处决(见 RB_E_F), 长按这里先关掉; 代码留着, 改 True 就恢复
    RB_HOLD_F = False
    RB_HOLD_F_INTERVAL = 0.25
    # 到场后多久才开始按 F(用户 2026-09-15: 别处决那么快)。原来 0.4s 就按; 狂热正常 3.1~4.1s 攒满。
    # 实机那局三次长按都是 处决x0 但 F 确实发出去了 —— 处决演出不藏队伍 HUD, 判不到演出, 不影响长按
    RB_HOLD_F_START = 1.50
    O_RB_TACTICAL_DODGE = True   # 启动轴满狂热后打一下战术闪避再松手, 多的协奏让大烟花之后直接满
    RB_DODGE_TO_RELEASE = 0.70   # 手枪战术闪避派生 36F
    # 松手 -> 切露西。循环轴视频松手 0.16s 就切(强化重击切走后照样打完); 启动轴(带战术闪避)视频是 1.0s。
    # 实机 2026-09-14 启动轴也用 0.15 时, 露西进场没马上出 A、打不到 A4 —— 切人压在了强化重击起手里
    O_RB_RELEASE_TO_SWITCH = 1.00
    L_RB_RELEASE_TO_SWITCH = 0.15
    # 上面两个现在是【读不到指示时的上限】: 松手后狂热指示连续两帧暗 = 强化重击起手吃掉了狂热, 再等这么久就切。
    # 实机 2026-09-15 启动轴松手到露西到场 1.09s, 用户嫌慢; 1.0s 是为了别在强化重击起手前切走(0.15 时露西进场不出 A)
    RB_DARK_TO_SWITCH = 0.10

    # ==================== 露西 · 4A ====================
    # 从到场起连点, A4 出手时切。视频 2.16~2.33s; 帧表 A1~A3 派生累计 ~2.0s 才轮到 A4。
    # 实机 2026-09-14 用 2.10 打不到 A4
    LU_4A_WINDOW = 2.50

    # ==================== 丽贝卡 · QR ====================
    RB_Q_WINDOW = 0.10
    RB_Q_TO_R = 0.05
    # 实机 2026-09-14: 1.5s 窗口里判不到演出(R_NOFIRE), 可紧接着 HUD 就消失了 —— R 是放出去了、起得晚。
    # 宏以为没放, 跳过机枪段直接切露西, 机枪+大烟花期间不放人, 5s 超时整圈判失败
    RB_R_WINDOW = 3.00
    RB_R_LATE_GRACE = 1.00       # 窗口结束后这么久内 HUD 连续消失也算 R 放出去了
    # 放 R 前能量保底(用户 2026-09-15): 放完 Q 读 R, 没转好 -> 强化重击指示还亮就补一发强化重击, 否则平 A, 转好了才按 R。
    # 能量不够一般是前面那发强化重击被打断了(狂热还满着, 大招回收 12~18 那一大笔没进账)
    RB_R_READY_SETTLE = 0.30     # 到场这么久之内的 R 读数不算(技能栏还是露西的)
    RB_R_BUILD_CAP = 20.0        # 攒能量的防卡死上限(打不到怪时永远攒不满)
    RB_R_BUILD_SLICE = 1.00      # 平 A 每轮时长, 之后再读一次 R
    RB_R_HEAVY_MAX = 2           # 最多补几发强化重击
    RB_HEAVY_PRESS = 0.65        # 按住过手枪重击-2 发生帧(32F)再松, 狂热满时松手出强化重击
    RB_HEAVY_DMG = 1.35          # 强化重击伤害-5 在 78F; 这段不点不按 R —— R 优先级高, 会把它打断
    RB_MG_CLICK_INTERVAL = 0.17  # 机枪里点普攻升阶
    RB_MG_R_EVERY = 0.90         # 顺带隔一会按一下 R(同样能升阶); 大招已放, 按了不会出别的
    RB_MG_BEFORE_SWITCH = 5.30   # 从开始按 R 起算, 之后边点边按切人。游戏 ~6.9s 放人
    RB_SWITCH_TIME_OUT = 9.00    # 要盖过 R 起得晚 + 机枪 + 大烟花; 放人第一帧就走, 给长不花钱
    # 协奏保底(用户 2026-09-15): 正常情况不用等大烟花打中协奏就是满的; 前面强化重击没打中怪才会差一截。
    # 所以【QR 入场时】读一次协奏: 低于 RB_CON_LOW -> 这圈等机枪+大烟花放完、协奏真满了再切露西;
    # 不低 -> 最后一枪打完游戏一放人就切(原来的写法)。不满就切的话露西没有变奏入场, 收尾整段全乱
    RB_CON_LOW = 0.75
    RB_CON_READ = 0.15           # 入场读协奏的时长(读到的最大值)
    RB_R_END_CAP = 8.00          # 等机枪 + 大烟花放完(队伍 HUD 回来)的上限
    RB_CON_WAIT_CAP = 4.00       # HUD 回来后等协奏满(大烟花打中)的上限, 到了也照样切

    # ==================== 露西 · 收尾 ====================
    LU_FILL_SETTLE = 0.40
    LU_FILL_CONFIRM = 2
    # 变奏入场 A 到回路满的上限; 视频启动轴 ~2.1s, 循环轴 E1+E2 之后几乎是满的。
    # 这段开 F(LU_F_ON_INTRO)时要放宽到 6.50 —— 处决演出期间 A 不涨回路、演出又不藏 HUD 扣不掉,
    # 4s 到点回路没满会盲按出普通 E1(干跑抓到过)。现在这里不按 F, 回到 4.00
    LU_FILL_CAP = 4.00
    LU_FILL_SNAPSHOT_AT = 0.80   # 到场这么久还没判满就存一张画面到 logs/(排查"强化E 好了却在等")
    LU_E3_PRESS = 0.60           # 强化E 每次只连发这么久, 之后等回路清空(死锁里多按的 E 会进缓存)
    # 骇入 88F 结束才清空回路; 实机按完到判到清空 0.94~1.46s。等不到 = 按的时候被打断、强化E 没出去,
    # 重按(用户 2026-09-14: 被打断就愣住了 —— 日志 `回路清空(CAP,2.52s)` 之后直接去打 3A)
    LU_E3_CLEAR_CAP = 2.20
    LU_E3_TRIES = 4
    # 判到回路满之后连按 E, 按到【队伍 HUD 连续消失】(或 E 框出 CD 数字)就停, 最长这么久。
    # 【要盖过 A3 的「第46F前禁用E」(0.77s)】: 回路常在连点打出 A3 的那一刻满, 实机 2026-09-14 23:04 启动轴
    # 旧版只按 0.6s 全落在禁用期里 -> 判成被打断 -> 干等 2.2s 重按(用户: 都好了还等 1~2s)。
    # 实机 23:17: 强化E 一出手队伍 HUD 就没了(trace 按完第一下之后再没读数) —— 这是最快的"出去了"信号;
    # 用 E 框图标差分判过一版, 回路刚满时 E1 图标换成强化E 图标本身就差 62~86, 按两下就误判成出去了
    LU_E3_PRESS_CAP = 1.20
    LU_E3_TAIL = 1.10            # 清空之后死锁还有 ~80F, 视频量到 ~1.1s 恢复连点
    LU_E3_BLIND = 2.60           # 读不到回路条时从按 E 起算的固定等待
    LU_3A_WINDOW = 0.65
    LU_Q_WINDOW = 0.30
    LU_Q_INTERVAL = 0.14
    LU_HEAVY_FILL_CAP = 3.00     # A 到重击指示亮(根协议满)的上限; 视频 ~1.7s
    # 强化E(死锁)之后的 3A 和 A 到重击亮这两段边 A 边 F(用户 2026-09-15): 接上处决也不耽误后面 A 出回路重击。
    # 读到重击指示亮就 A 和 F 都停, 马上长按; 处决演出扣不掉, 开着时 A 到重击亮的上限用 LU_HEAVY_FILL_CAP_F
    LU_E3_AFTER_F = True
    LU_E3_AFTER_F_INTERVAL = 0.15
    LU_HEAVY_FILL_CAP_F = 5.00
    # 3A 之后那发 Q 常被处决演出吞掉(干跑两圈都丢): A 到重击亮那段每这么久补按一下 Q。
    # 用户 2026-09-15: 露西的 Q 不打断攻击, 随时可以补按; 落在 CD 上是空操作
    LU_E3_AFTER_Q_INTERVAL = 0.50
    LU_HEAVY_HOLD = 1.00         # 回路重击按住时长, 视频 1.03s
    # 回路重击保底(用户 2026-09-14: 被打断就不打了): 松手后重击指示还亮 = 没打出去, 再按; 等伤害之后、放 R 之前也各查一次
    LU_HEAVY_RETRY = 3
    LU_HEAVY_VERIFY = 0.50       # 松手后等指示暗的时长; 强化重击2 起手就清空根协议, 按住 1s 早该暗了
    # 按住期间就盯指示: 暗了 = 接住了(强化重击2 起手清空根协议), 从那一刻再按够 LU_HEAVY_HOLD_AFTER 松手, 让强化重击3 整串打完;
    # 按下 LU_HEAVY_REGRIP_AT 秒还亮 = 没接住, 松开重按, 最多 LU_HEAVY_REGRIPS 次。
    # 0.45 -> 1.20(实机 2026-09-15 露莫丽): 接住的轮次指示多在按下后 0.45~0.57s 才暗, 跟 0.45 的重按贴得分不清是谁起的作用;
    # 而没接住的轮次每 ~0.5s 重按一次、指示全程亮 2s, 两发加起来空按 ~5s —— 重按太勤会把正要成立的长按打断
    LU_HEAVY_HOLD_AFTER = 0.95
    LU_HEAVY_REGRIP_AT = 1.20
    LU_HEAVY_REGRIPS = 1         # 重按一次还不行就松手让 lu_ensure_heavy 重来; 2 次时真接不住的一轮要空按 ~3.7s
    # A 到重击指示亮那一段点慢一点, 读到亮的第一帧起就不再点(用户: 强化重击好了刹不住车) ——
    # 多点出去的强化普攻要演完, 重击的按下会压在那个动作里
    LU_HEAVY_A_INTERVAL = 0.20
    LU_HEAVY_HOLD_CAP = 4.00
    # 回路重击松手之后: 整串是强化重击2(派生50F) -> 强化重击3 下落(30F) -> SQL落地(结束80F), 按住 1s 之后还要 ~1.7s 才打完。
    # 头 LU_HEAVY_A_ONLY 秒只点 A 不看 R(整串没打完, 这时按 R 会被吞或打断出伤), 之后边 A 边读 R, 转好就放。实机 R 在松手后 ~3.6s 转好
    # 2.60 -> 1.10(用户 2026-09-15 实机: 回路重击结束开 R 缩短 1.5s)。日志里 2.6s 等完 R 早就好了(A等R 0.10s 就读到),
    # 这段全是白等; 正常流程重击打完能量就够。R 没好就走下面边 A 边读 R, 好了马上放
    # 回路重击松手后: 头 LU_HEAVY_NO_F 秒只点 A 不按 F, 之后边 A 边 F 至少 LU_HEAVY_F_MIN 秒, 再边 A 边 F 等 R 转好。
    # 实机 2026-09-15 露丽维: 松手就边 A 边 F, 处决把回路重击打断了(用户)。露莫丽同一段代码没出事, 是因为那边露西变奏入场 /
    # E 段已经把处决用掉了, 到这里提示不在。整串: 强化重击2 派生50F -> 强化重击3 30F -> SQL落地 80F, 从强化重击2 起手
    # (指示暗)算 2.67s; 按住在暗后 0.95s 松手 -> 松手后还要 ~1.72s 才打完。露丽守当时"处决打断重击"定的 1.80 就是这条线
    LU_HEAVY_NO_F = 1.80
    LU_HEAVY_F_MIN = 0.30
    LU_R_WAIT_CAP = 4.00         # 边 A 边等 R 转好的上限(不算处决演出), 超时也照样去按 R; 跟上面加起来仍盖到松手后 ~5s
    LU_F_ANIM_CAP = 5.00         # 处决演出(队伍 HUD 消失)等回来的上限
    LU_HEAVY_MASH_INTERVAL = 0.17
    # 处决(用户 2026-09-15): 挪到露西变奏入场之后 —— A 到回路满那段边 A 边 F; 回路重击之后不再按 F, 打完直接接 R。
    # 放在强化E 之前: 处决演出里按的 E 被丢掉, 演出结束接着判回路满再按; 放在回路重击之后会把整串打断, 还拖慢 R
    # 露丽维(用户 2026-09-15): 变奏入场这处去掉, 改到强化E 之后(LU_E3_AFTER_F); 代码留着, 改 True 恢复。
    # 再打开的话 LU_FILL_CAP 要放宽: 处决演出不藏 HUD, 演出时间扣不掉, 到点回路没满会盲按出普通 E1
    LU_F_ON_INTRO = False
    # 变奏入场后至少边 A 边 F 这么久才开始按强化E(用户 2026-09-15): 实机循环轴回路条进场 0.45s 就读到满, F 只按了不到半秒,
    # 大半落在入场不响应输入里 —— A 没打出去处决提示就不出来, 几轮里只有一次先出了处决
    # 1.00 -> 1.20(用户 2026-09-15: 还是有没处决上的)。日志 F 每 ~0.25s 一下, 提示出来一定按得到;
    # 那一轮 1s 窗口里一次处决演出都没有 —— 是提示在 1s 里还没出来, 不是频率不够
    LU_F_MIN_WINDOW = 1.20
    # 回路重击松手后到 R 放出去之前边 A 边 F 给处决(用户 2026-09-15); F 的间隔。A 用 LU_HEAVY_MASH_INTERVAL
    LU_HEAVY_F_INTERVAL = 0.12
    LU_R_WINDOW_FINAL = 2.50
    # 窗口结束后这么久内 HUD 连续消失也算 R 放出去了(R 在窗口最后一刻才被接受时判不到, 会跳过面板直接切人卡死)
    LU_R_LATE_GRACE = 1.00
    # 收尾的 R 必须放出来(用户 2026-09-14: 前面被打断能量没攒够, 没放 R 就切人了)。
    # 按不出来就攒能量(回路重击 > 声骸 > 普攻)再按, 循环到出手; 上限只防打不到怪时永远攒不满
    LU_R_ENSURE_CAP = 25.0
    LU_R_BUILD_SLICE = 1.20      # 每轮攒能量的连点时长
    LU_R_RETRY_WINDOW = 1.00     # 补救时每次按 R 的窗口
    LU_R_BLIND_EVERY = 3         # R 读成暗时只攒不按, 每这么多轮盲按一次(防读数不准); 按 R 那 1~2s 是不打怪的
    LU_R_BLIND_WINDOW = 0.40     # 盲按只按这么久、不等"晚到" —— 实机 2026-09-15 进保底先盲按 2.5s+等晚到 1s, 3.5s 一下 A 没点
    LU_F_BREAK = False           # 处决玩家手动按。改 True 就在面板收起后连按 F
    LU_F_WINDOW = 1.10
    LU_F_INTERVAL = 0.20
    LU_TO_VR_TIME_OUT = 4.00    # 处决动画里不放人

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.poking = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        # 内置非治疗角色默认 True, 换类时会被打回, 所以在这里重申
        self.check_f_on_switch = False
        start_f_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_lrv(self) -> bool:
        """本队 = 露西 + 丽贝卡 + 维里奈。按类名判。"""
        team_members = 0
        for char in self.task.chars:
            if char and char.name in {'Rebecca', 'Verina'}:
                team_members += 1
        return team_members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        # 物理 F 刚按下、还在等怪那一小段也算待跑: 这时框架选人要让露西上, 不能交给维里奈
        return self.opener_blocked_by() is None or self.opener_f_wait_left() > 0

    def opener_f_wait_left(self):
        """物理 F 按下之后还要等怪多久(秒); 不在等就返回 0。条件跟 opener_blocked_by 里 F 那一段一致。"""
        if not self.is_in_lrv or not self.opener_armed:
            return 0.0
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press <= self.last_opener:
            return 0.0
        return max(0.0, f_settings(self.task)[1] - (time.time() - f_press))

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。不查任何技能可用性(场下读数是旧的)。"""
        if not self.is_in_lrv:
            return 'team is not lucy/rebecca/verina'
        if not self.opener_armed:
            return 'already armed-down (ran once this combat)'
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 宏原语(引擎) ====================
    # 从 Changli__Jinhsi__Verina/Changli.py 逐字抽出来的, 注释里的实机数据是那几条轴的
    def macro_wait(self, sec):
        """精确等待, 【不点击】。

        不走 executor.sleep —— 它每 0.4 秒无条件插一次 next_frame 截图, 插入位置
        不可控, 而这条轴的容错在 ±0.1 秒级。切成 0.1 秒一片, 片间检查任务是否被停用。
        """
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def macro_gap(self, sec, tag=None):
        """间隙。【持续普攻打开时自动变成连点】—— 这就是"我没说停就一直A"。"""
        if sec <= 0:
            return 0
        if not self.poking:
            self.macro_wait(sec)
            return 0
        return self.macro_spam(sec, self.A_INTERVAL, tag=tag or 'gapA')

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A', sample=None, sample_every=2,
                   max_clicks=None):
        """连点一个窗口。

        打出几段由 window 决定, 不由单次点击的时机决定 —— 动画期间的点击会被丢掉,
        连点保证总有一下落在动画刚结束的瞬间。时间轴上记首尾和点了几下, 对着录像
        能反推一段动画多长: 窗口里打出 n 段, 一段就约等于 window/n。
        """
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        # 次数上限: 光靠时间兜底的话, interval 被调成 0 或者机器卡一下就会瞬间
        # 灌进去几千次点击
        cap = int(window / max(interval, 0.01)) + 2
        # 【可以再封一层】: 用在【空中】那几格 —— 多余的点击会变成下落攻击,
        # 落地会打断/改变后面的动作。封顶【不缩短窗口】, 所以不花时间
        max_clicks = cap if max_clicks is None else min(cap, max_clicks)
        self.macro_mark(f'{tag}_start')
        self.spam_samples = []
        while time.time() - start < window and n < max_clicks:
            self.click()
            n += 1
            if sample is not None and n % sample_every == 0:
                self.spam_samples.append(f'{time.time() - start:.2f}:{1 if sample() else 0}')
            # 最后一段等待按剩余时间裁剪, 别整个 interval 等下去 —— 那是白送的延迟
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            self.macro_wait(min(interval, remaining))
        self.macro_mark(f'{tag}_end(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=None, presses=None,
                 click_interval=None, stop_when=None):
        """在一个窗口里反复发同一个技能键, 用来盖住动画那一段。

        动画期间的按键是被丢掉的、不排队, 所以单发必丢 —— 这个形状在爱琳莫那条轴上
        踩到过六次, 症状统一是"那一步慢了"(要等整个动画演完才有第二次机会)。

        【必须在这个角色自己的回合里跑完, 不要跟切人并行】: 切人期间发出去的键会被
        游戏带过换人边界落在新角色身上。点击可以并行(quick_switch 的 click_during),
        技能键不行。唯一的例外是 switch_into_lib()。

        Args:
            poke: 发键期间要不要照常点普攻。默认跟随全局的持续普攻开关。
            click_interval: 点普攻的间隔, 默认 A_INTERVAL。给 A_INTERVAL_FAST
                就是"技能键按自己的节奏、普攻按加密节奏", 两条流互不影响。
            stop_when: 每发一次键之后调一次, 返回 True 就停。用在【多按一下会
                烧掉后面要用的充能】的地方 —— 一旦读到技能已经不可用就立刻收手。
                【会读屏, 别配太密的 interval】。
            presses: 只发这么多次, 均匀铺在窗口里。用在"连续点按两次E"那种
                【次数本身有意义】的地方 —— 连发会把两发挤成一发。
                【给了 presses 就由它说了算, window 只用来推间隔】: 否则
                window=0(要求两发贴着发)会在第一发之后就把循环停掉, 变成单发。
        """
        interval = self.KEY_INTERVAL if interval is None else interval
        poke = self.poking if poke is None else poke
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if stop_when is not None and stop_when():
                break
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            # 发键的节奏和点击的节奏各走各的 —— 挂在一起的话点击会被技能键的
            # 间隔卡住(爱琳莫那边 R 被 E2_POLL 卡住就是这个)
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + click_interval
                self.macro_wait(min(0.02, step_end - time.time()))
        # 【点击数也要打进去】: x{n} 只数了技能键, 看不出这段时间有没有在持续普攻。
        # 用户 2026-08-16 问过一次"E的期间也要一直普攻" —— 实际一直在点,
        # 只是日志里看不见。A x0 就是真的没点(poke=False 的那几格)
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def release_attack(self):
        if self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def quick_switch(self, target, click=False, click_during=None, settle=None, time_out=None,
                     read_con=False, assume_con=False, click_interval=None,
                     click_first=False):
        """按数字键直切给指定角色。

        不走 switch_next_char(): 那个要先跑 _choose_switch_target 选人, 顺序是框架
        说了算; 而且它每次发数字键都跟一次左键, 想不要那下 A 就没法不要。

        Args:
            click: 到场之后补一下普攻(复刻框架 BaseCombatTask.py:644 的行为)。
                这条轴上一般不用 —— 持续普攻本身就在点, 再补就是多推一段连段。
            click_during: 等换人生效的这段时间里继续点。默认跟随持续普攻开关。
                这就是用户说的"狂点普攻切人": 换人不是瞬间的, 这几下落在上一个
                角色身上, 正好把他最后那一段打出来。
            read_con: 按键之前读一次协奏, 决定要不要按"带变奏"记账。
                【不便宜】(能量环连通域分析), 只有真的要变奏的那两三处才传 True。
            assume_con: 不读屏, 直接按满协奏记。用在【刚放完大招】之后 ——
                那时协奏必满, 而演出期间能量环读数不可信。

        Returns: 是否真的切过去了。
        """
        if target is None:
            return False
        if target is self.cur:
            # 目标已经在场。【这里必须早退】: 不早退的话到场判据立刻成立,
            # 整步 50 毫秒走完, 后面那些"给他的"按键其实发在了别人身上
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        settle = self.SWITCH_SETTLE if settle is None else settle
        click_during = self.poking if click_during is None else click_during
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        source = self.cur if self.cur is not None else self
        # 【第一个数字键要抢在读协奏之前发】: 读协奏是能量环的连通域分析, 少则
        # 二三十毫秒、睡完之后的第一次读屏能到 0.86 秒 —— 夹在"上一个动作"和
        # "数字键"之间就是白白的延迟。切人本身要 0.06~0.11 才落地, 来得及读完
        slot = target.index + 1
        # 【记下第一个数字键的时刻】: 有几格是靠它当锚点的。
        # 用户逐帧量的都是"从切人到 A 出手", 而窗口默认从【检测到到场】算起 ——
        # 中间隔着切人生效 + 读屏确认, 两者差好几十毫秒
        self.switch_press_at = time.time()
        # 【先点几下再发第一个数字键】(click_first = 点几下)。用在"边打A边不停切人"
        # 的格子上: 游戏在角色动作期间会拒绝切人 —— 这正是那种写法不会掐掉 A 的原因。
        # 但如果这一刻场上角色【刚到场、还没起手】, 切人键就没有东西挡着, 会当场生效,
        # 她一下都不打就走。
        # 【一下不够】(用户 2026-08-16: "这里千咲又没A出来了"): 那一下要是没被接受
        # 就白给了。所以改成可以指定点几下 —— 每多一下只把切人键推迟一个
        # click_interval(0.06), 但多一次撞上"能出招的那一帧"的机会
        for i in range(int(click_first)):
            self.click()
            if i + 1 < int(click_first):
                self.macro_wait(click_interval)
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            con_full = bool(source.is_con_full())
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start   # 第一个数字键已经在上面发过了
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            # 点击的节奏跟切人键解耦: 切人键 0.03 秒一发, 点击照旧 A_INTERVAL,
            # 否则这段时间会以 0.03 的密度灌点击, 远低于安全下限
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + click_interval
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            # 【count 不达标的 index 打折扣, 但不能一票否决】: in_team() 在只找到
            # 一个槽位文本时照样返回 True 和一个 index(那是渲染顺序的产物);
            # 但一票否决会造成假失败 —— 有槽位被特效盖住时 count 就是不达标,
            # 切人明明成功了也判不出来, 卡满超时, 整条轴从这里崩
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace:
                    self.logger.info(f'switch trace -> {target.name}: {" ".join(trace)}')
                if click:
                    self.click()
                    self.macro_mark(f'{target.name[:3]}A')
                self.macro_gap(settle)
                return True
        # 【失败时更要打 trace】:
        #   一直是旧角色的 index  -> 游戏真的在拒绝切人(上一个动作还没演完)
        #   带 ? 的都是目标 index -> 切过去了, 是 count 判据把它挡住了
        #   全是 x               -> HUD 整个不在(演出/时停里)
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账 (BaseCombatTask.py:663-672)。

        直接按数字键绕开了框架逻辑, 不补的话没人的 is_current_char 是 True,
        get_current_char() 返回 None, AutoCombatTask 主循环当场崩。
        """
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def poke_until_hud_back(self, tag='anim', time_out=None, tail=None):
        """演出期间一直点普攻, 等队伍 HUD 回来(演出结束)再往下走。

        【为什么点】: 演出结束的第一帧就要有输入落进去, 而演出期间的点击是被丢掉的、
        不排队 —— 连点免疫被吞, 单发要么埋在演出里要么等太久。
        【为什么还要 tail】: HUD 回来那一刻角色多半还在收招里, 那几下照样被吞。

        用户在启动轴上明写了这一格: "达妮娅动画期间一直点普攻触发不了, 所以需要等
        一点点时间等出手再切, 或者说你识别到了HUD就可以切了"。

        【"HUD 回来"要先确认它消失过】: 同 spam_key_through_lib —— 进来的这一刻
        画面还在渐变, 读一帧很可能读回 True, 那就是"演出刚开头就判成结束"。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        tail = self.LIB_ANIM_TAIL if tail is None else tail
        start = time.time()
        n = 0
        gone_seen = False
        back = False
        next_click = 0.0
        while time.time() - start < time_out:
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone_seen = True
            elif gone_seen or time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        # 演出这一段计入 freeze, 否则框架的各种 time_elapsed_accounting_for_freeze
        # 会把它算成"这个角色磨蹭了 5 秒"
        self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_seen else "NOANIM"},x{n},'
                        f'{time.time() - start:.2f}s)')
        if tail > 0:
            self.macro_spam(tail, self.A_INTERVAL, tag=f'{tag}Tail')
        return back

    def wait_con_at_least(self, char, level, tag='con', cap=None, interval=None, poke=True):
        """边打边等协奏圈涨到 level 以上(0~1)。到上限也往下走, 不把轴卡死。

        跟 wait_con_for_intro 的区别: 那个是"等满才交棒"(门槛是 CON_ENOUGH=0.99,
        【那个值是"环还没闭合"的哨兵, 不是真满】—— 要真满就把 level 传 1.0), 这个是
        【等到某个门槛才做下一个动作】—— 用户 2026-08-21: "达妮娅有时候被打断,
        能不能确保协奏圈超过75%才开R2Q切人"。

        【为什么是门槛不是满】: R2 和 Q 自己还会把圈推上去一截, 所以起手时到 75%
        就够她离场时是满的。等满再开 R2 反而是把这一截白等掉。

        【读协奏不便宜】(能量环连通域分析), 所以轮询间隔别调太小。
        【等的期间必须继续打】: 圈是靠打中涨的, 干站着等只会等到超时。
        """
        cap = self.CON_WAIT_TIME_OUT if cap is None else cap
        interval = self.CON_POLL_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        con = 0.0
        hit = False
        samples = []
        next_click = 0.0
        while self.time_elapsed_accounting_for_freeze(start) < cap:
            try:
                con = float(char.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            if con >= level:
                hit = True
                break
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.macro_wait(interval)
        self.macro_mark(f'{tag}({con:.2f},{"ok" if hit else "CAP"},A x{n},'
                        f'{time.time() - start:.2f}s)')
        if not hit:
            self.logger.info(f'{tag}: con only reached {con:.2f} (< {level:.2f}) in '
                             f'{cap:.1f}s — {" ".join(samples)}')
        return hit

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 【只在拿不到入口角色时才用】, 因为它开局会说谎。

        in_team() 的判据是"哪个槽位的名字文本【找不到】, 谁就在场"(BaseWWTask.py:930)。
        战斗刚开始时队伍 HUD 还在渐入, 三个槽位的文本不是同时出现的 —— 这时它只找到
        一个文本, 但 exist_count == 1 那个分支【照样返回 True 和一个 index】,
        而那个 index 只是渲染顺序的产物。可信判据是 count >= 队伍人数。
        """
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()   # in_team() 读的是缓存帧, 不刷就是反复读同一张图
            in_team, index, count = self.task.in_team()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def wait_hud_back(self, tag='anim', time_out=None, tail=0.0):
        """等演出结束(队伍 HUD 回来), 【期间一下都不点】。

        跟 poke_until_hud_back 的唯一差别就是不点普攻 —— 【角色在空中时必须用这个】:
        那时候的点击会变成下落攻击, 一下就把她砸回地面, 后面整段空中戏就没了。

        【"HUD 回来"要先确认它消失过】: 进来的这一刻画面可能还在渐变, 读一帧很可能
        读回 True, 那就是"演出刚开头就判成结束"。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_seen = False
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone_seen = True
            elif gone_seen or time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_seen else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def send_echo_now(self, char, tag='Q', presses=2, window=0.0):
        """立刻放 Q。【三个角色统一走这里, 而且都放在离场前的最后一步】
        (用户 2026-08-21: "因为声骸套装不一样, 统一设定最后放")。

        【不读屏】: click_echo(time_out=0) 的第一件事是读屏 echo_available(),
        读到 False 就掉进慢路径 —— 那条路要 OCR 一次 echo 的 CD, 再轮询最多 1 秒。
        而 Q 的位置个个都在处决/大招刚结束那一带, 那几帧的读数正是最不可信的时候。
        发键不读屏: 落在 CD 上是空操作, 不花钱。
        """
        self.spam_key(char.send_echo_key, window, interval=0.0, tag=tag,
                      presses=presses, poke=False)
        char.record_echo_use()

    def mark_busy(self, busy):
        """F 键监视线程靠它区分"战斗中手动处决"和"重开副本"。两个名字都置, 见文件顶部。"""
        self.task._ww_macro_busy = busy
        self.task._three_fire_macro_busy = busy

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 【现在】在场。按 R 之前用 —— HUD 本来就不在的时候 fire_lib 会当场判
        "演出开始了", 一发都没按出去就记成放了。跟 wait_hud_back(先消失再回来)是两回事。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.task.in_team()[0]:
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在场({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某个技能键到它进 CD。返回放出去了没有(本来就在 CD 上返回 False)。

        【先见过"亮"才认"暗"】: 刚切人那几帧技能栏还是上一个人的, 读到的是【上一个人】的 CD。
        实机 2026-09-11 两处都栽在这:
          - 维里奈刚放完 Q 切今汐, 今汐到场 0.21s 就"判到 Q 进 CD", 可她那时还在变奏入场的不响应输入里,
            角根本没召出来 -> 惊龙破空后协奏只有 0.50, 长离没变奏;
          - 长离刚放完 E 切维里奈, 维里奈到场 0.12s 就"判到 E 进 CD"(读的是长离的 E CD 数字)。
        所以要先读到过一次可用, 之后变成不可用才算放出去; ready_grace 秒都没见过可用, 才当它本来就在
        CD 上、直接跳过。(别的队伍那份引擎里的 press_e_until_cd 没有这道门, 这里不用它。)
        poke: 按键之间顺手点普攻(两条节奏各走各的, 不挤在同一帧)。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.task.in_team()[0])
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    # 两种情况分不开: 本来就在 CD 上 / 第一发就被接受、技能栏换过来时已经在 CD 了
                    # (没有入场锁的角色切进来第一发 E 常常就是这样)。都不用再按
                    self.macro_mark(f'{tag}_没见过亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def press_echo_until_cd(self, char, cap, tag, ready_grace=0.15):
        return self.press_key_until_cd(char.send_echo_key, char.echo_available, cap, tag,
                                       ready_grace=ready_grace)

    def press_res_until_cd(self, char, cap, tag, ready_grace=None, poke=False):
        """刚切进来的角色按 E 到进 CD(带"先见过亮"那道门)。"""
        ready_grace = self.SKILL_BAR_SETTLE if ready_grace is None else ready_grace
        return self.press_key_until_cd(char.send_resonance_key, char.resonance_available, cap, tag,
                                       ready_grace=ready_grace, poke=poke)

    # ==================== 本条轴额外用到的原语 ====================

    def need(self, ok, what):
        if not ok:
            raise MacroBroken(what)

    def fire_r(self, char, tag, window):
        """发大招到队伍 HUD【连续】消失 LIB_GONE_CONFIRM 帧。返回放出去没有。

        跟引擎 fire_lib 的差别就是这道确认: 露西强化重击的特效会让 HUD 读数闪一两帧,
        单帧判会把没放出去的 R 记成放了。发键之前先等 HUD 在场(HUD 本来就不在会假成功)。
        确认期间继续按 R 没有副作用 —— 演出里的按键被丢掉。
        """
        self.wait_hud_up(tag=f'{tag}前HUD')
        start = time.time()
        self.lib_press_at = start
        n = gone = 0
        fired = False
        while time.time() - start < window:
            char.send_liberation_key()
            n += 1
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.skip_combat_check = True
        if fired:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        # lit=True: 键被上一个动作吞了; lit=False: 能量不够
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def click_until_lit(self, read, cap, tag, settle=0.0, confirm=2, min_window=0.0,
                        interval=None, poke=True, f_interval=None, q_interval=None):
        """一直点普攻(poke=False 就只读不点)到某个指示连续亮 confirm 帧。返回亮了没有。

        settle: 到场头这么久的读数不算(技能栏/回路条换成新角色要几帧, 那几帧是上一个人的)。
        min_window: 至少点这么久才认亮 —— 提前满了也把这一段打完。
        HUD 不在的帧不读(演出/特效里读数是假的)。
        """
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = nf = nq = streak = 0
        next_click = next_f = next_q = 0.0
        lit = False
        trace = []
        while time.time() - start < cap:
            self.task.next_frame()
            now = time.time()
            if now - start >= settle and self.task.in_team()[0]:
                try:
                    full = bool(read())
                except Exception:
                    full = False
                if len(trace) < 40:
                    trace.append(f'{now - start:.2f}:{1 if full else 0}')
                streak = streak + 1 if full else 0
                if streak >= confirm and now - start >= min_window:
                    lit = True
                    break
            # 读到亮的那一帧起就不再点(连读确认的几帧也不点): 多点出去一下就多一个动作要演完
            if f_interval and streak == 0 and now >= next_f:
                # f_interval: 边点边按 F。跟 A 错开帧发(同一帧两个键游戏只认后按的); 读到亮之后都不发
                self.task.send_key('f')
                nf += 1
                next_f = now + f_interval
            elif q_interval and streak == 0 and now >= next_q:
                # q_interval: 隔一会补一下 Q(露西的声骸不打断攻击, 落在 CD 上是空操作) —— 被处决演出吞掉的那一发靠这里补
                self.send_echo_key()
                nq += 1
                next_q = now + q_interval
            elif poke and streak == 0 and now >= next_click:
                self.click()
                n += 1
                next_click = now + interval
            self.macro_wait(0.02)
        if f_interval:
            self.task.can_break = False
        self.macro_mark(f'{tag}({"亮" if lit else "CAP"},A x{n}{f",F x{nf}" if f_interval else ""}'
                        f'{f",Q x{nq}" if q_interval else ""},{time.time() - start:.2f}s)')
        if not lit:
            self.logger.info(f'{tag}: indicator never lit in {cap:.1f}s — {" ".join(trace)}')
        return lit

    def wait_until_dark(self, read, cap, tag, confirm=2):
        """不按任何键, 等某个指示连续暗 confirm 帧。只在 HUD 在场时读。返回暗了没有。"""
        start = time.time()
        streak = 0
        dark = False
        trace = []
        while time.time() - start < cap:
            self.task.next_frame()
            if self.task.in_team()[0]:
                try:
                    full = bool(read())
                except Exception:
                    full = True
                if len(trace) < 40:
                    trace.append(f'{time.time() - start:.2f}:{1 if full else 0}')
                streak = 0 if full else streak + 1
                if streak >= confirm:
                    dark = True
                    break
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}({"暗" if dark else "CAP"},{time.time() - start:.2f}s)')
        if not dark:
            self.logger.info(f'{tag}: indicator never went dark in {cap:.1f}s — {" ".join(trace)}')
        return dark

    def hold_until_clear(self, read, min_hold, cap, blind_hold, tag):
        """按住左键: 读到过亮、之后变暗、且按够 min_hold 才松; 一次都没读到亮就按 blind_hold 松。

        【先见过亮才认暗】: 按下的头几帧指示可能还没刷新。
        按住期间一下都不点(会打断长按)。
        """
        self.task.mouse_down()
        self.holding_attack = True
        start = time.time()
        seen = False
        state = 'CAP'
        try:
            while time.time() - start < cap:
                self.task.next_frame()
                held = time.time() - start
                if self.task.in_team()[0]:
                    try:
                        full = bool(read())
                    except Exception:
                        full = False
                    if full:
                        seen = True
                    elif seen and held >= min_hold:
                        state = 'cleared'
                        break
                    elif not seen and held >= blind_hold:
                        state = 'blind'
                        break
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}({state},{time.time() - start:.2f}s)')
        return state

    def dodge_keep_hold(self, tag):
        """左键按着的时候闪避: 直接投右键消息, 不走 click()。

        PostMessage 后端的 click()/mouse_down() 都会先投 WM_ACTIVATE, 按着的左键会被打断。
        wParam 带上 MK_LBUTTON 告诉窗口左键仍按着。拿不到后端就退回普通右键(那样左键多半会松)。
        """
        interaction = getattr(getattr(self.task, 'executor', None), 'interaction', None)
        post = getattr(interaction, 'post', None)
        pos = getattr(interaction, 'mouse_pos', None)
        try:
            import win32api
            import win32con
            if post is None or pos is None:
                raise AttributeError('no PostMessage backend')
            lparam = win32api.MAKELONG(int(pos[0]), int(pos[1]))
            post(win32con.WM_RBUTTONDOWN, win32con.MK_RBUTTON | win32con.MK_LBUTTON, lparam)
            self.macro_wait(0.03)
            post(win32con.WM_RBUTTONUP, win32con.MK_LBUTTON, lparam)
            how = 'post'
        except Exception as e:
            self.task.click(key='right', after_sleep=0)
            how = f'click:{e.__class__.__name__}'
        self.macro_mark(f'{tag}闪避({how})')

    def spam_a_f(self, window, tag, f_interval=None, a_interval=None):
        """一个窗口里 F 一直按、A 不停, 不读屏。F 和 A 错开帧发(同一帧两个键游戏只认后按的)。
        没处决可打时 F 什么都不触发; 处决演出里的按键被丢掉, 也不花钱。"""
        f_interval = self.LU_F_INTERVAL if f_interval is None else f_interval
        a_interval = self.A_INTERVAL if a_interval is None else a_interval
        start = time.time()
        na = nf = 0
        next_a = next_f = 0.0
        while time.time() - start < window:
            now = time.time()
            if now >= next_f:
                self.task.send_key('f')
                nf += 1
                next_f = now + f_interval
            elif now >= next_a:
                self.click()
                na += 1
                next_a = now + a_interval
            self.macro_wait(0.02)
        self.task.can_break = False
        self.macro_mark(f'{tag}(A x{na},F x{nf},{time.time() - start:.2f}s)')

    def lu_a_f_until_r(self, tag, use_f=True):
        """接着边 A(use_f: 再边按 F), 直到 R 连续两帧读到可用就停手去放 R。

        HUD 连续消失(处决/特效演出)就等演出结束(期间照样点), 然后接着等 R ——
        演出里按 R 会被丢掉, 而且 fire_r 靠 HUD 消失判大招, 演出没过去之前不能开始按 R。
        上限不算演出的时间。R 一直读不到可用就按满上限, 交给 lu_ensure_r 去按/补救。
        """
        start = time.time()
        na = nf = 0
        next_a = next_f = 0.0
        ready_hits = gone = 0
        anims = 0
        why = 'CAP'
        trace = []
        while time.time() - start < self.LU_R_WAIT_CAP:
            now = time.time()
            if use_f and now >= next_f:
                self.task.send_key('f')
                nf += 1
                next_f = now + self.LU_F_INTERVAL
            elif now >= next_a:
                self.click()
                na += 1
                next_a = now + self.A_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    anims += 1
                    anim_at = time.time()
                    self.poke_until_hud_back(tag=f'{tag}处决演出', time_out=self.LU_F_ANIM_CAP, tail=0.0)
                    start += time.time() - anim_at          # 演出时间不算进上限
                    gone = ready_hits = 0
                    next_a = next_f = 0.0
            else:
                gone = 0
                try:
                    ready = bool(self.liberation_available())
                except Exception:
                    ready = False
                ready_hits = ready_hits + 1 if ready else 0
                if len(trace) < 40:
                    trace.append(f'{time.time() - start:.2f}:{1 if ready else 0}')
                if ready_hits >= 2:
                    why = 'R好了'
                    break
            self.macro_wait(0.02)
        self.task.can_break = False
        self.macro_mark(f'{tag}{"A+F" if use_f else "A"}等R({why},演出x{anims},A x{na},F x{nf},'
                        f'{time.time() - start:.2f}s)')
        if why == 'CAP':
            self.logger.info(f'{tag}等R: liberation never read as ready in {self.LU_R_WAIT_CAP:.1f}s — '
                             f'{" ".join(trace)}')

    def spam_f_break(self, window, tag):
        """连按 F + 普攻一个窗口。没有处决可打时按 F 不触发别的(本场景没有可拾取物)。"""
        start = time.time()
        nf = na = 0
        next_f = next_a = 0.0
        while time.time() - start < window:
            now = time.time()
            if now >= next_f:
                self.task.send_key('f')
                nf += 1
                next_f = now + self.LU_F_INTERVAL
            elif now >= next_a:
                # 跟 F 错开帧发: 同一帧两个键游戏只认后按的
                self.click()
                na += 1
                next_a = now + self.A_INTERVAL
            self.macro_wait(0.02)
        self.task.can_break = False
        self.macro_mark(f'{tag}(F x{nf},A x{na})')

    def lu_ult_panel(self, tag):
        """露西大招演出 + 选项面板: 一直点左键到队伍 HUD 回来。调用前 R 已确认放出去(HUD 已消失)。

        演出里的点击被丢掉。面板里左键执行当前选中项、用完光标自己跳到下一项, RAM 用完再点就收起。
        面板出来 LU_PANEL_PLAIN 秒还没收起 = 光标卡在用不了的项上: 开始"滚一格 -> 点两下"地扫,
        先往下扫 LU_PANEL_SCAN_SPAN 格再往上扫同样多格, 循环到收起为止。
        """
        start = time.time()
        n = back = scrolls = 0
        next_click = 0.0
        next_scroll = start + self.LU_PANEL_OPEN + self.LU_PANEL_PLAIN
        done = False
        snapped = False
        while time.time() - start < self.LU_PANEL_CAP:
            now = time.time()
            if now >= next_scroll:
                if self.LU_PANEL_SNAPSHOT and not snapped:
                    snapped = True
                    self.save_panel_snapshot(tag)
                down = (scrolls % (2 * self.LU_PANEL_SCAN_SPAN)) < self.LU_PANEL_SCAN_SPAN
                try:
                    self.task.scroll_relative(0.5, 0.5, -1 if down else 1)
                except Exception as e:
                    self.logger.info(f'{tag}面板: scroll failed ({e})')
                scrolls += 1
                next_scroll = now + self.LU_PANEL_SCAN_STEP
                next_click = max(next_click, now + 0.08)   # 滚完稍等再点, 别跟滚轮挤在同一帧
            if now >= next_click:
                x, y = self.LU_PANEL_CLICK_POINTS[n % len(self.LU_PANEL_CLICK_POINTS)]
                self.click(x, y)
                n += 1
                next_click = now + self.LU_PANEL_CLICK_INTERVAL
            self.task.next_frame()
            if self.task.in_team()[0]:
                back += 1
                if back >= self.LU_PANEL_BACK_CONFIRM:
                    done = True
                    break
            else:
                back = 0
            self.macro_wait(0.02)
        self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}面板({"收起" if done else "CAP"},点x{n},滚x{scrolls},{time.time() - start:.2f}s)')
        return done

    def save_panel_snapshot(self, tag):
        """把当前画面存到 working/logs/lrv_panel_<时间>_<tag>.png, 日志里记路径。失败不影响宏。"""
        try:
            import os
            import cv2
            frame = self.task.frame
            if frame is None:
                return
            name = time.strftime('lrv_panel_%m%d_%H%M%S') + f'_{tag}.png'
            path = os.path.join(os.getcwd(), 'logs', name)
            cv2.imencode('.png', frame)[1].tofile(path)
            self.logger.info(f'{tag}面板: still open, snapshot saved to {path}')
        except Exception as e:
            self.logger.info(f'{tag}面板: snapshot failed ({e})')

    def switch_to_vr(self, vr, tag):
        """切给维里奈。返回时 HUD 在场、场上是她。

        切进来之后看一小段 HUD 会不会藏(有演出就等它回来), 然后就走。她的 QTE 第53F前不响应输入,
        那段锁由 seg_verina 里 E 的连发盖过去(锁里按的键被丢, 不花钱)。
        """
        src = self.cur
        sw_at = time.time()
        arrived = self.quick_switch(vr, click_during=True, read_con=True,
                                    time_out=self.LU_TO_VR_TIME_OUT)
        anim_in_switch = arrived and time.time() - sw_at >= self.VR_SWITCH_ANIM_HINT
        start = time.time()
        gone_seen = False
        back = False
        n = 0
        next_click = 0.0
        while time.time() - start < self.VR_INTRO_ANIM_CAP:
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone_seen = True
            elif gone_seen or anim_in_switch or time.time() - start >= self.VR_INTRO_NOANIM:
                back = True
                break
            self.macro_wait(0.01)
        if gone_seen:
            self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}维入场({"anim" if gone_seen or anim_in_switch else "noanim"},'
                        f'{"ok" if back else "timeout"},A x{n},{time.time() - start:.2f}s)')
        if not arrived:
            who = self.on_field_char(time_out=1.0)
            if who is not vr:
                self.macro_mark(f'{tag}维没上场({who.name if who else "?"})')
                return False
            self.handoff(src if src is not None else self, vr, True)
            self.macro_mark(f'{tag}>Ver(演出里到场)')
        return back

    # ==================== 各格 ====================

    def seg_lu_open(self, tag):
        """启动轴第一格: 露西 E1 -> 等 E 图标变金(强化E 解锁) -> R -> 面板。

        E1 命中后自动派生追加, 追加第1F解锁 E2, E 框换成金色图标 —— 那一刻 E1 整套打完、
        骇破偏移也挂上了, 马上接 R。
        """
        self.poking = False
        start = time.time()
        last_press = -9.0
        n = streak = 0
        seen_cd = False
        gold = False
        trace = []
        while time.time() - start < self.O_LU_E2_WAIT_CAP:
            now = time.time()
            if not seen_cd and streak == 0 and now - last_press >= self.O_LU_E1_RESEND:
                self.send_resonance_key()
                n += 1
                last_press = now
            self.task.next_frame()
            if self.task.in_team()[0]:
                ratio = self.box_gold_ratio('box_resonance')
                cd = self.read_cd('resonance')
                if cd > 0:
                    seen_cd = True
                if len(trace) < 60:
                    trace.append(f'{time.time() - start:.2f}:{ratio:.2f}/cd{cd:.1f}')
                streak = streak + 1 if ratio >= self.LU_E_GOLD_RATIO else 0
                if streak >= self.LU_E_GOLD_CONFIRM:
                    gold = True
                    break
            self.macro_wait(0.02)
        self.record_resonance_use()
        self.macro_mark(f'{tag}E1(x{n},{"变金" if gold else "CAP"},{time.time() - start:.2f}s)')
        if not gold:
            self.logger.info(f'{tag}E1: E icon never turned gold in {self.O_LU_E2_WAIT_CAP:.1f}s '
                             f'(firing R anyway) — gold/cd: {" ".join(trace)}')
        if self.fire_lucy_r(self.LU_R_WINDOW, tag):
            self.lu_ult_panel(tag)

    def gold_now(self, frames):
        """E 框连续 frames 帧读到金色(强化E 图标)。只读 HUD 在场的帧。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.task.in_team()[0]:
                if self.box_gold_ratio('box_resonance') >= self.LU_E_GOLD_RATIO:
                    hits += 1
                    if hits >= frames:
                        return True
                else:
                    return False
            self.macro_wait(0.02)
        return False

    def lu_wait_gold(self, cap, tag):
        """不按任何键, 等 E 框连续两帧读到金色(且没有 CD 数字)。返回等到没有。

        启动轴露西先按了 F: 出了处决的话演出里 E 图标可能读不出金色, 这时去按 E2 会被当成"没见过金色"按到上限。
        """
        start = time.time()
        streak = 0
        while time.time() - start < cap:
            self.task.next_frame()
            if self.task.in_team()[0]:
                ok = self.box_gold_ratio('box_resonance') >= self.LU_E_GOLD_RATIO and self.read_cd('resonance') <= 0
                streak = streak + 1 if ok else 0
                if streak >= 2:
                    self.macro_mark(f'{tag}(变金,{time.time() - start:.2f}s)')
                    return True
            self.macro_wait(0.03)
        self.macro_mark(f'{tag}(CAP,{cap:.1f}s)')
        return False

    def lu_e1_until_gold(self, cap, tag):
        """按 E1 到 E 图标变金(追加第1F解锁 E2)。只在没见到 CD 也没见到金色时才补发(防输入缓存连出 E2)。

        金色要同时满足: E 框没有 CD 数字、E1 已经进过 CD(读不到 CD 时退成"第一发 E1 之后够久")、连续 3 帧。
        """
        start = time.time()
        last_press = -9.0
        first_press = None
        n = streak = 0
        cd_at = None
        gold = False
        trace = []
        while time.time() - start < cap:
            now = time.time()
            if cd_at is None and streak == 0 and now - last_press >= self.O_LU_E1_RESEND:
                self.send_resonance_key()
                n += 1
                last_press = now
                if first_press is None:
                    first_press = now
            self.task.next_frame()
            if self.task.in_team()[0]:
                ratio = self.box_gold_ratio('box_resonance')
                cd = self.read_cd('resonance')
                now = time.time()
                if cd > 0 and cd_at is None:
                    cd_at = now
                if cd_at is not None:
                    armed = now - cd_at >= self.LU_E2_GOLD_AFTER_CD
                else:
                    armed = first_press is not None and now - first_press >= self.LU_E2_GOLD_NO_CD_AFTER
                valid = armed and cd <= 0 and ratio >= self.LU_E_GOLD_RATIO
                if len(trace) < 60:
                    trace.append(f'{now - start:.2f}:{ratio:.2f}/cd{cd:.1f}')
                streak = streak + 1 if valid else 0
                if streak >= self.LU_E2_GOLD_CONFIRM:
                    gold = True
                    break
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(x{n},{"变金" if gold else "CAP"},{time.time() - start:.2f}s)')
        if not gold:
            self.logger.info(f'{tag}: E icon never turned gold in {cap:.1f}s — gold/cd: {" ".join(trace)}')
        return gold

    def lu_press_while_gold(self, cap, tag, primed=False):
        """E 图标是金色(E2 可放)就连按 E, 金色连续消失两帧 = E2 放出去了, 立刻停手。

        【消失一次就停】: E2 放完回路可能刚好满, 再按会当场放出强化E; E1 冷却被削到 ~1.5s, 多按还会再出 E1。
        primed: 调用方刚确认过变金 —— 第一下常常当场就把 E2 放出去, 这里一次都读不到金色,
        不当成"见过金色"的话会一直按到上限(干跑抓到的)。
        一开始就没读到金色(判据失灵)才照按到上限 —— 宁可多按几下, 也不要漏掉 E2。
        """
        start = time.time()
        n = dark = 0
        seen_gold = primed
        cast = False
        next_press = 0.0
        trace = []
        while time.time() - start < cap:
            now = time.time()
            if now >= next_press:
                self.send_resonance_key()
                n += 1
                next_press = now + self.LU_E_INTERVAL
            self.task.next_frame()
            if self.task.in_team()[0]:
                ratio = self.box_gold_ratio('box_resonance')
                cd = self.read_cd('resonance')
                if len(trace) < 60:
                    trace.append(f'{time.time() - start:.2f}:{ratio:.2f}/cd{cd:.1f}')
                if ratio >= self.LU_E_GOLD_RATIO and cd <= 0:
                    seen_gold = True
                    dark = 0
                elif seen_gold:
                    dark += 1
                    # 出现 CD 数字才算真放出去; 特效把金色遮住几帧不算。读不到数字时要暗得够久
                    if (cd > 0 and dark >= 2) or dark >= self.LU_E2_DARK_NO_CD:
                        cast = True
                        break
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(x{n},{"出手" if cast else "CAP"},{time.time() - start:.2f}s)')
        if not cast:
            self.logger.info(f'{tag}: gold never went away (seen gold={seen_gold}) — {" ".join(trace)}')
        return cast

    def lu_ensure_heavy(self, tag):
        """回路重击保底: 重击指示亮着(根协议满)就按住打出去, 松手后指示还亮 = 被打断/没接受, 再来一次。

        判"打出去了"看指示由亮变暗(强化重击2 起手清空根协议)。指示一开始就没亮就什么都不做。
        """
        tries = 0
        while tries < self.LU_HEAVY_RETRY and self.lit_now(self.is_mouse_forte_full, 2):
            tries += 1
            caught = self.lu_hold_heavy(f'{tag}回路重击#{tries}')
            if caught or self.wait_until_dark(self.is_mouse_forte_full, self.LU_HEAVY_VERIFY,
                                              f'{tag}回路重击松开#{tries}'):
                return True
            self.logger.info(f'{tag}: heavy indicator still lit after hold #{tries}, pressing again')
        return tries > 0

    def lu_hold_heavy(self, tag):
        """按住回路重击, 按住期间盯重击指示。返回游戏接住没有(按住期间见到指示暗)。

        - 指示连续两帧暗 = 接住了: 从那一刻再按够 LU_HEAVY_HOLD_AFTER 秒松手;
        - 按下 LU_HEAVY_REGRIP_AT 秒还亮 = 这下没被接受: 松开 0.05s 马上重按(新的按下沿), 最多 LU_HEAVY_REGRIPS 次;
        - HUD 不在的帧不读(特效/演出里读数不准)。
        按住期间不点、不发任何会 activate 的键(会打断长按)。
        """
        start = time.time()
        press_at = start
        regrips = dark = 0
        dark_at = None
        trace = []
        self.task.mouse_down()
        self.holding_attack = True
        try:
            while time.time() - start < self.LU_HEAVY_HOLD_CAP:
                self.task.next_frame()
                now = time.time()
                if self.task.in_team()[0]:
                    try:
                        lit = bool(self.is_mouse_forte_full())
                    except Exception:
                        lit = True
                    if len(trace) < 60:
                        trace.append(f'{now - start:.2f}:{1 if lit else 0}')
                    dark = 0 if lit else dark + 1
                    if dark >= 2 and dark_at is None:
                        dark_at = now
                if dark_at is not None:
                    if now - dark_at >= self.LU_HEAVY_HOLD_AFTER:
                        break
                elif now - press_at >= self.LU_HEAVY_REGRIP_AT:
                    if regrips >= self.LU_HEAVY_REGRIPS:
                        break
                    self.task.mouse_up()
                    self.macro_wait(0.05)
                    self.task.mouse_down()
                    press_at = time.time()
                    regrips += 1
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        caught = dark_at is not None
        self.macro_mark(f'{tag}({"接住" if caught else "没接住"},重按x{regrips},{time.time() - start:.2f}s)')
        if not caught or regrips:
            self.logger.info(f'{tag}: {"caught" if caught else "never caught"} after {regrips} regrips — '
                             f'{" ".join(trace)}')
        return caught

    def lit_now(self, read, frames):
        """HUD 在场时连续 frames 帧读到 read() 为真。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.task.in_team()[0]:
                try:
                    lit = bool(read())
                except Exception:
                    lit = False
                if not lit:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def lu_ensure_r(self, tag):
        """收尾的 R 一定要放出来: 按不出来就攒能量再按, 直到出手或撞防卡死上限。返回放出去没有。

        每轮先读 R 亮不亮:
          - 暗(能量不够) -> 回路重击指示亮就打出去、声骸按一下(召唤类给大招能量)、连点普攻一小段;
            【暗的时候不按 R】: 按 R 加等"晚到"要 2s 不打怪, 能量永远攒不上来(干跑抓到的)。
            只每 LU_R_BLIND_EVERY 轮盲按一次, 防 R 的读数不准;
          - 亮(键被动作吞了) -> 不攒, 直接按。
        """
        # 【先读 R 再决定按不按】: R 没好时直接去攒能量, 不先干按 R —— 按 R 和等"晚到"那几秒是一下 A 都不点的
        if self.lib_ready_reads(self, 2) and self.fire_lucy_r(self.LU_R_WINDOW_FINAL, tag):
            return True
        start = time.time()
        rounds = 0
        while time.time() - start < self.LU_R_ENSURE_CAP:
            rounds += 1
            lit = self.lib_ready_reads(self, 2)
            self.macro_mark(f'{tag}R补救#{rounds}(R{"亮" if lit else "暗"})')
            if not lit:
                self.lu_ensure_heavy(f'{tag}R补救')
                self.send_echo_key()
                self.macro_spam(self.LU_R_BUILD_SLICE, tag=f'{tag}R补救A')
                lit = self.lib_ready_reads(self, 2)
                if not lit:
                    if rounds % self.LU_R_BLIND_EVERY == 0:
                        # 防 R 的读数不准: 短按一下试试, 不等晚到, 按完接着攒
                        if self.fire_r(self, f'{tag}R补救#{rounds}盲按', self.LU_R_BLIND_WINDOW):
                            return True
                    continue
            if self.fire_lucy_r(self.LU_R_RETRY_WINDOW, f'{tag}R补救#{rounds}'):
                self.logger.info(f'{tag}: final R fired after {rounds} rescue rounds '
                                 f'({time.time() - start:.1f}s)')
                return True
        self.logger.warning(f'{tag}: final R still not fired after {self.LU_R_ENSURE_CAP:.0f}s '
                            f'of building energy ({rounds} rounds), switching anyway')
        return False

    def fire_lucy_r(self, window, tag):
        """露西发 R; 窗口里判不到演出时, 再看 LU_R_LATE_GRACE 秒内 HUD 会不会连续消失(R 起得晚)。

        判漏了的代价很大: 面板开着没人点, 宏直接去切人, 切不动超时, 整圈散掉。
        """
        if self.fire_r(self, f'{tag}R', window):
            return True
        if self.hud_gone_within(self.LU_R_LATE_GRACE, f'{tag}R晚到'):
            self.record_liberation_use()
            return True
        return False

    def box_gold_ratio(self, name):
        """技能框里金色像素的占比。拿不到返回 -1。

        按 HSV 判不按 RGB: 金色图标的亮度随背景变化很大, RGB 阈值只在背景偏亮的帧上过线。
        """
        try:
            import cv2
            box = self.task.get_box_by_name(name)
            crop = self.task.frame[box.y:box.y + box.height, box.x:box.x + box.width]
            hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
            h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            gold = (h >= 12) & (h <= 38) & (s > 40) & (v > 90)
            return float(gold.mean())
        except Exception:
            return -1.0

    # ---------------- 维里奈 ----------------

    def vr_ensure_r(self, vr, tag):
        """维里奈 R: R 和 A 错开帧一起连发, 队伍 HUD 连续消失 LIB_GONE_CONFIRM 帧 = 大招出来了。返回放出去没有。

        R 没转好的时候这段就在打怪攒能量, 转好的那一刻 R 打断普攻放出来; VR_R_CAP 封顶(打不到怪时防卡死)。
        同一帧两个键游戏只认后按的, 所以 R 和 A 轮流发。发键之前先等 HUD 在场(HUD 本来就不在会假成功)。
        """
        self.wait_hud_up(tag=f'{tag}R前HUD')
        start = time.time()
        self.lib_press_at = start
        nr = na = gone = 0
        next_r = next_a = 0.0
        fired = False
        while time.time() - start < self.VR_R_CAP:
            now = time.time()
            if now >= next_r:
                vr.send_liberation_key()
                nr += 1
                next_r = now + self.VR_R_KEY_INTERVAL
            elif now >= next_a:
                self.click()
                na += 1
                next_a = now + self.A_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(0.02)
        self.task.skip_combat_check = True
        if fired:
            vr.record_liberation_use()
            self.macro_mark(f'{tag}R_fired(R x{nr},A x{na},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}R_NOFIRE(R x{nr},A x{na},{time.time() - start:.2f}s)')
        self.logger.warning(f'{tag}: 维里奈 R 边 A 边按了 {time.time() - start:.1f}s 没放出来, 不等了')
        return False

    def seg_verina(self, vr, rb, opener, tag):
        """维里奈一整格: E -> Q -> R -> 二段跳 -> 空中 A -> 边 A 边等协奏满 -> 变奏丽贝卡。返回切过去没有。

        启动轴普通切人上场, 循环轴变奏入场(QTE 第53F前不响应输入) —— 两种一样走: E 按到进 CD 为止,
        锁里被吞的几发不花钱。【E/Q 都排在 R 前面】: 光合作用那一格先落地, 大招的治疗和增益盖在铺开的场上。
        R 没放出来就不跳, 直接边 A 边等协奏(普攻也给协奏)。
        """
        self.poking = False
        marks = len(self.macro_marks)
        if not opener and vr.has_intro:
            # 变奏入场: 先让那段冲撞攻击演完(不按键), 再只按 E。ready_grace 放满上限 —— 空中那一截 E 图标
            # 要是读成暗的, 默认 0.4s 就会当成"本来在 CD 上"放弃, E 直接被跳过
            arrived = getattr(vr, 'last_switch_in_time', 0.0) or 0.0
            left = arrived + self.VR_INTRO_TO_E - time.time()
            if 0 < left <= self.VR_INTRO_TO_E:
                self.macro_wait(left)
            self.press_res_until_cd(vr, self.VR_E_CAP_INTRO, tag=f'{tag}E', ready_grace=self.VR_E_CAP_INTRO,
                                    poke=False)
        else:
            self.press_res_until_cd(vr, self.VR_E_CAP, tag=f'{tag}E', poke=True)
        vr.record_resonance_use()
        self.macro_wait(self.VR_E_TO_Q)
        self.send_echo_now(vr, tag=f'{tag}Q', window=self.VR_Q_WINDOW)
        self.macro_wait(self.VR_Q_TO_R)
        fired = self.vr_ensure_r(vr, tag)
        if fired:
            self.poke_until_hud_back(tag=f'{tag}R演出', tail=0.0)
            self.task.jump(after_sleep=0)
            self.macro_wait(self.VR_JUMP_GAP)
            self.task.jump(after_sleep=0)
            self.macro_mark(f'{tag}二段跳')
            self.macro_wait(self.VR_JUMP_SETTLE)
            self.macro_spam(self.VR_AIR_A, tag=f'{tag}空中A')
        else:
            self.logger.info(f'{tag}: 维里奈 R 没放出来, 不跳, 直接边 A 边等协奏')
        full = self.wait_con_for_intro(vr, 'Rebecca', poke=True, time_out=self.VR_CON_CAP)
        self.warn_no_con(full, '维', '丽')
        ok = self.quick_switch(rb, assume_con=full, click_during=True)
        # 单独打一行: 整圈的时间轴要跑完一圈才打, 中途停掉就看不到维里奈这段
        self.logger.info(f'{tag} timeline: {self.macro_timeline(marks)}')
        return ok

    # ---------------- 通用原语 ----------------

    def read_cd(self, name='resonance', char=None):
        """读技能框里的 CD 数字(秒)。不在 CD / 读不到都返回 0。"""
        try:
            index = None if char is None else char.index
            return float(self.task.get_cd(name, index))
        except Exception:
            return 0.0

    def read_con(self, want, settle=None, click=False, tag=None):
        """读协奏: 自己刷帧、给结算留时间, 连着几帧达到 want 就立刻返回。返回期间读到的最大值。

        不走 char.get_current_con(): 那层读到过 1 就一直缓存成 1。
        """
        settle = self.INTRO_CON_SETTLE if settle is None else settle
        start = time.time()
        best = 0.0
        hits = 0
        next_click = 0.0
        while True:
            now = time.time()
            if click and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= want else 0
            if hits >= self.INTRO_CON_FULL_CONFIRM or time.time() - start >= settle:
                break
            self.macro_wait(self.INTRO_CON_POLL)
        if tag:
            self.macro_mark(f'{tag}(con{best:.2f},{time.time() - start:.2f}s)')
        return best

    def wait_con_for_intro(self, char, next_name, poke=True, time_out=None):
        """边打边等协奏满(连着几帧读到)再交棒。等不到就往上游找哪笔伤害打空了。"""
        time_out = self.INTRO_CON_CAP if time_out is None else time_out
        start = time.time()
        samples = []
        full = False
        full_hits = 0
        next_click = 0.0
        while time.time() - start < time_out:
            self.task.next_frame()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            full_hits = full_hits + 1 if con >= self.INTRO_CON_ENOUGH else 0
            if full_hits >= self.INTRO_CON_FULL_CONFIRM:
                full = True
                break
            now = time.time()
            if poke and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.macro_wait(self.INTRO_CON_POLL)
        self.macro_mark(f'con({"full" if full else "timeout"},{time.time() - start:.2f}s)')
        self.logger.info(f'{char.name} con {" ".join(samples)} '
                         f'{"(full)" if full else f"(never filled, {next_name} gets no intro)"}')
        return full

    def warn_no_con(self, full, who, nxt):
        """协奏没满就交棒时记一笔 —— 下一个人拿不到变奏入场, 这一圈从这里开始就不对了。"""
        if full:
            return True
        self.logger.warning(f'【协奏没满就交棒】{who} -> {nxt}: {nxt}拿不到变奏入场')
        self.macro_mark(f'{who}协奏不满!')
        return False

    def seg_rb_e(self, rb, lu, tag):
        """丽贝卡(变奏入场): [头 RB_E_F_LEAD 秒只按 F 给处决] -> 连按霰弹E 到 E 进 CD -> 马上切露西。

        读到 CD 的时候枪早已切回手枪(40F), 可以直接切人。【读到 CD 立刻停手】: 霰弹E 派生 90F
        之后再按会连出手枪E(它 46F 又切回霰弹, 后面长按就不是手枪重击了)。
        两个判据任一成立就算进 CD:
          - 见过亮之后变暗(刚到场几帧技能栏是上一个人的, 所以要先见过亮);
          - E 框里 OCR 到 CD 数字(连续两帧)。入场时 E 图标可能是灰的、锁一解开第一发就出去,
            那样读不到"亮", 只有这一条能判到。
        每次都把技能栏读数、CD 数字和 E 图标变化量打进日志, 判据不灵时拿它标定。
        """
        self.poking = False
        start = time.time()
        n = nf = 0
        seen_ready = False
        on_cd = False
        cd_hits = 0
        next_press = next_f = 0.0
        ref = None
        trace = []
        # 先 F 后 E: 到场头 RB_E_F_LEAD 秒只按 F
        e_from = start + (self.RB_E_F_LEAD if self.RB_E_F else 0.0)
        cap = self.RB_E_CAP_F if self.RB_E_F else self.RB_E_CAP
        while time.time() - e_from < cap:
            now = time.time()
            if now < e_from:
                if now >= next_f:
                    self.task.send_key('f')
                    nf += 1
                    next_f = now + self.RB_E_F_INTERVAL
            elif now >= next_press:
                rb.send_resonance_key()
                n += 1
                next_press = now + self.RB_E_INTERVAL
            self.task.next_frame()
            elapsed = time.time() - start
            if elapsed >= self.RB_E_SETTLE and self.task.in_team()[0]:
                try:
                    ready = bool(rb.resonance_available())
                except Exception:
                    ready = False
                cd = self.read_cd('resonance')
                cd_hits = cd_hits + 1 if cd > 0 else 0
                gray = self.box_gray('box_resonance')
                if ref is None:
                    ref = gray
                diff = self.gray_diff(gray, ref)
                if len(trace) < 60:
                    trace.append(f'{elapsed:.2f}:{1 if ready else 0}/cd{cd:.1f}/{diff}')
                # 只认开始按 E 之后见到的"亮": 前面按 F 那段要是出了处决, 演出里图标暗下去不能算成 E 放出去了
                if ready and n > 0:
                    seen_ready = True
                if n > 0 and ((seen_ready and not ready) or cd_hits >= 2):
                    on_cd = True
                    break
            self.macro_wait(0.02)
        rb.record_resonance_use()
        self.task.can_break = False
        self.macro_mark(f'{tag}霰弹E({"CD" if on_cd else "CAP"},x{n},F x{nf},{time.time() - start:.2f}s)')
        self.logger.info(f'{tag}霰弹E {"on-cooldown" if on_cd else "never read as on-cooldown"} '
                         f'after {n} presses (seen ready={seen_ready}) — ready/icon-diff: {" ".join(trace)}')
        if not on_cd:
            self.macro_wait(self.RB_E_TO_SWITCH)
        # E 放出去马上切人, E 之后不再按 F(处决会把 E 吞掉)
        return self.quick_switch(lu, click_during=False,
                                 time_out=self.RB_E_TO_LU_TIME_OUT if self.RB_E_F else None)

    def box_gray(self, name):
        """技能框的缩小灰度图, 只用来记日志(图标换没换)。拿不到返回 None。"""
        try:
            import cv2
            box = self.task.get_box_by_name(name)
            frame = self.task.frame
            crop = frame[box.y:box.y + box.height, box.x:box.x + box.width]
            return cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), (24, 24)).astype('int16')
        except Exception:
            return None

    @staticmethod
    def gray_diff(a, b):
        if a is None or b is None:
            return '-'
        return int(abs(a - b).mean())

    def seg_lu_e(self, rb, stay, opener, tag):
        """露西: [只按 F 给处决] -> [E1 -> 等变金] -> 连按 E2 到放出去 -> 站满 stay 秒 -> 按住普攻 -> 切丽贝卡。

        启动轴: 开局已经放过 E1, E2 早就解锁, 直接按 E2。
        循环轴: 上一圈 E2 用掉了, 进场时一律先按 E1 —— 不看进场那一刻 E 框是不是金色(会被特效骗)。
        按住跨过切人, 丽贝卡一上场就是重击循环。
        """
        self.poking = False
        self.macro_wait(self.LU_E_SETTLE)
        extra = 0.0
        if self.LU_E_F:
            # 先处决: 丽贝卡的霰弹E 刚打中, 提示这时候就在; 演出里按的 E 会被吞, 所以 F 在 E 前面
            self.spam_key(lambda: self.task.send_key('f'), self.LU_E_F_WINDOW, interval=self.LU_E_F_INTERVAL,
                          tag=f'{tag}E前F', poke=False)
            self.task.can_break = False
            extra = self.LU_E_F_EXTRA_CAP
        arrive = time.time()
        if opener:
            gold = self.gold_now(2)
            if not gold and self.LU_E_F:
                # 刚按过 F: 处决演出里 E2 的金色图标可能读不出来, 不按键等它回来再按(按了也是被演出吞掉)
                gold = self.lu_wait_gold(extra, f'{tag}等E2金')
        else:
            gold = self.lu_e1_until_gold(self.LU_E2_GOLD_CAP + extra, f'{tag}E1')
        # 没见过金色时这个上限是照按到底的, 所以只在确认过变金时才加长
        self.lu_press_while_gold(self.LU_E2_PRESS_CAP + (extra if gold else 0.0), f'{tag}E2', primed=gold)
        self.record_resonance_use()
        left = max(stay - (time.time() - arrive), self.LU_E2_MIN_TAIL if self.LU_E_F else 0.0)
        if left > 0:
            self.macro_wait(left)
        self.task.mouse_down()
        self.holding_attack = True
        self.macro_mark(f'{tag}按住')
        return self.quick_switch(rb, click_during=False)

    def rb_send_f_keep_hold(self):
        """左键按着的时候按一下 F。返回怎么发的('post' / 'send_key')。

        PostMessage 后端的 send_key 会先投 WM_ACTIVATE, 按着的左键会被打断; 它的 send_key_down 带
        activate=False 就只投 WM_KEYDOWN。别的输入后端没有这个参数(也没有 activate 这回事), 照常 send_key。
        """
        interaction = getattr(getattr(self.task, 'executor', None), 'interaction', None)
        try:
            interaction.send_key_down('f', activate=False)
            time.sleep(0.02)
            interaction.send_key_up('f')
            return 'post'
        except (AttributeError, TypeError):
            self.task.send_key('f')
            return 'send_key'

    def rb_hold_wait_fervor(self, rb, tag):
        """丽贝卡(左键已按着)等狂热满(强化重击指示连续亮), 期间隔 RB_HOLD_F_INTERVAL 按一下 F。返回亮了没有。

        出了处决(队伍 HUD 连续消失)就等演出结束, 然后松开重按一次接着攒 —— 演出期间的按住游戏不一定还认。
        演出时间不算进 RB_HOLD_CAP; 到场头 RB_HOLD_SETTLE 秒(和每次重按后)指示读数不算。
        """
        start = time.time()
        settle_from = start
        anim = 0.0
        n_f = n_exec = streak = gone = 0
        next_f = start + max(self.RB_HOLD_SETTLE, self.RB_HOLD_F_START)
        how = ''
        lit = False
        trace = []
        while time.time() - start - anim < self.RB_HOLD_CAP:
            now = time.time()
            if self.RB_HOLD_F and now >= next_f:
                how = self.rb_send_f_keep_hold()
                n_f += 1
                next_f = now + self.RB_HOLD_F_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    n_exec += 1
                    t0 = time.time()
                    self.wait_hud_up(cap=self.LU_F_ANIM_CAP, tag=f'{tag}处决演出')
                    self.task.mouse_up()
                    self.macro_wait(0.03)
                    self.task.mouse_down()
                    self.holding_attack = True
                    self.task.can_break = False
                    anim += time.time() - t0
                    settle_from = time.time()
                    gone = streak = 0
                    next_f = settle_from + self.RB_HOLD_F_INTERVAL
                    self.macro_mark(f'{tag}处决完重新按住')
            else:
                gone = 0
                if time.time() - settle_from >= self.RB_HOLD_SETTLE:
                    try:
                        full = bool(rb.is_mouse_forte_full())
                    except Exception:
                        full = False
                    if len(trace) < 40:
                        trace.append(f'{time.time() - start:.2f}:{1 if full else 0}')
                    streak = streak + 1 if full else 0
                    if streak >= self.RB_HOLD_CONFIRM:
                        lit = True
                        break
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}等狂热满({"亮" if lit else "CAP"},F x{n_f}{"/" + how if how else ""},'
                        f'处决x{n_exec},{time.time() - start:.2f}s)')
        if not lit:
            self.logger.info(f'{tag}等狂热满: indicator never lit in {self.RB_HOLD_CAP:.1f}s — {" ".join(trace)}')
        return lit

    def seg_rb_hold(self, rb, lu, dodge, release_to_switch, tag):
        """丽贝卡(左键已按着): 等强化重击指示亮 -> [战术闪避] -> 松手 -> 等一下 -> 切露西。

        切人时读一次丽贝卡协奏(时间轴上 >Luc^ = 读到满): 满协奏离场会让露西带着变奏进场,
        QTE 期间不响应输入, 看着就是"进场没马上 A"。
        """
        self.poking = False
        lit = self.rb_hold_wait_fervor(rb, tag)
        if dodge:
            self.dodge_keep_hold(tag)
            self.macro_wait(self.RB_DODGE_TO_RELEASE)
        self.release_attack()
        self.macro_mark(f'{tag}松开')
        # 狂热指示暗了 = 强化重击起手了, 马上切; 读不到(没见亮 / 一直不暗)就按原来的时长兜底
        if lit and self.wait_until_dark(rb.is_mouse_forte_full, release_to_switch, f'{tag}强化重击起手'):
            self.macro_wait(self.RB_DARK_TO_SWITCH)
        else:
            self.macro_wait(max(0.0, release_to_switch))
        return self.quick_switch(lu, click_during=True, read_con=True)

    def hud_gone_within(self, cap, tag):
        """cap 秒内队伍 HUD 连续消失 LIB_GONE_CONFIRM 帧就返回 True(不按任何键)。"""
        start = time.time()
        gone = 0
        while time.time() - start < cap:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    self.macro_mark(f'{tag}(HUD消失,{time.time() - start:.2f}s)')
                    return True
            else:
                gone = 0
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(HUD一直在)')
        return False

    def seg_lu_4a(self, rb, tag):
        """露西: 连点到 A4 出手 -> 切丽贝卡(切人期间继续点, A4 落在露西身上)。"""
        self.poking = False
        self.macro_spam(self.LU_4A_WINDOW, tag=f'{tag}4A')
        return self.quick_switch(rb, click_during=True)

    def seg_rb_qr(self, rb, lu, tag):
        """丽贝卡: Q -> R -> 机枪里连点 -> 大烟花 -> 满协奏变奏露西。"""
        self.poking = False
        arrive = time.time()
        self.send_echo_now(rb, tag=f'{tag}Q', window=self.RB_Q_WINDOW)
        self.macro_wait(self.RB_Q_TO_R)
        left = self.RB_R_READY_SETTLE - (time.time() - arrive)
        if left > 0:
            self.macro_wait(left)
        # 入场协奏: 低于 75% 说明前面强化重击没打中, 这圈要等大烟花打中协奏满了再切
        # (本局没见过满环前协奏中间值读 0, 会被当成低 —— 那一圈多等一会儿, 方向是安全的)
        con_in = self.read_con(self.RB_CON_LOW, settle=self.RB_CON_READ, tag=f'{tag}入场协奏')
        wait_full = con_in < self.RB_CON_LOW
        self.rb_build_r(rb, tag)
        fired = self.fire_r(rb, f'{tag}R', self.RB_R_WINDOW)
        if not fired and self.hud_gone_within(self.RB_R_LATE_GRACE, f'{tag}R晚到'):
            # 按完才起演出: 还是按"放出去了"走机枪段, 不然切人会撞在机枪里超时
            fired = True
            rb.record_liberation_use()
        if fired:
            start = self.lib_press_at
            n = nr = 0
            next_click = 0.0
            next_r = time.time() + self.RB_MG_R_EVERY
            while time.time() - start < self.RB_MG_BEFORE_SWITCH:
                now = time.time()
                if now >= next_r:
                    rb.send_liberation_key()
                    nr += 1
                    next_r = now + self.RB_MG_R_EVERY
                elif now >= next_click:
                    self.click()
                    n += 1
                    next_click = now + self.RB_MG_CLICK_INTERVAL
                self.macro_wait(0.02)
            self.macro_mark(f'{tag}机枪(A x{n},R x{nr})')
            if wait_full:
                # 入场协奏低: 等机枪 + 大烟花放完(期间队伍 HUD 不在), 再等大烟花打中协奏真满才切
                self.poke_until_hud_back(tag=f'{tag}等R放完', time_out=self.RB_R_END_CAP, tail=0.0)
                self.wait_con_for_intro(rb, 'Lucy', poke=True, time_out=self.RB_CON_WAIT_CAP)
        return self.quick_switch(lu, click_during=True, read_con=True, time_out=self.RB_SWITCH_TIME_OUT,
                                 click_interval=self.RB_MG_CLICK_INTERVAL)

    def forte_white_percent(self):
        """框架 is_forte_full 读的那一块(回路条右端的 E 按键提示)的白色占比, >0.08 算满。拿不到返回 -1。"""
        try:
            from src.char.BaseChar import forte_white_color
            box = self.task.box_of_screen_scaled(3840, 2160, 2251, 1993, 2311, 2016, name='forte_full', hcenter=True)
            return float(self.task.calculate_color_percentage(forte_white_color, box))
        except Exception:
            return -1.0

    def lu_fill_forte(self, tag):
        """露西(变奏入场)一直点 A 到回路满。跟 click_until_lit 一样的判据, 多做两件排查用的事:
        - 每一帧的白色占比都记进日志(不管判没判到);
        - 到场 LU_FILL_SNAPSHOT_AT 秒还没判满, 存一张当时的画面到 logs/(看强化E 是不是其实已经好了)。
        (用户 2026-09-14: 启动轴强化E 明明好了还要等 1~2s 才按; 实机启动轴这一步 1.5~2.7s, 循环轴 0.44s)
        """
        start = time.time()
        n = nf = streak = 0
        # 先点 A 再按 F: 处决提示要打到怪才出来
        next_click = 0.0
        next_f = start + 0.06
        f_window = self.LU_F_MIN_WINDOW if self.LU_F_ON_INTRO else 0.0
        lit = False
        snapped = False
        trace = []
        gone_at = None
        anim = 0.0
        while time.time() - start - anim < self.LU_FILL_CAP:
            self.task.next_frame()
            now = time.time()
            on_hud = bool(self.task.in_team()[0])
            if not on_hud:
                # 处决演出(或特效闪一下): 这段不算进上限, 读数也不读
                if gone_at is None:
                    gone_at = now
            elif gone_at is not None:
                anim += now - gone_at
                gone_at = None
            if now - start >= self.LU_FILL_SETTLE and on_hud:
                # 判断照旧走 is_forte_full(); 白色占比只记日志 —— 算占比那一路出错时不能把判断也带坏
                try:
                    full = bool(self.is_forte_full())
                except Exception:
                    full = False
                if len(trace) < 80:
                    trace.append(f'{now - start:.2f}:{self.forte_white_percent():.2f}{"*" if full else ""}')
                streak = streak + 1 if full else 0
                # 回路早满了也把 A+F 那 1 秒打完再去按强化E
                if streak >= self.LU_FILL_CONFIRM and now - start >= f_window:
                    lit = True
                    break
            if self.LU_PANEL_SNAPSHOT and not snapped and now - start >= self.LU_FILL_SNAPSHOT_AT:
                snapped = True
                self.save_panel_snapshot(f'{tag}等回路满')
            if streak == 0 or now - start < f_window:
                # F 和 A 错开帧发(同一帧两个键游戏只认后按的); 过了 A+F 窗口后读到满的确认帧里两样都不发, 马上去按强化E
                if self.LU_F_ON_INTRO and now >= next_f:
                    self.task.send_key('f')
                    nf += 1
                    next_f = now + self.LU_F_INTERVAL
                elif now >= next_click:
                    self.click()
                    n += 1
                    next_click = now + self.A_INTERVAL
            self.macro_wait(0.02)
        self.task.can_break = False
        self.macro_mark(f'{tag}A到回路满({"亮" if lit else "CAP"},A x{n},F x{nf}'
                        f'{",演出%.2fs" % anim if anim else ""},{time.time() - start:.2f}s)')
        self.logger.info(f'{tag}A到回路满 {"lit" if lit else "CAP"} after {time.time() - start:.2f}s — '
                         f'forte white%: {" ".join(trace)}')
        return lit

    def lu_press_e3(self, tag):
        """连按强化E 到出手: 队伍 HUD 连续消失 LIB_GONE_CONFIRM 帧, 或 E 框连续两帧出 CD 数字, 立刻停手。

        不按固定时长: 按的那一刻可能正落在 A3「第46F前禁用E」里, 固定 0.6s 会整段按空;
        出手之后还接着按又会把多余的 E 带进死锁(输入缓存), 实机 23:17 就是按满 15 下。
        返回 False = 按满上限都没反应(没出去)。
        """
        start = time.time()
        n = gone = cd_hits = 0
        why = 'CAP'
        next_press = 0.0
        trace = []
        while time.time() - start < self.LU_E3_PRESS_CAP:
            now = time.time()
            if now >= next_press:
                self.send_resonance_key()
                n += 1
                next_press = now + self.E_RESEND_STEP
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone += 1
                if len(trace) < 60:
                    trace.append(f'{time.time() - start:.2f}:x')
                if gone >= self.LIB_GONE_CONFIRM:
                    why = 'HUD消失'
                    break
            else:
                gone = 0
                cd = self.read_cd('resonance')
                cd_hits = cd_hits + 1 if cd > 0 else 0
                if len(trace) < 60:
                    trace.append(f'{time.time() - start:.2f}:cd{cd:.1f}')
                if cd_hits >= 2:
                    why = '出CD'
                    break
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(x{n},{why},{time.time() - start:.2f}s)')
        self.logger.info(f'{tag} {why} after {n} presses — {" ".join(trace)}')
        return why != 'CAP'

    def lib_ready_reads(self, char, frames):
        """HUD 在场时连续 frames 帧读到 char 的 R 可用。读不到(HUD 不在)的帧不算, 最多读 frames*3 帧。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.task.in_team()[0]:
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                if not ready:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def rb_build_r(self, rb, tag):
        """丽贝卡放 R 之前的能量保底: R 没转好就补强化重击 / 平 A, 转好了才返回。返回转好了没有。

        每轮先读 R: 转好就走; 没转好 -> 强化重击指示还亮(狂热满, 前面那发多半被打断了)就补一发,
        否则平 A 一小段。R 的读数本身读偏了也只是多 A 一轮, 不会卡死(有上限)。
        """
        start = time.time()
        rounds = heavies = 0
        while time.time() - start < self.RB_R_BUILD_CAP:
            if self.lib_ready_reads(rb, 2):
                if rounds:
                    self.macro_mark(f'{tag}R能量补好(第{rounds}轮,补重击x{heavies},{time.time() - start:.2f}s)')
                    self.logger.info(f'{tag}: rebecca R ready after {rounds} rounds ({heavies} strong heavies, '
                                     f'{time.time() - start:.1f}s)')
                return True
            rounds += 1
            if heavies < self.RB_R_HEAVY_MAX and self.lit_now(rb.is_mouse_forte_full, 2):
                heavies += 1
                self.rb_strong_heavy(rb, f'{tag}补强化重击#{heavies}')
            else:
                self.macro_spam(self.RB_R_BUILD_SLICE, tag=f'{tag}补能量A#{rounds}')
        self.macro_mark(f'{tag}R能量没补满(CAP,{rounds}轮)')
        self.logger.warning(f'{tag}: rebecca R still not ready after {self.RB_R_BUILD_CAP:.0f}s, pressing R anyway')
        return False

    def rb_strong_heavy(self, rb, tag):
        """丽贝卡补一发强化重击: 按住过手枪重击-2 发生帧再松手(狂热满 = 松手出强化重击), 然后停手等伤害打出来。"""
        self.task.mouse_down()
        self.holding_attack = True
        self.macro_wait(self.RB_HEAVY_PRESS)
        self.release_attack()
        self.macro_mark(f'{tag}松手')
        self.macro_wait(self.RB_HEAVY_DMG)

    def lu_enhanced_e(self, tag):
        """露西(变奏入场): A 到回路满 -> 强化E -> 等死锁演完。

        回路条满 -> 按 E 一小段 -> 等回路条变空(死锁第1F清空) -> 再等死锁剩下那截。
        【按到出去为止】: 等不到清空 = 按的时候被打断了, 回路还满着, 重按, 最多 LU_E3_TRIES 次。
        (彩色光环图标不是每次都有 —— 视频启动轴那次按之前就没有 —— 所以不拿图标判。)
        回路条一直读不到满就照样按一次 E, 然后按固定时长等。
        """
        lit = self.lu_fill_forte(tag)
        if not lit:
            e_at = time.time()
            self.spam_key(self.send_resonance_key, self.LU_E3_PRESS, interval=self.E_RESEND_STEP,
                          tag=f'{tag}强化E(没见满)', poke=False)
            self.record_resonance_use()
            left = self.LU_E3_BLIND - (time.time() - e_at)
            if left > 0:
                self.macro_wait(left)
            return False
        for attempt in range(1, self.LU_E3_TRIES + 1):
            out = self.lu_press_e3(f'{tag}强化E#{attempt}')
            self.record_resonance_use()
            if not out and self.lit_now(self.is_forte_full, 2):
                # 按满上限 HUD 都没消失、回路还满着 = 没出去, 马上再按, 不先干等回路清空
                self.logger.info(f'{tag}: enhanced E press #{attempt} got no reaction, pressing again')
                continue
            # HUD 不在(强化E 本身, 或前面按的 F 刚好出了处决)就先等它回来: wait_until_dark 只在 HUD 在场时读,
            # 处决演出会把它的上限耗光。回来后回路还满 = 这次 E 被演出吞了, 下面重按
            self.wait_hud_up(cap=self.LU_F_ANIM_CAP, tag=f'{tag}强化E后HUD#{attempt}')
            if self.wait_until_dark(self.is_forte_full, self.LU_E3_CLEAR_CAP, f'{tag}回路清空#{attempt}'):
                self.macro_wait(self.LU_E3_TAIL)
                return True
            self.logger.info(f'{tag}: transfer bar still full after enhanced E press #{attempt} '
                             f'(interrupted?), pressing again')
        self.logger.warning(f'{tag}: enhanced E never went out after {self.LU_E3_TRIES} tries, carrying on')
        return False

    def seg_lu_finale(self, vr, tag):
        """露西(变奏入场) 收尾: (边 A 边 F)回路满 -> 强化E -> 3A -> Q -> 回路重击 -> 等出伤 -> R 面板 -> 变奏维里奈。"""
        self.poking = False
        self.lu_enhanced_e(tag)
        # 强化E 之后 3A / A 到重击亮 这两段边 A 边 F(用户 2026-09-15): 出了处决也接着 A 把回路重击攒出来。
        # 处决演出不藏 HUD、扣不掉时间, 所以开 F 时 A 到重击亮的上限放宽(读到亮就走, 不花时间)
        f_iv = self.LU_E3_AFTER_F_INTERVAL if self.LU_E3_AFTER_F else None
        heavy_cap = self.LU_HEAVY_FILL_CAP_F if self.LU_E3_AFTER_F else self.LU_HEAVY_FILL_CAP
        # 处决正好压在下面那发 Q 上时 Q 会被吞: A 到重击亮那段隔一会补按 Q
        q_iv = self.LU_E3_AFTER_Q_INTERVAL if self.LU_E3_AFTER_F else None
        # 3A 期间重击指示提前亮了就不点完, 直接 Q 接回路重击
        self.click_until_lit(self.is_mouse_forte_full, self.LU_3A_WINDOW, f'{tag}3A', f_interval=f_iv)
        self.spam_key(self.send_echo_key, self.LU_Q_WINDOW, interval=self.LU_Q_INTERVAL, tag=f'{tag}Q',
                      poke=True)
        self.record_echo_use()
        if self.click_until_lit(self.is_mouse_forte_full, heavy_cap, f'{tag}A到重击亮',
                                interval=self.LU_HEAVY_A_INTERVAL, f_interval=f_iv, q_interval=q_iv):
            self.lu_ensure_heavy(tag)
        else:
            # 指示一直没读到亮: 照旧按一发(可能是判据读不到), 不做重试
            self.task.mouse_down()
            self.holding_attack = True
            self.macro_mark(f'{tag}回路重击按住(没见亮)')
            self.macro_wait(self.LU_HEAVY_HOLD)
            self.release_attack()
        # 回路重击整串打完之前只点 A(处决会把它打断), 打完才边 A 边 F, 一直夹着 F 到 R 放出去。
        # 露丽维只在这一处处决(用户 2026-09-15); spam_a_f 第一下就是 F, 提示在的话马上出处决
        self.macro_spam(self.LU_HEAVY_NO_F, interval=self.LU_HEAVY_MASH_INTERVAL, tag=f'{tag}等重击打完A')
        self.spam_a_f(self.LU_HEAVY_F_MIN, f'{tag}重击后A+F', f_interval=self.LU_HEAVY_F_INTERVAL,
                      a_interval=self.LU_HEAVY_MASH_INTERVAL)
        # 等伤害那段里被打断的话根协议还是满的(或者又被 A 攒满了): 只要指示亮就再打出去, 确保出伤再接 R
        self.lu_ensure_heavy(f'{tag}补')
        self.lu_a_f_until_r(tag, use_f=True)
        self.lu_ensure_heavy(f'{tag}R前补')
        if self.lu_ensure_r(tag):
            self.lu_ult_panel(tag)
        if self.LU_F_BREAK:
            self.spam_f_break(self.LU_F_WINDOW, f'{tag}处决')
        return self.switch_to_vr(vr, tag)

    # ==================== 一圈 / 启动轴 / 循环轴 ====================

    def run_cycle(self, rb, vr, opener, tag):
        """维里奈(在场) -> ... -> 露西收尾 -> 维里奈变奏入场。"""
        marks = len(self.macro_marks)
        self.need(self.seg_verina(vr, rb, opener, tag=f'{tag}维'), 'verina -> rebecca')
        self.need(self.seg_rb_e(rb, self, tag=f'{tag}丽'), 'rebecca E -> lucy')
        stay = self.O_LU_E2_STAY if opener else self.L_LU_E12_STAY
        self.need(self.seg_lu_e(rb, stay, opener, tag=f'{tag}露'), 'lucy E -> rebecca')
        release_to_switch = self.O_RB_RELEASE_TO_SWITCH if opener else self.L_RB_RELEASE_TO_SWITCH
        self.need(self.seg_rb_hold(rb, self, opener and self.O_RB_TACTICAL_DODGE, release_to_switch,
                                   tag=f'{tag}丽'),
                  'rebecca heavy -> lucy')
        self.need(self.seg_lu_4a(rb, tag=f'{tag}露'), 'lucy 4A -> rebecca')
        self.need(self.seg_rb_qr(rb, self, tag=f'{tag}丽'), 'rebecca QR -> lucy')
        self.need(self.seg_lu_finale(vr, tag=f'{tag}露'), 'lucy -> verina')
        self.logger.info(f'{tag} cycle timeline: {self.macro_timeline(marks)}')

    def macro_enter(self, entry_char):
        rb = self.teammate('Rebecca')
        vr = self.teammate('Verina')
        if rb is None or vr is None:
            return None
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        self.poking = False
        # 处决由宏在固定位置按, 框架切人时那一发一律关掉
        for char in (self, rb, vr):
            char.check_f_on_switch = False
        self.macro_start()
        return rb, vr, previous

    def macro_exit(self, previous):
        # 长按跨了好几个方法, 中途抛异常的话鼠标会一直按着。这里是唯一保证松手的地方
        self.release_attack()
        self.poking = False
        self.task.skip_combat_check = previous
        self.mark_busy(False)

    def perform_opener(self, entry_char=None):
        """启动轴: 露西 E1 R -> 切维里奈 -> 一圈。返回时维里奈刚变奏入场。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        rb, vr, previous = got
        self.logger.info(f'lrv opener entry: {self.cur.name}')
        try:
            self.loop_count = 0
            if self.cur is not self:
                self.need(self.quick_switch(self), 'opener: switch to lucy')
            self.seg_lu_open(tag='op露')
            self.need(self.quick_switch(vr, click_during=True, time_out=self.LU_TO_VR_TIME_OUT),
                      'opener: lucy -> verina')
            self.run_cycle(rb, vr, opener=True, tag='op')
            self.logger.info(
                f'lrv opener total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'lrv opener broke ({e}) — timeline: {self.macro_timeline()}')
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """循环轴一圈。场上不是维里奈(宏散过)就先把场子交给她。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        rb, vr, previous = got
        try:
            if self.cur is not vr:
                self.need(self.switch_to_vr(vr, tag='L接维'), 'loop: hand the field to verina')
            self.loop_count += 1
            n = self.loop_count
            self.run_cycle(rb, vr, opener=False, tag=f'L{n}')
            self.logger.info(
                f'lrv loop #{n} {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'lrv loop broke ({e}) — timeline: {self.macro_timeline()}')
        finally:
            self.macro_exit(previous)
        return True

    def perform_tail(self, entry_char=None):
        """宏散掉后露西带着变奏上场: 只打收尾那一段(强化E ... 变奏维里奈), 然后回到正常循环。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        rb, vr, previous = got
        try:
            self.need(self.seg_lu_finale(vr, tag='T露'), 'tail: lucy -> verina')
            self.logger.info(f'lrv tail timeline: {self.macro_timeline()}')
        except MacroBroken as e:
            self.logger.warning(f'lrv tail broke ({e}) — timeline: {self.macro_timeline()}')
        finally:
            self.macro_exit(previous)
        return True

    # ==================== 框架接口 ====================

    def drive(self, entry):
        """三个人的 do_perform 都走这里。entry = 框架这次调的是谁(= 场上是谁)。"""
        try:
            # 物理 F 刚按下, 框架自己先判进了战斗: 等满 F 之后的等怪延迟再跑启动轴。
            # 实机 2026-09-15: 按 F 后 0.82~0.98s 框架就进战斗(延迟设的 1.0s), 旧代码判"启动轴还不该跑"
            # 直接掉进循环轴 —— 用户看到的就是"开关自动战斗之后一直不从启动轴开始"
            left = self.opener_f_wait_left()
            if left > 0:
                self.logger.info(f'lrv: F pressed, waiting {left:.2f}s more for the mobs, then the opener')
                self.macro_wait(left)
            blocked = self.opener_blocked_by()
            if blocked is None:
                # 标记要在跑之前落: 中途脱战也不能让启动轴重跑
                self.opener_armed = False
                self.last_opener = time.time()
                return self.perform_opener(entry)
            if entry is self and getattr(self, 'has_intro', False):
                self.logger.info('lrv: lucy came in with an intro, running the tail first')
                return self.perform_tail(entry)
            self.logger.info(f'lrv: opener not pending ({blocked}), running the loop')
            return self.perform_loop(entry)
        except Exception as e:
            # 宏跑到一半自动战斗被关掉(框架在等待里抛 TaskDisabledException): 下次打开从启动轴开始
            if type(e).__name__ == 'TaskDisabledException':
                self.opener_armed = True
                self.last_opener = -1
                self.logger.info('lrv: auto combat was turned off mid-macro, opener re-armed for next time')
            raise

    def do_perform(self):
        if not self.is_in_lrv:
            return super().do_perform()
        self.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时必须露西先上; 其余时候交给维里奈(她是 HIGH), 这里走原版。"""
        if self.is_in_lrv and self.opener_pending():
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        self.poking = False
        return super().on_combat_end(chars)
